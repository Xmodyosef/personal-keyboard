import SwiftUI

@main
struct KeyboardPrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    var body: some View {
        VStack(spacing: 18) {
            Text("لوحتي")
                .font(.largeTitle.bold())
            Text("لوحة عربية وإنجليزية خفيفة")
                .font(.title3)
            VStack(alignment: .leading, spacing: 10) {
                Label("افتح الإعدادات > عام > لوحة المفاتيح", systemImage: "gearshape")
                Label("أضف لوحة «لوحتي» من لوحات المفاتيح", systemImage: "keyboard")
                Label("فعّلها ثم بدّل إليها من زر اللغة", systemImage: "globe")
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
            Text("النموذج لا يطلب الوصول الكامل ولا يرسل ما تكتبه إلى الإنترنت.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(uiColor: .systemGroupedBackground))
    }
}
