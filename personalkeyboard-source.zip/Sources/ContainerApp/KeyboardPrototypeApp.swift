import SwiftUI
import Translation
import UIKit

@main
struct KeyboardPrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ThemeSwatch: Identifiable {
    let id: String
    let title: String
    let key: Color
    let ink: Color
}

enum ThemeCatalog {
    static let core: [ThemeSwatch] = [
        .init(id: "auto", title: "تلقائي", key: Color(red: 0.30, green: 0.32, blue: 0.36), ink: .white),
        .init(id: "light", title: "فاتح", key: Color(red: 0.92, green: 0.95, blue: 0.98), ink: Color(red: 0.16, green: 0.20, blue: 0.26)),
        .init(id: "dark", title: "داكن", key: Color(red: 0.16, green: 0.20, blue: 0.28), ink: .white),
        .init(id: "glass", title: "منشور", key: Color(red: 0.78, green: 0.76, blue: 0.86), ink: Color(red: 0.16, green: 0.20, blue: 0.26)),
        .init(id: "ocean", title: "بحر", key: Color(red: 0.10, green: 0.28, blue: 0.36), ink: .white),
        .init(id: "cobalt", title: "كوبالت", key: Color(red: 0.14, green: 0.22, blue: 0.46), ink: .white),
        .init(id: "violet", title: "بنفسج", key: Color(red: 0.24, green: 0.16, blue: 0.38), ink: .white),
        .init(id: "orchid", title: "أوركيد", key: Color(red: 0.36, green: 0.14, blue: 0.24), ink: .white),
        .init(id: "hailey", title: "دم", key: Color(red: 0.28, green: 0.10, blue: 0.12), ink: .white),
        .init(id: "ember", title: "جمر", key: Color(red: 0.32, green: 0.18, blue: 0.10), ink: .white),
        .init(id: "forest", title: "غابة", key: Color(red: 0.10, green: 0.24, blue: 0.16), ink: .white),
        .init(id: "matrix", title: "ماتريكس", key: Color(red: 0.06, green: 0.14, blue: 0.08), ink: .white),
        .init(id: "nord", title: "نورد", key: Color(red: 0.82, green: 0.86, blue: 0.90), ink: Color(red: 0.16, green: 0.20, blue: 0.26))
    ]

    static let morning: [ThemeSwatch] = [
        ("رملي", 0.93, 0.86, 0.72), ("قش", 0.90, 0.82, 0.62), ("خوخ", 0.96, 0.78, 0.68),
        ("مشمش", 0.96, 0.72, 0.48), ("عاج", 0.95, 0.92, 0.84), ("حليب", 0.96, 0.94, 0.90),
        ("نعناع", 0.74, 0.90, 0.82), ("مريمية", 0.70, 0.80, 0.72), ("سماء", 0.70, 0.84, 0.94),
        ("بحيرة", 0.55, 0.78, 0.86), ("لافندر", 0.82, 0.76, 0.90), ("ورد", 0.94, 0.74, 0.80),
        ("ذهب", 0.90, 0.76, 0.40), ("عسل", 0.88, 0.68, 0.36), ("زيتون", 0.62, 0.66, 0.40),
        ("طين", 0.72, 0.52, 0.40), ("ورق", 0.78, 0.84, 0.72), ("ضباب", 0.82, 0.84, 0.86),
        ("مرجان", 0.92, 0.55, 0.50), ("فستق", 0.70, 0.82, 0.58)
    ].enumerated().map { i, item in
        ThemeSwatch(id: "m\(i + 1)", title: item.0, key: Color(red: item.1, green: item.2, blue: item.3), ink: Color(red: 0.16, green: 0.16, blue: 0.14))
    }

    static let evening: [ThemeSwatch] = [
        ("فحم", 0.12, 0.12, 0.13), ("كحلي", 0.08, 0.12, 0.22), ("ليل", 0.07, 0.09, 0.16),
        ("حبر", 0.08, 0.10, 0.18), ("برقوق", 0.16, 0.08, 0.16), ("نبيذ", 0.22, 0.08, 0.12),
        ("غابة", 0.06, 0.14, 0.10), ("زمرد", 0.05, 0.16, 0.12), ("محيط", 0.05, 0.12, 0.18),
        ("كوبالت ليلي", 0.08, 0.12, 0.28), ("جمر", 0.22, 0.10, 0.06), ("نحاس", 0.24, 0.14, 0.08),
        ("بنفسج ليلي", 0.14, 0.08, 0.22), ("أوركيد ليلي", 0.18, 0.08, 0.16), ("رماد", 0.16, 0.18, 0.22),
        ("دخان", 0.14, 0.14, 0.16), ("قهوة", 0.18, 0.12, 0.08), ("صحراء", 0.20, 0.14, 0.10),
        ("ملكي", 0.12, 0.08, 0.20), ("فجر", 0.18, 0.10, 0.12)
    ].enumerated().map { i, item in
        ThemeSwatch(id: "e\(i + 1)", title: item.0, key: Color(red: item.1, green: item.2, blue: item.3), ink: .white)
    }

    static var all: [ThemeSwatch] { core + morning + evening }
}

enum ThemeStore {
    static let suiteName = "group.app.personal.PersonalKeyboard"
    static var suite: UserDefaults { UserDefaults(suiteName: suiteName) ?? .standard }
    static var fileURL: URL? {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: suiteName)?
            .appendingPathComponent("naqra-prefs.json")
    }
    static func fileDict() -> [String: Any] {
        guard let url = fileURL, let data = try? Data(contentsOf: url),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return [:] }
        return obj
    }
    static let boardName = UIPasteboard.Name("group.app.personal.PersonalKeyboard")
    static func write(_ key: String, value: Any) {
        suite.set(value, forKey: key)
        UserDefaults.standard.set(value, forKey: key)
        suite.synchronize()
        UserDefaults.standard.synchronize()
        var d = fileDict()
        d[key] = value
        if let url = fileURL, let data = try? JSONSerialization.data(withJSONObject: d, options: []) {
            try? data.write(to: url, options: .atomic)
        }
        let pb = UIPasteboard(name: boardName, create: true)
        if let text = value as? String {
            pb?.string = "naqra|" + key + "|" + text
        } else if let flag = value as? Bool {
            pb?.string = "naqra|" + key + "|" + (flag ? "1" : "0")
        }
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName("app.personal.PersonalKeyboard.prefs" as CFString),
            nil, nil, true
        )
    }
    static func string(_ key: String) -> String? {
        if let v = fileDict()[key] as? String { return v }
        if let v = suite.string(forKey: key) { return v }
        if let v = UserDefaults.standard.string(forKey: key) { return v }
        if let raw = UIPasteboard(name: boardName, create: false)?.string,
           raw.hasPrefix("naqra|" + key + "|") {
            return String(raw.dropFirst(("naqra|" + key + "|").count))
        }
        return nil
    }
    static func bool(_ key: String) -> Bool? {
        if let v = fileDict()[key] as? Bool { return v }
        if suite.object(forKey: key) != nil { return suite.bool(forKey: key) }
        if UserDefaults.standard.object(forKey: key) != nil { return UserDefaults.standard.bool(forKey: key) }
        return nil
    }
    static var groupAlive: Bool {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: suiteName) != nil
    }
}

struct ContentView: View {
    @State private var themeID = ThemeStore.string("themeId") ?? "dark"
    @State private var haptics = ThemeStore.bool("haptics") ?? true
    @State private var hapticLevel = ThemeStore.string("hapticLevel") ?? "medium"
    @State private var trackpad = ThemeStore.bool("trackpad") ?? true
    @State private var hasFullAccess = ThemeStore.bool("hasFullAccess") ?? false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    accessCard
                    NavigationLink {
                        ThemePreviewScreen(themeID: $themeID)
                    } label: {
                        Label("معاينة الثيمات", systemImage: "paintpalette")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white.opacity(0.08))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    extrasCard
                    repairCard
                    if #available(iOS 18.0, *) {
                        TranslationPrepCard()
                    }
                    Text(ThemeStore.groupAlive
                         ? "الثيم يُختار هنا ويصل للوحة عند فتحها. أبقِ App Groups عند التوقيع."
                         : "التوقيع العام قد يمنع المشاركة. أبقِ App Groups ولا تحذف الـ entitlements.")
                        .font(.footnote)
                        .foregroundStyle(.white.opacity(0.62))
                }
                .padding()
            }
            .background(Color.black.ignoresSafeArea())
            .navigationTitle("نقرة")
            .toolbarColorScheme(.dark, for: .navigationBar)
        }
        .preferredColorScheme(.dark)
        .onAppear(perform: reload)
    }

    private var accessCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(hasFullAccess ? "الوصول الكامل مفعّل" : "الوصول الكامل غير مفعّل")
                .font(.headline)
            Text("يلزم للنسخ واللصق والترجمة.")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.7))
            Button("فتح الإعدادات") {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var extrasCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("اللمس")
                .font(.headline)
            Toggle("اهتزاز المفاتيح", isOn: $haptics)
                .onChange(of: haptics) { _, v in ThemeStore.write("haptics", value: v) }
            if haptics {
                Picker("شدة الاهتزاز", selection: $hapticLevel) {
                    Text("خفيف").tag("light")
                    Text("وسط").tag("medium")
                    Text("قوي").tag("strong")
                }
                .pickerStyle(.segmented)
                .onChange(of: hapticLevel) { _, v in ThemeStore.write("hapticLevel", value: v) }
            }
            Toggle("سحب المسافة لتحريك المؤشر", isOn: $trackpad)
                .onChange(of: trackpad) { _, v in ThemeStore.write("trackpad", value: v) }
            Text("لوحات iOS قد لا تهتز حتى مع تفعيل المفتاح.")
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.55))
        }
        .padding()
        .background(Color.white.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var repairCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("إصلاح")
                .font(.headline)
            Text("يعيد الثيم الداكن، ويمسح اللغة المحفوظة، ويوقف الاهتزاز. الارتفاع يبقى 268.")
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.62))
            Button("إصلاح اللوحة") {
                themeID = "dark"
                haptics = false
                ThemeStore.write("themeId", value: "dark")
                ThemeStore.write("lastLanguage", value: "ar")
                ThemeStore.write("haptics", value: false)
            }
            .buttonStyle(.bordered)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func reload() {
        hasFullAccess = ThemeStore.bool("hasFullAccess") ?? false
        if let raw = ThemeStore.string("themeId") { themeID = raw }
        if let v = ThemeStore.bool("haptics") { haptics = v }
        if let v = ThemeStore.bool("trackpad") { trackpad = v }
        if let v = ThemeStore.string("hapticLevel"), ["light", "medium", "strong"].contains(v) { hapticLevel = v }
    }
}

struct ThemePreviewScreen: View {
    @Binding var themeID: String
    @State private var draft: String = "dark"

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                preview
                Button("تطبيق هذا الثيم") {
                    themeID = draft
                    ThemeStore.write("themeId", value: draft)
                }
                .buttonStyle(.borderedProminent)
                .frame(maxWidth: .infinity)
                section("الأساسية", ThemeCatalog.core)
                section("عشرون صباحاً", ThemeCatalog.morning)
                section("عشرون مساءً", ThemeCatalog.evening)
            }
            .padding()
        }
        .background(Color.black.ignoresSafeArea())
        .navigationTitle("معاينة الثيم")
        .toolbarColorScheme(.dark, for: .navigationBar)
        .onAppear { draft = themeID }
    }

    private var current: ThemeSwatch {
        ThemeCatalog.all.first { $0.id == draft } ?? ThemeCatalog.core[2]
    }

    private var preview: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(current.title)
                .font(.headline)
            HStack(spacing: 6) {
                ForEach(["ض", "ص", "ث", "ق"], id: \.self) { letter in
                    Text(letter)
                        .font(.system(size: 18, weight: .medium))
                        .foregroundStyle(current.ink)
                        .frame(maxWidth: .infinity)
                        .frame(height: 42)
                        .background(current.key)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
            }
            Text("المعاينة قبل التطبيق. اللوحة بلا زر ثيم.")
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.6))
        }
        .padding()
        .background(Color.white.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private func section(_ title: String, _ items: [ThemeSwatch]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.headline)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                ForEach(items) { item in
                    Button { draft = item.id } label: {
                        HStack {
                            Text(item.title)
                                .foregroundStyle(item.ink)
                            Spacer()
                            Text("ض")
                                .foregroundStyle(item.ink)
                        }
                        .padding(10)
                        .frame(maxWidth: .infinity)
                        .background(item.key)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(draft == item.id ? Color.white : Color.clear, lineWidth: 2)
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

@available(iOS 18.0, *)
struct TranslationPrepCard: View {
    @State private var status = "جاري فحص حزم الترجمة…"

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("تجهيز ترجمة iOS 18")
                .font(.headline)
            Text(status)
                .font(.subheadline)
            Text("الترجمة داخل اللوحة بين العربية والإنجليزية فقط.")
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.62))
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .task {
            let availability = LanguageAvailability()
            let arEn = await availability.status(from: Locale.Language(identifier: "ar"), to: Locale.Language(identifier: "en"))
            let enAr = await availability.status(from: Locale.Language(identifier: "en"), to: Locale.Language(identifier: "ar"))
            switch (arEn, enAr) {
            case (.installed, .installed): status = "حزم العربية والإنجليزية جاهزة."
            case (.unsupported, _), (_, .unsupported): status = "الجهاز لا يدعم هذا الزوج من اللغات."
            default: status = "اللغات مدعومة. قد تُنزَّل الحزم عند أول ترجمة."
            }
        }
    }
}
