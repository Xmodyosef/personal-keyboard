import SwiftUI
import Translation
import UIKit

@main
struct KeyboardPrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

enum NaqraThemeID: String, CaseIterable, Identifiable {
    case auto, light, dark, glass, ocean, cobalt, violet
    case orchid, hailey, ember, forest, matrix, nord, custom

    var id: String { rawValue }

    var title: String {
        switch self {
        case .auto: return "تلقائي"
        case .light: return "فاتح"
        case .dark: return "داكن"
        case .glass: return "منشور"
        case .ocean: return "بحر"
        case .cobalt: return "كوبالت"
        case .violet: return "بنفسج"
        case .orchid: return "أوركيد"
        case .hailey: return "دم"
        case .ember: return "جمر"
        case .forest: return "غابة"
        case .matrix: return "ماتريكس"
        case .nord: return "نورد"
        case .custom: return "مخصص"
        }
    }

    var keyColor: Color {
        switch self {
        case .auto: return Color(red: 0.30, green: 0.32, blue: 0.36)
        case .light: return Color(red: 0.92, green: 0.95, blue: 0.98)
        case .dark: return Color(red: 0.16, green: 0.20, blue: 0.28)
        case .glass: return Color(red: 0.78, green: 0.76, blue: 0.86)
        case .ocean: return Color(red: 0.10, green: 0.28, blue: 0.36)
        case .cobalt: return Color(red: 0.14, green: 0.22, blue: 0.46)
        case .violet: return Color(red: 0.24, green: 0.16, blue: 0.38)
        case .orchid: return Color(red: 0.36, green: 0.14, blue: 0.24)
        case .hailey: return Color(red: 0.28, green: 0.10, blue: 0.12)
        case .ember: return Color(red: 0.32, green: 0.18, blue: 0.10)
        case .forest: return Color(red: 0.10, green: 0.24, blue: 0.16)
        case .matrix: return Color(red: 0.06, green: 0.14, blue: 0.08)
        case .nord: return Color(red: 0.82, green: 0.86, blue: 0.90)
        case .custom: return Color(red: 0.42, green: 0.46, blue: 0.50)
        }
    }

    var ink: Color {
        switch self {
        case .light, .glass, .nord: return Color(red: 0.16, green: 0.20, blue: 0.26)
        default: return Color.white.opacity(0.92)
        }
    }

    static func normalized(_ raw: String) -> NaqraThemeID {
        switch raw {
        case "charcoal", "smoke": return .dark
        case "teal": return .ocean
        case "midnight": return .cobalt
        case "snow": return .light
        case "clear": return .glass
        default: return NaqraThemeID(rawValue: raw) ?? .dark
        }
    }
}

enum ThemeStore {
    static let suiteName = "group.app.personal.PersonalKeyboard"
    static var suite: UserDefaults { UserDefaults(suiteName: suiteName) ?? .standard }
    static var fileURL: URL? {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: suiteName)?
            .appendingPathComponent("naqra-prefs.json")
    }

    static func fileDict() -> [String: Any] {
        guard let url = fileURL, let data = try? Data(contentsOf: url),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return [:] }
        return obj
    }

    static let boardName = UIPasteboard.Name("group.app.personal.PersonalKeyboard")

    static func write(_ key: String, value: Any) {
        suite.set(value, forKey: key)
        UserDefaults.standard.set(value, forKey: key)
        suite.synchronize()
        UserDefaults.standard.synchronize()
        var d = fileDict()
        d[key] = value
        if let url = fileURL, let data = try? JSONSerialization.data(withJSONObject: d, options: []) {
            try? data.write(to: url, options: .atomic)
        }
        let pb = UIPasteboard(name: boardName, create: true)
        if let text = value as? String {
            pb?.string = "naqra|" + key + "|" + text
        } else if let flag = value as? Bool {
            pb?.string = "naqra|" + key + "|" + (flag ? "1" : "0")
        }
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName("app.personal.PersonalKeyboard.prefs" as CFString),
            nil,
            nil,
            true
        )
    }

    static func string(_ key: String) -> String? {
        if let v = fileDict()[key] as? String { return v }
        if let v = suite.string(forKey: key) { return v }
        if let v = UserDefaults.standard.string(forKey: key) { return v }
        if key == "themeId",
           let raw = UIPasteboard(name: boardName, create: false)?.string,
           raw.hasPrefix("naqra|themeId|") {
            return String(raw.dropFirst("naqra|themeId|".count))
        }
        return nil
    }

    static func bool(_ key: String) -> Bool? {
        if let v = fileDict()[key] as? Bool { return v }
        if suite.object(forKey: key) != nil { return suite.bool(forKey: key) }
        if UserDefaults.standard.object(forKey: key) != nil {
            return UserDefaults.standard.bool(forKey: key)
        }
        return nil
    }

    static var groupAlive: Bool {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: suiteName) != nil
    }
}

struct ContentView: View {
    @State private var hasFullAccess = false
    @State private var themeID = NaqraThemeID.dark
    @State private var haptics = true
    @State private var trackpad = true
    @State private var hapticLevel = "medium"
    @State private var batterySaver = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    accessCard
                    themesCard
                    extrasCard
                }
                .padding()
            }
            .navigationTitle("نقرة")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear(perform: reload)
        }
    }

    private var accessCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            if hasFullAccess {
                Text("الوصول الكامل مفعّل")
                    .font(.headline)
                Text("النسخ واللصق والترجمة جاهزة.")
                    .font(.subheadline)
            } else {
                Text("الوصول الكامل غير مفعّل")
                    .font(.headline)
                Text("يلزم للنسخ واللصق والترجمة وسجلّ العبارات.")
                    .font(.subheadline)
                Button {
                    if let url = URL(string: UIApplication.openSettingsURLString) {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    Text("فتح الإعدادات الآن")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                }
                .buttonStyle(.borderedProminent)
                Text("ثم: عام → لوحة المفاتيح → نقرة → السماح بالوصول الكامل.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(hasFullAccess ? Color.green.opacity(0.18) : Color.orange.opacity(0.16))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var themesCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("الثيمات")
                .font(.headline)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach(NaqraThemeID.allCases) { item in
                    Button {
                        applyTheme(item)
                    } label: {
                        VStack(spacing: 8) {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(item.keyColor)
                                .frame(height: 52)
                                .overlay(
                                    HStack(spacing: 6) {
                                        miniKey("Q", item)
                                        miniKey("W", item)
                                        miniKey("E", item)
                                    }
                                    .padding(.horizontal, 10)
                                )
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(themeID == item ? Color.white : Color.clear, lineWidth: 2)
                                )
                        }
                        .padding(10)
                        .frame(maxWidth: .infinity)
                        .contentShape(Rectangle())
                        .background(themeID == item ? Color.accentColor.opacity(0.18) : Color.secondary.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .buttonStyle(.plain)
                }
            }
            Text(ThemeStore.groupAlive
                 ? "مجموعة التطبيق تعمل. الثيم هنا يصل للوحة بعد إعادة فتحها."
                 : "التوقيع العام قد يمنع المشاركة. غيّر الثيم من أيقونة الألوان داخل اللوحة، أو عند التوقيع في ESign / Feather / TrollStore أبقِ App Groups ولا تحذف الـ entitlements.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func miniKey(_ letter: String, _ item: NaqraThemeID) -> some View {
        Text(letter)
            .font(.system(size: 12, weight: .semibold))
            .foregroundStyle(item.ink)
            .frame(width: 28, height: 20)
            .background(item.keyColor.opacity(0.35))
            .clipShape(RoundedRectangle(cornerRadius: 4))
    }

    private var extrasCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("لمس أدق")
                .font(.headline)
            Toggle("اهتزاز المفاتيح", isOn: $haptics)
                .onChange(of: haptics) { _, v in ThemeStore.write("haptics", value: v) }
            if haptics {
                Picker("شدّة الاهتزاز", selection: $hapticLevel) {
                    Text("خفيف").tag("light")
                    Text("وسط").tag("medium")
                    Text("قوي").tag("strong")
                }
                .pickerStyle(.segmented)
                .onChange(of: hapticLevel) { _, v in
                    ThemeStore.write("hapticLevel", value: v)
                    let style: UIImpactFeedbackGenerator.FeedbackStyle = v == "strong" ? .rigid : (v == "light" ? .light : .medium)
                    UIImpactFeedbackGenerator(style: style).impactOccurred()
                }
            }
            Toggle("سحب المسافة لتحريك المؤشر", isOn: $trackpad)
                .onChange(of: trackpad) { _, v in ThemeStore.write("trackpad", value: v) }
            Toggle("توفير البطارية", isOn: $batterySaver)
                .onChange(of: batterySaver) { _, v in ThemeStore.write("batterySaver", value: v) }
            Text("اضغط المسافة مرة للمسافة، مرتين سريعاً لتبديل عربي/إنجليزي، واسحب عليها يميناً ويساراً لتحريك المؤشر دون رفع الإصبع.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var howToCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("تفعيل اللوحة")
                .font(.headline)
            Text("1. الإعدادات → عام → لوحة المفاتيح → لوحات المفاتيح.")
            Text("2. أضف لوحة مفاتيح ثم اختر نقرة.")
            Text("3. اضغط نقرة وفعّل السماح بالوصول الكامل.")
            Text("4. افتح اللوحة مرة ثم ارجع هنا لتتحدّث الحالة.")
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var sideloadCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("ESign / Feather / TrollStore")
                .font(.headline)
            Text("لا يوجد زر سحري داخل ملف deb. الثيم بين التطبيق واللوحة يحتاج App Group.")
            Text("عند التوقيع: لا تزيل Entitlements، وأبقِ group.app.personal.PersonalKeyboard. شهادة مطور أو TrollStore غالباً تشغّلها. التوقيع العام غالباً لا.")
            Text("إذا فشل المشاركة: ثيم اللوحة من أيقونة الألوان يعمل مباشرة.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func applyTheme(_ item: NaqraThemeID) {
        themeID = item
        ThemeStore.write("themeId", value: item.rawValue)
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    private func reload() {
        hasFullAccess = ThemeStore.bool("hasFullAccess") ?? false
        if let raw = ThemeStore.string("themeId") {
            themeID = NaqraThemeID.normalized(raw)
        }
        if let v = ThemeStore.bool("haptics") { haptics = v }
        if let v = ThemeStore.bool("trackpad") { trackpad = v }
        if let v = ThemeStore.string("hapticLevel"), ["light","medium","strong"].contains(v) { hapticLevel = v }
        if let v = ThemeStore.bool("batterySaver") { batterySaver = v }
    }
}

@available(iOS 18.0, *)
struct TranslationPrepCard: View {
    @State private var status = "جاري فحص حزم الترجمة…"

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("تجهيز ترجمة iOS 18")
                .font(.headline)
            Text(status)
                .font(.subheadline)
            Text("الترجمة داخل اللوحة بين العربية والإنجليزية فقط.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.blue.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .task {
            let availability = LanguageAvailability()
            let arEn = await availability.status(from: Locale.Language(identifier: "ar"), to: Locale.Language(identifier: "en"))
            let enAr = await availability.status(from: Locale.Language(identifier: "en"), to: Locale.Language(identifier: "ar"))
            switch (arEn, enAr) {
            case (.installed, .installed): status = "حزم العربية والإنجليزية جاهزة."
            case (.unsupported, _), (_, .unsupported): status = "الجهاز لا يدعم هذا الزوج من اللغات."
            default: status = "اللغات مدعومة. قد تُنزَّل الحزم عند أول ترجمة."
            }
        }
    }
}
