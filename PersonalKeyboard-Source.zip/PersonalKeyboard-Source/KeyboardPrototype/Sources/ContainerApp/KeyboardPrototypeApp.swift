import SwiftUI
import Translation

@main
struct KeyboardPrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

enum NaqraThemeID: String, CaseIterable, Identifiable {
    case glass, charcoal, teal, midnight, violet, smoke, snow, clear
    var id: String { rawValue }

    var title: String {
        switch self {
        case .glass: return "زجاج داكن"
        case .charcoal: return "فحمي شفاف"
        case .teal: return "تيل نقرة"
        case .midnight: return "أزرق ليلي"
        case .violet: return "بنفسجي"
        case .smoke: return "دخاني"
        case .snow: return "ثلجي"
        case .clear: return "زجاج أفتح"
        }
    }

    var swatch: Color {
        switch self {
        case .glass: return Color(red: 0.14, green: 0.15, blue: 0.18)
        case .charcoal: return Color(red: 0.10, green: 0.10, blue: 0.12)
        case .teal: return Color(red: 0.07, green: 0.28, blue: 0.32)
        case .midnight: return Color(red: 0.07, green: 0.12, blue: 0.24)
        case .violet: return Color(red: 0.20, green: 0.12, blue: 0.30)
        case .smoke: return Color(red: 0.22, green: 0.23, blue: 0.26)
        case .snow: return Color(red: 0.90, green: 0.92, blue: 0.95)
        case .clear: return Color(red: 0.18, green: 0.20, blue: 0.24)
        }
    }
}

struct ContentView: View {
    private let suite = UserDefaults(suiteName: "group.app.personal.PersonalKeyboard") ?? .standard

    @State private var hasFullAccess = false
    @State private var themeID = NaqraThemeID.glass
    @State private var haptics = true
    @State private var trackpad = true

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("نقرة")
                        .font(.largeTitle.bold())
                    Text("لوحة عربية وإنجليزية. اسحب على المسافة لتحريك المؤشر.")
                        .foregroundStyle(.secondary)

                    if !hasFullAccess {
                        accessCard
                    }

                    themesCard
                    extrasCard
                    howToCard

                    if #available(iOS 18.0, *) {
                        TranslationPrepCard()
                    }
                }
                .padding()
            }
            .navigationTitle("نقرة")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear(perform: reload)
        }
    }

    private var accessCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("الوصول الكامل غير مفعّل")
                .font(.headline)
            Text("يلزم للنسخ واللصق والترجمة وسجلّ العبارات.")
                .font(.subheadline)
            Button {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            } label: {
                Text("فتح الإعدادات الآن")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
            }
            .buttonStyle(.borderedProminent)
            Text("ثم: عام → لوحة المفاتيح → نقرة → السماح بالوصول الكامل.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.orange.opacity(0.16))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var themesCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("الثيمات")
                .font(.headline)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach(NaqraThemeID.allCases) { item in
                    Button {
                        themeID = item
                        suite.set(item.rawValue, forKey: "themeId")
                    } label: {
                        VStack(alignment: .leading, spacing: 8) {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(item.swatch)
                                .frame(height: 44)
                                .overlay(
                                    HStack(spacing: 6) {
                                        cap
                                        cap
                                        cap
                                    }
                                    .padding(.horizontal, 10)
                                )
                            Text(item.title)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.primary)
                        }
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(themeID == item ? Color.accentColor.opacity(0.18) : Color.secondary.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .buttonStyle(.plain)
                }
            }
            Text("افتح أي حقل كتابة بعد الاختيار لترى الثيم على اللوحة.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var cap: some View {
        RoundedRectangle(cornerRadius: 4)
            .fill(.white.opacity(0.28))
            .frame(width: 28, height: 18)
    }

    private var extrasCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("لمس أدق")
                .font(.headline)
            Toggle("اهتزاز خفيف عند المفاتيح", isOn: $haptics)
                .onChange(of: haptics) { _, v in suite.set(v, forKey: "haptics") }
            Toggle("سحب المسافة لتحريك المؤشر", isOn: $trackpad)
                .onChange(of: trackpad) { _, v in suite.set(v, forKey: "trackpad") }
            Text("اضغط المسافة مرة للمسافة، مرتين سريعاً لتبديل عربي/إنجليزي، واسحب عليها يميناً ويساراً لتحريك المؤشر دون رفع الإصبع.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var howToCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("تفعيل اللوحة")
                .font(.headline)
            Text("1. الإعدادات → عام → لوحة المفاتيح → لوحات المفاتيح.")
            Text("2. أضف لوحة مفاتيح ثم اختر نقرة.")
            Text("3. اضغط نقرة وفعّل السماح بالوصول الكامل.")
            Text("4. ارجع هنا بعد التفعيل ليختفي كرت الحالة.")
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func reload() {
        hasFullAccess = suite.bool(forKey: "hasFullAccess")
        if let raw = suite.string(forKey: "themeId"), let t = NaqraThemeID(rawValue: raw) {
            themeID = t
        }
        if suite.object(forKey: "haptics") != nil { haptics = suite.bool(forKey: "haptics") }
        if suite.object(forKey: "trackpad") != nil { trackpad = suite.bool(forKey: "trackpad") }
    }
}

@available(iOS 18.0, *)
struct TranslationPrepCard: View {
    @State private var status = "جاري فحص حزم الترجمة…"

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("تجهيز ترجمة iOS 18")
                .font(.headline)
            Text(status)
                .font(.subheadline)
            Text("الترجمة داخل اللوحة بين العربية والإنجليزية فقط.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.blue.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .task {
            let availability = LanguageAvailability()
            let arEn = await availability.status(from: Locale.Language(identifier: "ar"), to: Locale.Language(identifier: "en"))
            let enAr = await availability.status(from: Locale.Language(identifier: "en"), to: Locale.Language(identifier: "ar"))
            switch (arEn, enAr) {
            case (.installed, .installed): status = "حزم العربية والإنجليزية جاهزة."
            case (.unsupported, _), (_, .unsupported): status = "الجهاز لا يدعم هذا الزوج من اللغات."
            default: status = "اللغات مدعومة. قد تُنزَّل الحزم عند أول ترجمة."
            }
        }
    }
}