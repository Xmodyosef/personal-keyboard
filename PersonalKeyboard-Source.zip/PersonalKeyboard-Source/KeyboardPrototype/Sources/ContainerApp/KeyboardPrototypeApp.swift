import SwiftUI
import Translation

@main
struct PersonalKeyboardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @AppStorage("hasFullAccess", store: UserDefaults(suiteName: "group.app.personal.PersonalKeyboard"))
    private var hasFullAccess = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("لوحة عربية وإنجليزية")
                            .font(.title2.bold())
                        Text("مسافتان تبدّلان العربية والإنجليزية. زر ترجم يحوّل النص المحدد بينهما.")
                            .foregroundStyle(.secondary)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Label(
                            hasFullAccess ? "الوصول الكامل مفعّل" : "الوصول الكامل غير مفعّل",
                            systemImage: hasFullAccess ? "checkmark.seal.fill" : "exclamationmark.triangle.fill"
                        )
                        .foregroundStyle(hasFullAccess ? .green : .orange)

                        Button("فتح إعدادات الآيفون") {
                            if let url = URL(string: UIApplication.openSettingsURLString) {
                                UIApplication.shared.open(url)
                            }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))

                    VStack(alignment: .leading, spacing: 10) {
                        Text("التفعيل").font(.headline)
                        Label("الإعدادات > عام > لوحة المفاتيح > لوحات المفاتيح", systemImage: "gearshape")
                        Label("أضف «كيبورد» ثم فعّلها", systemImage: "keyboard")
                        Label("اسمح بالوصول الكامل للحافظة والترجمة", systemImage: "lock.open")
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))

                    VStack(alignment: .leading, spacing: 10) {
                        Text("الاستخدام").font(.headline)
                        Label("مسافتان: العربية ↔ English", systemImage: "globe")
                        Label("زر ترجم: إلى العربية أو إلى English", systemImage: "character.book.closed")
                        Label("الأرقام إنجليزية دائماً", systemImage: "number")
                        Label("الرموز والإيموجي من الشريط العلوي", systemImage: "face.smiling")
                        Label("الحذف يمين، والضغط المطوّل يحذف باستمرار", systemImage: "delete.left")
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))

                    if #available(iOS 18.0, *) {
                        TranslationPreparationButton()
                    }

                    Text("النسخ والحافظة والترجمة يحتاجون الوصول الكامل. الترجمة بين العربية والإنجليزية على الجهاز من iOS 18 بعد تجهيز الحزم.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("كيبورد")
        }
    }
}

@available(iOS 18.0, *)
private struct TranslationPreparationButton: View {
    @State private var configuration: TranslationSession.Configuration?
    @State private var status = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button("تجهيز الترجمة العربية والإنجليزية") {
                configuration = TranslationSession.Configuration(
                    source: Locale.Language(identifier: "ar"),
                    target: Locale.Language(identifier: "en")
                )
            }
            .buttonStyle(.bordered)
            if !status.isEmpty {
                Text(status)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .translationTask(configuration) { session in
            do {
                try await session.prepareTranslation()
                status = "اكتمل تجهيز الترجمة على الجهاز"
            } catch {
                status = "تعذر التجهيز. اتصل بـ Wi‑Fi وأعد المحاولة"
            }
        }
    }
}