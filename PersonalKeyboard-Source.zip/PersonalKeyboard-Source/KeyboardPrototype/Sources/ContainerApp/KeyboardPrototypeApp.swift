import SwiftUI

@main
struct KeyboardPrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

enum NaqraThemeID: String, CaseIterable, Identifiable {
    case auto, light, dark, glass, ocean, cobalt, violet
    case orchid, hailey, ember, forest, matrix, nord, custom

    var id: String { rawValue }

    var title: String {
        switch self {
        case .auto: return "تلقائي"
        case .light: return "فاتح"
        case .dark: return "داكن"
        case .glass: return "منشور"
        case .ocean: return "بحر"
        case .cobalt: return "كوبالت"
        case .violet: return "بنفسج"
        case .orchid: return "أوركيد"
        case .hailey: return "دم"
        case .ember: return "جمر"
        case .forest: return "غابة"
        case .matrix: return "ماتريكس"
        case .nord: return "نورد"
        case .custom: return "مخصص"
        }
    }

    var swatch: Color {
        switch self {
        case .auto: return Color(red: 0.28, green: 0.30, blue: 0.34)
        case .light: return Color(red: 0.90, green: 0.95, blue: 0.99)
        case .dark: return Color(red: 0.10, green: 0.16, blue: 0.28)
        case .glass: return Color(red: 0.70, green: 0.66, blue: 0.82)
        case .ocean: return Color(red: 0.06, green: 0.22, blue: 0.32)
        case .cobalt: return Color(red: 0.10, green: 0.18, blue: 0.42)
        case .violet: return Color(red: 0.18, green: 0.10, blue: 0.32)
        case .orchid: return Color(red: 0.32, green: 0.08, blue: 0.18)
        case .hailey: return Color(red: 0.22, green: 0.05, blue: 0.08)
        case .ember: return Color(red: 0.24, green: 0.12, blue: 0.05)
        case .forest: return Color(red: 0.06, green: 0.18, blue: 0.12)
        case .matrix: return Color(red: 0.02, green: 0.07, blue: 0.03)
        case .nord: return Color(red: 0.78, green: 0.82, blue: 0.86)
        case .custom: return Color(red: 0.45, green: 0.48, blue: 0.52)
        }
    }

    static func normalized(_ raw: String) -> NaqraThemeID {
        switch raw {
        case "charcoal", "smoke": return .dark
        case "teal": return .ocean
        case "midnight": return .cobalt
        case "snow": return .light
        case "clear": return .glass
        default: return NaqraThemeID(rawValue: raw) ?? .dark
        }
    }
}

enum ThemeStore {
    static let suiteName = "group.app.personal.PersonalKeyboard"
    static var suite: UserDefaults { UserDefaults(suiteName: suiteName) ?? .standard }

    static func write(_ key: String, value: Any) {
        suite.set(value, forKey: key)
        UserDefaults.standard.set(value, forKey: key)
        suite.synchronize()
        UserDefaults.standard.synchronize()
    }

    static func string(_ key: String) -> String? {
        suite.string(forKey: key) ?? UserDefaults.standard.string(forKey: key)
    }

    static func bool(_ key: String) -> Bool? {
        if suite.object(forKey: key) != nil { return suite.bool(forKey: key) }
        if UserDefaults.standard.object(forKey: key) != nil {
            return UserDefaults.standard.bool(forKey: key)
        }
        return nil
    }
}

struct ContentView: View {
    @State private var hasFullAccess = false
    @State private var themeID = NaqraThemeID.dark
    @State private var haptics = true
    @State private var trackpad = true

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("نقرة")
                        .font(.largeTitle.bold())
                    Text("لوحة عربية وإنجليزية. اسحب على المسافة لتحريك المؤشر.")
                        .foregroundStyle(.secondary)

                    if !hasFullAccess {
                        accessCard
                    }

                    themesCard
                    extrasCard
                    howToCard

                    if #available(iOS 18.0, *) {
                        TranslationPrepCard()
                    }
                }
                .padding()
            }
            .navigationTitle("نقرة")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear(perform: reload)
        }
    }

    private var accessCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("الوصول الكامل غير مفعّل")
                .font(.headline)
            Text("يلزم للنسخ واللصق والترجمة وسجلّ العبارات.")
                .font(.subheadline)
            Button {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            } label: {
                Text("فتح الإعدادات الآن")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
            }
            .buttonStyle(.borderedProminent)
            Text("ثم: عام → لوحة المفاتيح → نقرة → السماح بالوصول الكامل.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.orange.opacity(0.16))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var themesCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("الثيمات")
                .font(.headline)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach(NaqraThemeID.allCases) { item in
                    Button {
                        themeID = item
                        ThemeStore.write("themeId", value: item.rawValue)
                    } label: {
                        VStack(alignment: .leading, spacing: 8) {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(item.swatch)
                                .frame(height: 44)
                                .overlay(
                                    HStack(spacing: 6) {
                                        cap
                                        cap
                                        cap
                                    }
                                    .padding(.horizontal, 10)
                                )
                            Text(item.title)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.primary)
                        }
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(themeID == item ? Color.accentColor.opacity(0.18) : Color.secondary.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .buttonStyle(.plain)
                }
            }
            Text("نفس قائمة اللوحة. إذا ثيم التطبيق ما ظهر على لوحة ESign العام، غيّره من أيقونة الثيم داخل اللوحة.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var cap: some View {
        RoundedRectangle(cornerRadius: 4)
            .fill(.white.opacity(0.28))
            .frame(width: 28, height: 18)
    }

    private var extrasCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("لمس أدق")
                .font(.headline)
            Toggle("اهتزاز خفيف عند المفاتيح", isOn: $haptics)
                .onChange(of: haptics) { _, v in ThemeStore.write("haptics", value: v) }
            Toggle("سحب المسافة لتحريك المؤشر", isOn: $trackpad)
                .onChange(of: trackpad) { _, v in ThemeStore.write("trackpad", value: v) }
            Text("اضغط المسافة مرة للمسافة، مرتين سريعاً لتبديل عربي/إنجليزي، واسحب عليها يميناً ويساراً لتحريك المؤشر دون رفع الإصبع.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var howToCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("تفعيل اللوحة")
                .font(.headline)
            Text("1. الإعدادات → عام → لوحة المفاتيح → لوحات المفاتيح.")
            Text("2. أضف لوحة مفاتيح ثم اختر نقرة.")
            Text("3. اضغط نقرة وفعّل السماح بالوصول الكامل.")
            Text("4. ارجع هنا بعد التفعيل ليختفي كرت الحالة.")
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func reload() {
        hasFullAccess = ThemeStore.bool("hasFullAccess") ?? false
        if let raw = ThemeStore.string("themeId") {
            themeID = NaqraThemeID.normalized(raw)
        }
        if let v = ThemeStore.bool("haptics") { haptics = v }
        if let v = ThemeStore.bool("trackpad") { trackpad = v }
    }
}

@available(iOS 18.0, *)
struct TranslationPrepCard: View {
    @State private var status = "جاري فحص حزم الترجمة…"

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("تجهيز ترجمة iOS 18")
                .font(.headline)
            Text(status)
                .font(.subheadline)
            Text("الترجمة داخل اللوحة بين العربية والإنجليزية فقط.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.blue.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .task {
            let availability = LanguageAvailability()
            let arEn = await availability.status(from: Locale.Language(identifier: "ar"), to: Locale.Language(identifier: "en"))
            let enAr = await availability.status(from: Locale.Language(identifier: "en"), to: Locale.Language(identifier: "ar"))
            switch (arEn, enAr) {
            case (.installed, .installed): status = "حزم العربية والإنجليزية جاهزة."
            case (.unsupported, _), (_, .unsupported): status = "الجهاز لا يدعم هذا الزوج من اللغات."
            default: status = "اللغات مدعومة. قد تُنزَّل الحزم عند أول ترجمة."
            }
        }
    }
}