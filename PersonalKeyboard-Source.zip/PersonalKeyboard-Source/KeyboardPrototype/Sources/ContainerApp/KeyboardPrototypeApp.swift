import SwiftUI
import Translation

@main
struct KeyboardPrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    private let appGroupID = "group.app.personal.PersonalKeyboard"

    private var defaults: UserDefaults {
        UserDefaults(suiteName: appGroupID) ?? .standard
    }

    private var hasFullAccess: Bool {
        defaults.bool(forKey: "hasFullAccess")
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("نقرة")
                        .font(.largeTitle.bold())
                    Text("لوحة مفاتيح عربية وإنجليزية، مع ترجمة بين العربية والإنجليزية على iOS 18.")
                        .foregroundStyle(.secondary)

                    if !hasFullAccess {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("الوصول الكامل غير مفعّل")
                                .font(.headline)
                            Text("النسخ واللصق والترجمة يحتاجون الوصول الكامل. فعّله من إعدادات لوحة المفاتيح ثم ارجع هنا.")
                                .font(.subheadline)
                        }
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.orange.opacity(0.15))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("تفعيل اللوحة")
                            .font(.headline)
                        Text("1. الإعدادات → عام → لوحة المفاتيح → لوحات المفاتيح.")
                        Text("2. أضف لوحة مفاتيح ثم اختر نقرة.")
                        Text("3. اضغط نقرة وفعّل السماح بالوصول الكامل.")
                        Text("4. افتح حقلاً للكتابة واختر نقرة من لوحات النظام.")
                        Text("مسافتان سريعتان خلال 0.36 ثانية تبدّلان العربية والإنجليزية.")
                            .padding(.top, 4)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.secondary.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 12))

                    if #available(iOS 18.0, *) {
                        TranslationPrepCard()
                    } else {
                        Text("تجهيز الترجمة يحتاج iOS 18 أو أحدث.")
                            .foregroundStyle(.secondary)
                    }
                }
                .padding()
            }
            .navigationTitle("نقرة")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

@available(iOS 18.0, *)
struct TranslationPrepCard: View {
    @State private var status = "جاري فحص حزم الترجمة…"
    @State private var token = 0

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("تجهيز ترجمة iOS 18")
                .font(.headline)
            Text(status)
                .font(.subheadline)
            Text("الترجمة داخل اللوحة بين العربية والإنجليزية فقط.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.blue.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .task {
            let availability = LanguageAvailability()
            let arEn = await availability.status(
                from: Locale.Language(identifier: "ar"),
                to: Locale.Language(identifier: "en")
            )
            let enAr = await availability.status(
                from: Locale.Language(identifier: "en"),
                to: Locale.Language(identifier: "ar")
            )
            status = statusText(arEn: arEn, enAr: enAr)
            token += 1
        }
        .translationTask(
            TranslationSession.Configuration(
                source: Locale.Language(identifier: "ar"),
                target: Locale.Language(identifier: "en")
            )
        ) { session in
            _ = session
        }
        .id(token)
    }

    private func statusText(arEn: LanguageAvailability.Status, enAr: LanguageAvailability.Status) -> String {
        switch (arEn, enAr) {
        case (.installed, .installed):
            return "حزم العربية والإنجليزية جاهزة."
        case (.unsupported, _), (_, .unsupported):
            return "الجهاز لا يدعم هذه الزوج من اللغات."
        default:
            return "اللغات مدعومة. قد ينزّل iOS الحزم عند أول ترجمة."
        }
    }
}