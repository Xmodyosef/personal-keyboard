import SwiftUI
import Translation
import UIKit

enum KeyboardLanguage { case arabic, english }
enum KeyboardPage { case letters, symbols, emoji }

final class TranslationBridgeModel: ObservableObject {
    @Published var sourceText = ""
    @Published var token = 0
    var sourceLang = "ar"
    var targetLang = "en"
    var onResult: ((String) -> Void)?
}

struct TranslationBridgeView: View {
    @ObservedObject var model: TranslationBridgeModel
    var body: some View {
        Group {
            if #available(iOS 18.0, *) {
                Color.clear.frame(width: 1, height: 1)
                    .translationTask(
                        TranslationSession.Configuration(
                            source: Locale.Language(identifier: model.sourceLang),
                            target: Locale.Language(identifier: model.targetLang)
                        )
                    ) { session in
                        let text = model.sourceText
                        guard !text.isEmpty else { return }
                        do {
                            let response = try await session.translate(text)
                            await MainActor.run {
                                model.onResult?(response.targetText)
                            }
                        } catch {}
                    }
                    .id(model.token)
            }
        }
    }
}

struct NaqraPalette {
    var background: UIColor
    var key: UIColor
    var text: UIColor
    var accent: UIColor
    var blurDark: Bool

    static let order = [
        "auto", "light", "dark", "glass", "ocean", "cobalt", "violet",
        "orchid", "hailey", "ember", "forest", "matrix", "nord", "custom"
    ]
    static let titles = [
        "auto": "تلقائي",
        "light": "فاتح",
        "dark": "داكن",
        "glass": "منشور",
        "ocean": "بحر",
        "cobalt": "كوبالت",
        "violet": "بنفسج",
        "orchid": "أوركيد",
        "hailey": "دم",
        "ember": "جمر",
        "forest": "غابة",
        "matrix": "ماتريكس",
        "nord": "نورد",
        "custom": "مخصص"
    ]

    static func current() -> NaqraPalette {
        let suite = UserDefaults(suiteName: "group.app.personal.PersonalKeyboard")
        let raw = suite?.string(forKey: "themeId")
            ?? UserDefaults.standard.string(forKey: "themeId")
            ?? "dark"
        let id = normalizeThemeId(raw)
        if id == "custom" { return customPalette() }
        if id == "auto" {
            let dark = UITraitCollection.current.userInterfaceStyle == .dark
            return preset(dark ? "dark" : "light")
        }
        return preset(id)
    }

    static func preset(_ id: String) -> NaqraPalette {
        switch id {
        case "light":
            return .init(
                background: .clear,
                key: UIColor(red: 0.90, green: 0.95, blue: 0.99, alpha: 0.82),
                text: UIColor(red: 0.14, green: 0.27, blue: 0.40, alpha: 1),
                accent: UIColor(red: 0.28, green: 0.52, blue: 0.86, alpha: 1),
                blurDark: false
            )
        case "glass":
            return .init(
                background: .clear,
                key: UIColor(red: 0.86, green: 0.82, blue: 0.96, alpha: 0.38),
                text: UIColor(red: 0.18, green: 0.16, blue: 0.28, alpha: 1),
                accent: UIColor(red: 0.62, green: 0.42, blue: 0.88, alpha: 1),
                blurDark: false
            )
        case "ocean":
            return .init(
                background: .clear,
                key: UIColor(red: 0.06, green: 0.22, blue: 0.32, alpha: 0.55),
                text: UIColor(red: 0.62, green: 0.96, blue: 0.98, alpha: 1),
                accent: UIColor(red: 0.16, green: 0.78, blue: 0.84, alpha: 1),
                blurDark: true
            )
        case "cobalt":
            return .init(
                background: .clear,
                key: UIColor(red: 0.10, green: 0.18, blue: 0.42, alpha: 0.62),
                text: UIColor(red: 0.82, green: 0.90, blue: 1.0, alpha: 1),
                accent: UIColor(red: 0.32, green: 0.56, blue: 1.0, alpha: 1),
                blurDark: true
            )
        case "violet":
            return .init(
                background: .clear,
                key: UIColor(red: 0.18, green: 0.10, blue: 0.32, alpha: 0.50),
                text: UIColor(red: 0.90, green: 0.78, blue: 1.0, alpha: 1),
                accent: UIColor(red: 0.70, green: 0.42, blue: 1.0, alpha: 1),
                blurDark: true
            )
        case "orchid":
            return .init(
                background: .clear,
                key: UIColor(red: 0.32, green: 0.08, blue: 0.18, alpha: 0.58),
                text: UIColor(red: 1.0, green: 0.78, blue: 0.86, alpha: 1),
                accent: UIColor(red: 0.92, green: 0.32, blue: 0.52, alpha: 1),
                blurDark: true
            )
        case "hailey":
            return .init(
                background: .clear,
                key: UIColor(red: 0.22, green: 0.05, blue: 0.08, alpha: 0.58),
                text: UIColor(red: 1.0, green: 0.78, blue: 0.80, alpha: 1),
                accent: UIColor(red: 0.86, green: 0.16, blue: 0.22, alpha: 1),
                blurDark: true
            )
        case "ember":
            return .init(
                background: .clear,
                key: UIColor(red: 0.24, green: 0.12, blue: 0.05, alpha: 0.58),
                text: UIColor(red: 1.0, green: 0.84, blue: 0.58, alpha: 1),
                accent: UIColor(red: 0.96, green: 0.50, blue: 0.18, alpha: 1),
                blurDark: true
            )
        case "forest":
            return .init(
                background: .clear,
                key: UIColor(red: 0.06, green: 0.18, blue: 0.12, alpha: 0.58),
                text: UIColor(red: 0.70, green: 0.96, blue: 0.76, alpha: 1),
                accent: UIColor(red: 0.22, green: 0.78, blue: 0.42, alpha: 1),
                blurDark: true
            )
        case "matrix":
            return .init(
                background: .clear,
                key: UIColor(red: 0.02, green: 0.07, blue: 0.03, alpha: 0.62),
                text: UIColor(red: 0.28, green: 0.98, blue: 0.36, alpha: 1),
                accent: UIColor(red: 0.12, green: 0.78, blue: 0.22, alpha: 1),
                blurDark: true
            )
        case "nord":
            return .init(
                background: .clear,
                key: UIColor(red: 0.78, green: 0.82, blue: 0.86, alpha: 0.72),
                text: UIColor(red: 0.16, green: 0.20, blue: 0.26, alpha: 1),
                accent: UIColor(red: 0.36, green: 0.56, blue: 0.70, alpha: 1),
                blurDark: false
            )
        default:
            return .init(
                background: .clear,
                key: UIColor(red: 0.10, green: 0.16, blue: 0.28, alpha: 0.62),
                text: UIColor(red: 0.93, green: 0.96, blue: 1.0, alpha: 1),
                accent: UIColor(red: 0.36, green: 0.60, blue: 1.0, alpha: 1),
                blurDark: true
            )
        }
    }

    static func customPalette() -> NaqraPalette {
        let key = storedColor("customKey") ?? UIColor(white: 1.0, alpha: 0.16)
        let text = storedColor("customText") ?? UIColor(white: 0.96, alpha: 1)
        let accent = storedColor("customAccent") ?? UIColor(red: 0.55, green: 0.62, blue: 0.70, alpha: 1)
        let dark = storedBool("customBlurDark") ?? true
        return .init(
            background: .clear,
            key: key,
            text: text,
            accent: accent,
            blurDark: dark
        )
    }

    static func storedColor(_ key: String) -> UIColor? {
        let suite = UserDefaults(suiteName: "group.app.personal.PersonalKeyboard")
        let raw = suite?.string(forKey: key)
            ?? UserDefaults.standard.string(forKey: key)
        guard let raw else { return nil }
        let p = raw.split(separator: ",").compactMap { Double($0) }
        guard p.count == 4 else { return nil }
        return UIColor(
            red: CGFloat(p[0]),
            green: CGFloat(p[1]),
            blue: CGFloat(p[2]),
            alpha: CGFloat(p[3])
        )
    }

    static func storedBool(_ key: String) -> Bool? {
        let suite = UserDefaults(suiteName: "group.app.personal.PersonalKeyboard")
        if suite?.object(forKey: key) != nil {
            return suite?.bool(forKey: key)
        }
        if UserDefaults.standard.object(forKey: key) != nil {
            return UserDefaults.standard.bool(forKey: key)
        }
        return nil
    }

    static func saveColor(_ color: UIColor, key: String) {
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        color.getRed(&r, green: &g, blue: &b, alpha: &a)
        let raw = "\(r),\(g),\(b),\(a)"
        let suite = UserDefaults(suiteName: "group.app.personal.PersonalKeyboard")
        suite?.set(raw, forKey: key)
        UserDefaults.standard.set(raw, forKey: key)
    }

    static func saveTheme(_ id: String) {
        let suite = UserDefaults(suiteName: "group.app.personal.PersonalKeyboard")
        suite?.set(id, forKey: "themeId")
        UserDefaults.standard.set(id, forKey: "themeId")
    }

    static func normalizeThemeId(_ raw: String) -> String {
        switch raw {
        case "charcoal", "smoke": return "dark"
        case "teal": return "ocean"
        case "midnight": return "cobalt"
        case "snow": return "light"
        case "clear": return "glass"
        default: return raw
        }
    }

    static func saveBool(_ value: Bool, key: String) {
        let suite = UserDefaults(suiteName: "group.app.personal.PersonalKeyboard")
        suite?.set(value, forKey: key)
        UserDefaults.standard.set(value, forKey: key)
    }

    static func applyHarmony(from base: UIColor) {
        let lum = luminance(base)
        let darkGlass = lum < 0.55
        let text = darkGlass
            ? UIColor(white: 0.97, alpha: 1)
            : UIColor(red: 0.16, green: 0.20, blue: 0.26, alpha: 1)
        let accent = relatedAccent(base, dark: darkGlass)
        saveColor(base, key: "customKey")
        saveColor(text, key: "customText")
        saveColor(accent, key: "customAccent")
        saveBool(darkGlass, key: "customBlurDark")
        saveTheme("custom")
    }

    static func luminance(_ color: UIColor) -> CGFloat {
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        color.getRed(&r, green: &g, blue: &b, alpha: &a)
        return 0.2126 * r + 0.7152 * g + 0.0722 * b
    }

    static func relatedAccent(_ color: UIColor, dark: Bool) -> UIColor {
        var h: CGFloat = 0
        var s: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        if color.getHue(&h, saturation: &s, brightness: &b, alpha: &a) {
            let ns = min(0.55, max(0.18, s * 0.75))
            let nb = dark ? min(0.86, max(0.55, b + 0.28)) : min(0.62, max(0.38, b * 0.72))
            return UIColor(hue: h, saturation: ns, brightness: nb, alpha: 1)
        }
        return dark
            ? UIColor(red: 0.55, green: 0.62, blue: 0.70, alpha: 1)
            : UIColor(red: 0.42, green: 0.58, blue: 0.74, alpha: 1)
    }
}

final class KeyboardViewController: UIInputViewController, UIScrollViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    private let suite = UserDefaults(suiteName: "group.app.personal.PersonalKeyboard")
    private var language: KeyboardLanguage = .arabic
    private var page: KeyboardPage = .letters
    private var isShifted = false
    private var symbolPageIndex = 0
    private var emojiCategoryIndex = 0
    private var palette = NaqraPalette.current()
    private var colorSlot = 0
    private var themePanel: UIView?

    private let blurView = UIVisualEffectView(effect: UIBlurEffect(style: .systemUltraThinMaterialDark))
    private let rootStack = UIStackView()
    private var heightConstraint: NSLayoutConstraint?
    private var deleteTimer: Timer?
    private var lastSpaceTap: Date?
    private let spaceSwitchInterval: TimeInterval = 0.36
    private var spaceStart: CGPoint = .zero
    private var spaceIsTrackpad = false
    private var lastTrackpadX: CGFloat = 0
    private var holdTimer: Timer?
    private var holdSource: UIButton?
    private var holdPopup: UIView?
    private var holdChoice = ""

    private let translationModel = TranslationBridgeModel()
    private var translationHost: UIHostingController<TranslationBridgeView>?
    private var emojiPager: UIScrollView?
    private var emojiTabs: UIStackView?

    private let letterFont = UIFont.systemFont(ofSize: 22, weight: .medium)
    private let iconConfig = UIImage.SymbolConfiguration(pointSize: 13, weight: .semibold)
    private let boardHeight: CGFloat = 268

    private let paintWells: [UIColor] = [
        UIColor(white: 0.08, alpha: 0.92),
        UIColor(white: 0.96, alpha: 0.92),
        UIColor(red: 0.82, green: 0.88, blue: 0.94, alpha: 0.92),
        UIColor(red: 0.07, green: 0.22, blue: 0.30, alpha: 0.92),
        UIColor(red: 0.16, green: 0.04, blue: 0.06, alpha: 0.92),
        UIColor(red: 0.18, green: 0.24, blue: 0.32, alpha: 1),
        UIColor(red: 0.82, green: 0.94, blue: 0.96, alpha: 1),
        UIColor(red: 0.98, green: 0.86, blue: 0.86, alpha: 1),
        UIColor(red: 0.22, green: 0.72, blue: 0.78, alpha: 1),
        UIColor(red: 0.72, green: 0.14, blue: 0.18, alpha: 1),
        UIColor(red: 0.42, green: 0.62, blue: 0.82, alpha: 1),
        UIColor(red: 0.55, green: 0.62, blue: 0.70, alpha: 1)
    ]

    private let arabicRows = [
        ["ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج"],
        ["ش","س","ي","ب","ل","ا","ت","ن","م","ك","ة"],
        ["،","ئ","ظ","ط","ذ","د","ز","ر","و"]
    ]
    private let arabicShiftRows = [
        ["َ","ً","ُ","ٌ","ِ","ٍ","ْ","ّ","ـ","ٰ","ٓ"],
        ["أ","إ","آ","ى","ء","ؤ","لا","لآ","لأ","لإ","ة"],
        ["،","؛","؟","٪","…","ـ","ى","ئ"]
    ]
    private let englishLower = [
        ["q","w","e","r","t","y","u","i","o","p"],
        ["a","s","d","f","g","h","j","k","l"],
        ["z","x","c","v","b","n","m"]
    ]
    private let englishUpper = [
        ["Q","W","E","R","T","Y","U","I","O","P"],
        ["A","S","D","F","G","H","J","K","L"],
        ["Z","X","C","V","B","N","M"]
    ]
    private let numberRow = ["1","2","3","4","5","6","7","8","9","0"]
    private let symbolPages = [
        [["-","/",":",";","(",")","$","&","@","\""],[".",",","?","!","'","*","+","=","#"],["%","^","_","\\","|","~","`"]],
        [["[","]","{","}","<",">","«","»"],["€","£","¥","₽","٪","،","؛","؟"],["…","–","—","•","×","÷","﴾","﴿"]]
    ]
    private let emojiPack: [(icon: String, items: [String])] = KeyboardViewController.catalog()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        configureRoot()
        attachBridge()
        translationModel.onResult = { [weak self] t in self?.applyTranslation(t) }
        rebuild()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        persistAccess()
        palette = NaqraPalette.current()
        rebuild()
    }

    override func updateViewConstraints() {
        if heightConstraint == nil {
            let c = view.heightAnchor.constraint(equalToConstant: boardHeight)
            c.priority = .defaultHigh
            c.isActive = true
            heightConstraint = c
        }
        super.updateViewConstraints()
    }

    private func persistAccess() {
        suite?.set(hasFullAccess, forKey: "hasFullAccess")
        UserDefaults.standard.set(hasFullAccess, forKey: "hasFullAccess")
    }
    private var hapticsOn: Bool { suite?.object(forKey: "haptics") as? Bool ?? UserDefaults.standard.object(forKey: "haptics") as? Bool ?? true }
    private var trackpadOn: Bool { suite?.object(forKey: "trackpad") as? Bool ?? UserDefaults.standard.object(forKey: "trackpad") as? Bool ?? true }

    private func tapHaptic() {
        guard hapticsOn else { return }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    private func configureRoot() {
        blurView.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(blurView, at: 0)
        NSLayoutConstraint.activate([
            blurView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            blurView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            blurView.topAnchor.constraint(equalTo: view.topAnchor),
            blurView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        rootStack.axis = .vertical
        rootStack.spacing = 4
        rootStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(rootStack)
        NSLayoutConstraint.activate([
            rootStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 5),
            rootStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -5),
            rootStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 6),
            rootStack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -4)
        ])
    }

    private func attachBridge() {
        let host = UIHostingController(rootView: TranslationBridgeView(model: translationModel))
        translationHost = host
        addChild(host)
        host.view.backgroundColor = .clear
        host.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(host.view)
        NSLayoutConstraint.activate([
            host.view.widthAnchor.constraint(equalToConstant: 1),
            host.view.heightAnchor.constraint(equalToConstant: 1),
            host.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            host.view.topAnchor.constraint(equalTo: view.topAnchor)
        ])
        host.didMove(toParent: self)
    }

    private func rebuild() {
        palette = NaqraPalette.current()
        view.backgroundColor = .clear
        blurView.effect = UIBlurEffect(style: palette.blurDark ? .systemUltraThinMaterialDark : .systemUltraThinMaterialLight)
        blurView.backgroundColor = .clear
        rootStack.arrangedSubviews.forEach { rootStack.removeArrangedSubview($0); $0.removeFromSuperview() }
        heightConstraint?.constant = boardHeight
        rootStack.addArrangedSubview(makeToolbar())
        switch page {
        case .letters:
            rootStack.addArrangedSubview(makeRow(numberRow, rtl: false))
            let rows = language == .arabic ? (isShifted ? arabicShiftRows : arabicRows) : (isShifted ? englishUpper : englishLower)
            for (i, row) in rows.enumerated() {
                if i == rows.count - 1 { rootStack.addArrangedSubview(makeLastLetterRow(row)) }
                else { rootStack.addArrangedSubview(makeRow(row, rtl: false)) }
            }
            rootStack.addArrangedSubview(makeBottom(title: "#+="))
        case .symbols:
            let rows = symbolPages[min(symbolPageIndex, 1)]
            for (i, row) in rows.enumerated() {
                if i == rows.count - 1 { rootStack.addArrangedSubview(makeSymbolLastRow(row)) }
                else { rootStack.addArrangedSubview(makeRow(row, rtl: false)) }
            }
            rootStack.addArrangedSubview(makeBottom(title: symbolPageIndex == 0 ? "1/2" : "2/2", letters: true))
        case .emoji:
            rootStack.addArrangedSubview(makeEmojiTabs())
            rootStack.addArrangedSubview(makeEmojiPager())
            rootStack.addArrangedSubview(makeBottom(title: "#+=", letters: true, emojiOn: true))
        }
    }

    private func makeToolbar() -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 5
        s.distribution = .fillEqually
        s.semanticContentAttribute = .forceLeftToRight
        s.addArrangedSubview(iconKey("doc.on.doc", #selector(copyTapped)))
        s.addArrangedSubview(iconKey("doc.on.clipboard", #selector(pasteTapped)))
        s.addArrangedSubview(iconKey("translate", #selector(translateTapped)))
        s.addArrangedSubview(iconKey("paintpalette", #selector(themeMenuTapped)))
        s.heightAnchor.constraint(equalToConstant: 28).isActive = true
        return s
    }

    @objc private func themeMenuTapped() {
        if themePanel != nil {
            hideThemePanel()
            return
        }
        showThemePanel()
        tapHaptic()
    }

    private func showThemePanel() {
        hideThemePanel()
        let overlay = UIView()
        overlay.translatesAutoresizingMaskIntoConstraints = false
        overlay.backgroundColor = UIColor.black.withAlphaComponent(0.28)
        let tap = UITapGestureRecognizer(target: self, action: #selector(themeMenuTapped))
        tap.cancelsTouchesInView = false
        overlay.addGestureRecognizer(tap)

        let card = UIView()
        card.translatesAutoresizingMaskIntoConstraints = false
        card.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        card.layer.cornerRadius = 16
        card.layer.cornerCurve = .continuous
        card.layer.borderWidth = 0.6
        card.layer.borderColor = UIColor.white.withAlphaComponent(0.18).cgColor

        let col = UIStackView()
        col.axis = .vertical
        col.spacing = 8
        col.translatesAutoresizingMaskIntoConstraints = false

        let title = UILabel()
        title.text = "الثيمات"
        title.textAlignment = .center
        title.textColor = .white
        title.font = .systemFont(ofSize: 13, weight: .semibold)
        col.addArrangedSubview(title)

        let current = suite?.string(forKey: "themeId") ?? UserDefaults.standard.string(forKey: "themeId") ?? "dark"
        let rows = UIStackView()
        rows.axis = .vertical
        rows.spacing = 6
        let chunk = 7
        var start = 0
        while start < NaqraPalette.order.count {
            let line = UIStackView()
            line.axis = .horizontal
            line.spacing = 5
            line.distribution = .fillEqually
            let end = min(start + chunk, NaqraPalette.order.count)
            for i in start..<end {
                let id = NaqraPalette.order[i]
                let b = UIButton(type: .system)
                b.tag = i
                b.setTitle(NaqraPalette.titles[id], for: .normal)
                b.titleLabel?.font = .systemFont(ofSize: 10, weight: .semibold)
                let sample = themeInk(id)
                b.setTitleColor(sample, for: .normal)
                b.backgroundColor = previewColor(id)
                b.layer.cornerRadius = 10
                b.layer.cornerCurve = .continuous
                b.layer.borderWidth = id == current ? 2 : 0.4
                b.layer.borderColor = UIColor.white.cgColor
                b.heightAnchor.constraint(equalToConstant: 30).isActive = true
                b.addTarget(self, action: #selector(presetTapped(_:)), for: .touchUpInside)
                line.addArrangedSubview(b)
            }
            rows.addArrangedSubview(line)
            start = end
        }
        col.addArrangedSubview(rows)

        let edit = UILabel()
        edit.text = "تعديل الألوان"
        edit.textAlignment = .center
        edit.textColor = UIColor.white.withAlphaComponent(0.86)
        edit.font = .systemFont(ofSize: 12, weight: .medium)
        col.addArrangedSubview(edit)

        let slots = UIStackView()
        slots.axis = .horizontal
        slots.spacing = 6
        slots.distribution = .fillEqually
        let names = ["مفتاح", "نص", "تمييز"]
        for i in 0..<3 {
            let b = UIButton(type: .system)
            b.tag = i
            b.setTitle(names[i], for: .normal)
            b.titleLabel?.font = .systemFont(ofSize: 12, weight: .semibold)
            b.setTitleColor(.white, for: .normal)
            b.backgroundColor = slotColor(i).withAlphaComponent(0.95)
            b.layer.cornerRadius = 10
            b.layer.borderWidth = colorSlot == i ? 2 : 0.4
            b.layer.borderColor = UIColor.white.cgColor
            b.heightAnchor.constraint(equalToConstant: 30).isActive = true
            b.addTarget(self, action: #selector(slotTapped(_:)), for: .touchUpInside)
            slots.addArrangedSubview(b)
        }
        col.addArrangedSubview(slots)

        let wells = UIStackView()
        wells.axis = .horizontal
        wells.spacing = 5
        wells.distribution = .fillEqually
        for (i, color) in paintWells.enumerated() {
            let b = UIButton(type: .system)
            b.tag = i
            b.backgroundColor = color
            b.layer.cornerRadius = 11
            b.layer.borderWidth = 0.6
            b.layer.borderColor = UIColor.white.withAlphaComponent(0.35).cgColor
            b.heightAnchor.constraint(equalToConstant: 22).isActive = true
            b.addTarget(self, action: #selector(wellTapped(_:)), for: .touchUpInside)
            wells.addArrangedSubview(b)
        }
        col.addArrangedSubview(wells)

        let glass = UIStackView()
        glass.axis = .horizontal
        glass.spacing = 6
        glass.distribution = .fillEqually
        glass.addArrangedSubview(miniControl("زجاج داكن", #selector(darkGlassTapped)))
        glass.addArrangedSubview(miniControl("زجاج فاتح", #selector(lightGlassTapped)))
        glass.addArrangedSubview(miniControl("تم", #selector(themeMenuTapped)))
        col.addArrangedSubview(glass)

        card.addSubview(col)
        overlay.addSubview(card)
        view.addSubview(overlay)
        themePanel = overlay
        NSLayoutConstraint.activate([
            overlay.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            overlay.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            overlay.topAnchor.constraint(equalTo: view.topAnchor),
            overlay.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            card.leadingAnchor.constraint(equalTo: overlay.leadingAnchor, constant: 8),
            card.trailingAnchor.constraint(equalTo: overlay.trailingAnchor, constant: -8),
            card.topAnchor.constraint(equalTo: overlay.topAnchor, constant: 8),
            col.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 10),
            col.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -10),
            col.topAnchor.constraint(equalTo: card.topAnchor, constant: 10),
            col.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -10)
        ])
    }

    private func hideThemePanel() {
        themePanel?.removeFromSuperview()
        themePanel = nil
    }

    private func miniControl(_ title: String, _ action: Selector) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(title, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 12, weight: .semibold)
        b.setTitleColor(.white, for: .normal)
        b.backgroundColor = UIColor.white.withAlphaComponent(0.14)
        b.layer.cornerRadius = 10
        b.heightAnchor.constraint(equalToConstant: 28).isActive = true
        b.addTarget(self, action: action, for: .touchUpInside)
        return b
    }

    private func previewColor(_ id: String) -> UIColor {
        if id == "custom" { return NaqraPalette.customPalette().key }
        if id == "auto" { return UIColor(white: 0.28, alpha: 1) }
        return NaqraPalette.preset(id).key.withAlphaComponent(0.95)
    }

    private func themeInk(_ id: String) -> UIColor {
        if id == "custom" { return NaqraPalette.customPalette().text }
        if id == "auto" { return .white }
        return NaqraPalette.preset(id).text
    }

    private func slotColor(_ i: Int) -> UIColor {
        switch i {
        case 1: return palette.text
        case 2: return palette.accent
        default: return palette.key
        }
    }

    @objc private func presetTapped(_ sender: UIButton) {
        let id = NaqraPalette.order[min(max(sender.tag, 0), NaqraPalette.order.count - 1)]
        NaqraPalette.saveTheme(id)
        hideThemePanel()
        rebuild()
        tapHaptic()
    }

    @objc private func slotTapped(_ sender: UIButton) {
        colorSlot = sender.tag
        hideThemePanel()
        showThemePanel()
        tapHaptic()
    }

    @objc private func wellTapped(_ sender: UIButton) {
        let color = paintWells[min(max(sender.tag, 0), paintWells.count - 1)]
        if colorSlot == 0 {
            NaqraPalette.applyHarmony(from: color)
        } else if colorSlot == 1 {
            NaqraPalette.saveColor(color, key: "customText")
            NaqraPalette.saveTheme("custom")
        } else {
            NaqraPalette.saveColor(color, key: "customAccent")
            NaqraPalette.saveTheme("custom")
        }
        hideThemePanel()
        rebuild()
        DispatchQueue.main.async { [weak self] in self?.showThemePanel() }
        tapHaptic()
    }

    @objc private func darkGlassTapped() {
        NaqraPalette.saveBool(true, key: "customBlurDark")
        NaqraPalette.saveTheme("custom")
        hideThemePanel()
        rebuild()
        tapHaptic()
    }

    @objc private func lightGlassTapped() {
        NaqraPalette.saveBool(false, key: "customBlurDark")
        NaqraPalette.saveTheme("custom")
        hideThemePanel()
        rebuild()
        tapHaptic()
    }

    private func makeRow(_ keys: [String], rtl: Bool) -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 5
        s.distribution = .fillEqually
        s.semanticContentAttribute = rtl ? .forceRightToLeft : .forceLeftToRight
        keys.forEach { s.addArrangedSubview(charKey($0)) }
        s.heightAnchor.constraint(equalToConstant: 42).isActive = true
        return s
    }

    private func makeLastLetterRow(_ keys: [String]) -> UIView {
        return makeActionRow(keys, leadingShift: language == .english)
    }

    private func makeSymbolLastRow(_ keys: [String]) -> UIView {
        return makeActionRow(keys, leadingShift: false)
    }

    private func makeActionRow(_ keys: [String], leadingShift: Bool) -> UIView {
        let wrap = UIStackView()
        wrap.axis = .horizontal
        wrap.spacing = 5
        wrap.semanticContentAttribute = .forceLeftToRight
        if leadingShift {
            let shift = iconKey(isShifted ? "shift.fill" : "shift", #selector(shiftTapped))
            shift.widthAnchor.constraint(equalToConstant: 40).isActive = true
            paint(shift, emphasized: isShifted)
            wrap.addArrangedSubview(shift)
        }
        let mid = UIStackView()
        mid.axis = .horizontal
        mid.spacing = 5
        mid.distribution = .fillEqually
        mid.semanticContentAttribute = .forceLeftToRight
        keys.forEach { mid.addArrangedSubview(charKey($0)) }
        wrap.addArrangedSubview(mid)
        wrap.addArrangedSubview(makeHideKey())
        wrap.addArrangedSubview(makeDeleteKey())
        wrap.heightAnchor.constraint(equalToConstant: 42).isActive = true
        return wrap
    }

    private func makeDeleteKey() -> UIButton {
        let del = iconKey("delete.left", #selector(deleteTouchUp))
        del.addTarget(self, action: #selector(deleteTouchDown), for: .touchDown)
        del.addTarget(self, action: #selector(deleteTouchCancel), for: [.touchUpOutside, .touchCancel])
        del.widthAnchor.constraint(equalToConstant: 38).isActive = true
        return del
    }

    private func makeHideKey() -> UIButton {
        let hide = iconKey("keyboard.chevron.compact.down", #selector(dismissKeyboardAction))
        hide.widthAnchor.constraint(equalToConstant: 38).isActive = true
        return hide
    }

    private func makeBottom(title: String, letters: Bool = false, emojiOn: Bool = false) -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 5
        s.semanticContentAttribute = .forceLeftToRight
        let emoji = control(emojiOn ? "😊" : "🙂", #selector(emojiTapped), font: 18)
        let midTitle: String
        if page == .symbols {
            midTitle = title
        } else if page == .emoji || letters {
            midTitle = language == .arabic ? "عربي" : "ABC"
        } else {
            midTitle = title
        }
        let symbols = control(midTitle, #selector(symbolsOrLettersTapped), font: 13)
        let space = control("مسافة", #selector(spaceTouchUp), font: 14)
        space.addTarget(self, action: #selector(spaceTouchDown(_:event:)), for: .touchDown)
        space.addTarget(self, action: #selector(spaceDrag(_:event:)), for: .touchDragInside)
        space.addTarget(self, action: #selector(spaceDrag(_:event:)), for: .touchDragOutside)
        let enter = control("إدخال", #selector(enterTapped), font: 13)
        emoji.widthAnchor.constraint(equalToConstant: 42).isActive = true
        symbols.widthAnchor.constraint(equalToConstant: 52).isActive = true
        enter.widthAnchor.constraint(equalToConstant: 58).isActive = true
        space.setContentHuggingPriority(.defaultLow, for: .horizontal)
        space.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        s.addArrangedSubview(emoji)
        s.addArrangedSubview(symbols)
        s.addArrangedSubview(space)
        if emojiOn {
            s.addArrangedSubview(makeDeleteKey())
        } else {
            let period = control(".", #selector(periodTapped), font: 20)
            period.widthAnchor.constraint(equalToConstant: 36).isActive = true
            s.addArrangedSubview(period)
        }
        s.addArrangedSubview(enter)
        s.heightAnchor.constraint(equalToConstant: 36).isActive = true
        return s
    }

    private func makeEmojiTabs() -> UIView {
        let wrap = UIStackView()
        wrap.axis = .horizontal
        wrap.spacing = 5
        wrap.semanticContentAttribute = .forceLeftToRight
        let scroller = UIScrollView()
        scroller.showsHorizontalScrollIndicator = false
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 4
        s.translatesAutoresizingMaskIntoConstraints = false
        scroller.addSubview(s)
        emojiTabs = s
        for (i, pack) in emojiPack.enumerated() {
            let b = control(pack.icon, #selector(emojiTab(_:)), font: 18)
            b.tag = i
            b.backgroundColor = i == emojiCategoryIndex ? UIColor.white.withAlphaComponent(0.22) : .clear
            b.widthAnchor.constraint(equalToConstant: 38).isActive = true
            s.addArrangedSubview(b)
        }
        NSLayoutConstraint.activate([
            s.leadingAnchor.constraint(equalTo: scroller.contentLayoutGuide.leadingAnchor, constant: 2),
            s.trailingAnchor.constraint(equalTo: scroller.contentLayoutGuide.trailingAnchor, constant: -2),
            s.topAnchor.constraint(equalTo: scroller.contentLayoutGuide.topAnchor),
            s.bottomAnchor.constraint(equalTo: scroller.contentLayoutGuide.bottomAnchor),
            s.heightAnchor.constraint(equalTo: scroller.frameLayoutGuide.heightAnchor)
        ])
        wrap.addArrangedSubview(scroller)
        wrap.heightAnchor.constraint(equalToConstant: 32).isActive = true
        return wrap
    }

    private func makeEmojiPager() -> UIView {
        let pager = UIScrollView()
        pager.isPagingEnabled = true
        pager.showsHorizontalScrollIndicator = false
        pager.delegate = self
        pager.translatesAutoresizingMaskIntoConstraints = false
        emojiPager = pager
        let host = UIView()
        host.translatesAutoresizingMaskIntoConstraints = false
        pager.addSubview(host)
        NSLayoutConstraint.activate([
            host.topAnchor.constraint(equalTo: pager.contentLayoutGuide.topAnchor),
            host.bottomAnchor.constraint(equalTo: pager.contentLayoutGuide.bottomAnchor),
            host.leadingAnchor.constraint(equalTo: pager.contentLayoutGuide.leadingAnchor),
            host.trailingAnchor.constraint(equalTo: pager.contentLayoutGuide.trailingAnchor),
            host.heightAnchor.constraint(equalTo: pager.frameLayoutGuide.heightAnchor)
        ])
        var previous: UIView?
        for i in 0..<emojiPack.count {
            let layout = UICollectionViewFlowLayout()
            layout.minimumInteritemSpacing = 2
            layout.minimumLineSpacing = 2
            layout.sectionInset = UIEdgeInsets(top: 2, left: 2, bottom: 2, right: 2)
            let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
            cv.backgroundColor = .clear
            cv.dataSource = self
            cv.delegate = self
            cv.tag = i
            cv.register(EmojiCell.self, forCellWithReuseIdentifier: "e")
            cv.translatesAutoresizingMaskIntoConstraints = false
            host.addSubview(cv)
            NSLayoutConstraint.activate([
                cv.topAnchor.constraint(equalTo: host.topAnchor),
                cv.bottomAnchor.constraint(equalTo: host.bottomAnchor),
                cv.widthAnchor.constraint(equalTo: pager.frameLayoutGuide.widthAnchor),
                cv.heightAnchor.constraint(equalTo: host.heightAnchor)
            ])
            if let previous {
                cv.leadingAnchor.constraint(equalTo: previous.trailingAnchor).isActive = true
            } else {
                cv.leadingAnchor.constraint(equalTo: host.leadingAnchor).isActive = true
            }
            if i == emojiPack.count - 1 {
                cv.trailingAnchor.constraint(equalTo: host.trailingAnchor).isActive = true
            }
            previous = cv
        }
        DispatchQueue.main.async { [weak self] in
            guard let self, let pager = self.emojiPager else { return }
            pager.setContentOffset(CGPoint(x: CGFloat(self.emojiCategoryIndex) * pager.bounds.width, y: 0), animated: false)
        }
        return pager
    }

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        guard scrollView === emojiPager, scrollView.bounds.width > 0 else { return }
        let idx = Int(round(scrollView.contentOffset.x / scrollView.bounds.width))
        emojiCategoryIndex = min(max(idx, 0), emojiPack.count - 1)
        refreshTabs()
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        emojiPack[collectionView.tag].items.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "e", for: indexPath) as! EmojiCell
        cell.label.text = emojiPack[collectionView.tag].items[indexPath.item]
        cell.paint(palette)
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        textDocumentProxy.insertText(emojiPack[collectionView.tag].items[indexPath.item])
        tapHaptic()
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cols: CGFloat = 8
        let w = floor((collectionView.bounds.width - 4 - (cols - 1) * 2) / cols)
        return CGSize(width: max(w, 28), height: max(w, 32))
    }

    private func refreshTabs() {
        guard let tabs = emojiTabs else { return }
        for (i, view) in tabs.arrangedSubviews.enumerated() {
            view.backgroundColor = i == emojiCategoryIndex ? UIColor.white.withAlphaComponent(0.22) : .clear
        }
    }

    @objc private func emojiTab(_ sender: UIButton) {
        emojiCategoryIndex = sender.tag
        refreshTabs()
        guard let pager = emojiPager else { return }
        pager.setContentOffset(CGPoint(x: CGFloat(sender.tag) * pager.bounds.width, y: 0), animated: true)
    }

    private func paint(_ b: UIButton, emphasized: Bool = false) {
        if emphasized {
            b.backgroundColor = palette.accent.withAlphaComponent(0.72)
        } else {
            b.backgroundColor = palette.key
        }
        b.setTitleColor(emphasized ? .white : palette.text, for: .normal)
        b.tintColor = emphasized ? .white : palette.text
        b.layer.cornerRadius = 12
        b.layer.cornerCurve = .continuous
        b.layer.borderWidth = 0.6
        let line = palette.blurDark ? UIColor.white.withAlphaComponent(0.20) : UIColor.black.withAlphaComponent(0.10)
        b.layer.borderColor = line.cgColor
        b.layer.shadowColor = UIColor.black.cgColor
        b.layer.shadowOpacity = 0.10
        b.layer.shadowRadius = 1.5
        b.layer.shadowOffset = CGSize(width: 0, height: 1)
        b.clipsToBounds = false
    }

    private func attachPress(_ b: UIButton) {
        b.addTarget(self, action: #selector(keyPressDown(_:)), for: .touchDown)
        b.addTarget(self, action: #selector(keyPressUp(_:)), for: [.touchUpInside, .touchUpOutside, .touchCancel])
    }

    @objc private func keyPressDown(_ sender: UIButton) {
        UIView.animate(withDuration: 0.08, delay: 0, options: [.allowUserInteraction, .curveEaseOut]) {
            sender.transform = CGAffineTransform(scaleX: 1.12, y: 1.12)
            sender.backgroundColor = UIColor.white.withAlphaComponent(0.30)
        }
    }

    @objc private func keyPressUp(_ sender: UIButton) {
        let isShiftBtn = sender.image(for: .normal) != nil && (sender.currentImage?.description.contains("shift") == true)
        UIView.animate(withDuration: 0.14, delay: 0, options: [.allowUserInteraction, .curveEaseOut]) {
            sender.transform = .identity
            self.paint(sender, emphasized: self.isShifted && isShiftBtn)
        }
    }

    private let holdMap: [String: [String]] = [
        "ا": ["أ", "إ", "آ", "ء", "ى"],
        "و": ["ؤ"],
        "ي": ["ئ", "ى"],
        "ه": ["ة"],
        "ل": ["لا", "لأ", "لإ", "لآ"],
        "ة": ["ه"],
        "ئ": ["ء", "ي"],
        "أ": ["إ", "آ", "ء", "ا"],
        "ؤ": ["و", "ء"],
        ".": ["…", "•"],
        "-": ["–", "—"],
        ",": ["،"],
        ";": ["؛"],
        "?": ["؟"],
        "!": ["؟"],
        "%": ["٪"],
        "'": ["’", "‘"]
    ]

    private func alts(for key: String) -> [String] {
        if key == "\"" { return ["«", "»"] }
        return holdMap[key] ?? []
    }

    private func charKey(_ t: String) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(t, for: .normal)
        b.titleLabel?.font = letterFont
        paint(b)
        attachPress(b)
        b.addTarget(self, action: #selector(charDown(_:)), for: .touchDown)
        b.addTarget(self, action: #selector(charDrag(_:event:)), for: .touchDragInside)
        b.addTarget(self, action: #selector(charDrag(_:event:)), for: .touchDragOutside)
        b.addTarget(self, action: #selector(charUp(_:)), for: [.touchUpInside, .touchUpOutside, .touchCancel])
        return b
    }

    private func control(_ t: String, _ a: Selector, font: CGFloat) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(t, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: font, weight: .semibold)
        paint(b)
        attachPress(b)
        b.addTarget(self, action: a, for: .touchUpInside)
        return b
    }

    private func iconKey(_ name: String, _ a: Selector) -> UIButton {
        let b = UIButton(type: .system)
        let symbol = UIImage(systemName: name, withConfiguration: iconConfig)
            ?? UIImage(systemName: fallbackSymbol(name), withConfiguration: iconConfig)
        b.setImage(symbol, for: .normal)
        paint(b, emphasized: name.contains("shift.fill") && isShifted)
        attachPress(b)
        b.addTarget(self, action: a, for: .touchUpInside)
        return b
    }

    private func fallbackSymbol(_ name: String) -> String {
        switch name {
        case "translate": return "globe"
        case "paintpalette": return "paintbrush"
        case "doc.on.clipboard": return "doc.on.doc"
        default: return "circle"
        }
    }

    @objc private func charDown(_ sender: UIButton) {
        holdSource = sender
        holdChoice = sender.title(for: .normal) ?? ""
        holdTimer?.invalidate()
        hideHoldPopup()
        guard let key = sender.title(for: .normal), !alts(for: key).isEmpty else { return }
        holdTimer = Timer.scheduledTimer(withTimeInterval: 0.38, repeats: false) { [weak self] _ in
            self?.showHoldPopup(from: sender)
        }
    }

    @objc private func charDrag(_ sender: UIButton, event: UIEvent) {
        guard let popup = holdPopup, let touch = event.allTouches?.first else { return }
        let p = touch.location(in: popup)
        for v in popup.subviews {
            guard let b = v as? UIButton else { continue }
            let inside = b.frame.insetBy(dx: -4, dy: -10).contains(p)
            b.backgroundColor = inside ? UIColor.white.withAlphaComponent(0.28) : .clear
            if inside { holdChoice = b.title(for: .normal) ?? holdChoice }
        }
    }

    @objc private func charUp(_ sender: UIButton) {
        holdTimer?.invalidate()
        holdTimer = nil
        let text = holdPopup != nil ? holdChoice : (sender.title(for: .normal) ?? "")
        hideHoldPopup()
        holdSource = nil
        guard !text.isEmpty else { return }
        textDocumentProxy.insertText(text)
        tapHaptic()
        if page == .letters, language == .english, isShifted {
            isShifted = false
            rebuild()
        }
    }

    private func showHoldPopup(from button: UIButton) {
        guard let key = button.title(for: .normal) else { return }
        let items = alts(for: key)
        guard !items.isEmpty else { return }
        hideHoldPopup()
        let bar = UIStackView()
        bar.axis = .horizontal
        bar.spacing = 4
        bar.alignment = .center
        bar.translatesAutoresizingMaskIntoConstraints = false
        bar.backgroundColor = UIColor.black.withAlphaComponent(0.82)
        bar.layer.cornerRadius = 12
        bar.layer.cornerCurve = .continuous
        bar.isLayoutMarginsRelativeArrangement = true
        bar.layoutMargins = UIEdgeInsets(top: 6, left: 6, bottom: 6, right: 6)
        holdChoice = items[0]
        for (i, item) in items.enumerated() {
            let b = UIButton(type: .system)
            b.setTitle(item, for: .normal)
            b.titleLabel?.font = .systemFont(ofSize: 22, weight: .medium)
            b.setTitleColor(.white, for: .normal)
            b.backgroundColor = i == 0 ? UIColor.white.withAlphaComponent(0.28) : .clear
            b.layer.cornerRadius = 8
            b.contentEdgeInsets = UIEdgeInsets(top: 4, left: 8, bottom: 4, right: 8)
            bar.addArrangedSubview(b)
        }
        view.addSubview(bar)
        let frame = button.convert(button.bounds, to: view)
        NSLayoutConstraint.activate([
            bar.bottomAnchor.constraint(equalTo: view.topAnchor, constant: frame.minY - 6),
            bar.heightAnchor.constraint(equalToConstant: 44)
        ])
        let center = bar.centerXAnchor.constraint(equalTo: view.leadingAnchor, constant: frame.midX)
        center.priority = .defaultHigh
        center.isActive = true
        bar.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 6).isActive = true
        bar.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -6).isActive = true
        holdPopup = bar
        tapHaptic()
    }

    private func hideHoldPopup() {
        holdPopup?.removeFromSuperview()
        holdPopup = nil
    }

    @objc private func shiftTapped() {
        isShifted.toggle()
        rebuild()
    }

    @objc private func deleteTouchDown() {
        textDocumentProxy.deleteBackward()
        tapHaptic()
        deleteTimer?.invalidate()
        deleteTimer = Timer.scheduledTimer(withTimeInterval: 0.35, repeats: false) { [weak self] _ in
            self?.deleteTimer = Timer.scheduledTimer(withTimeInterval: 0.07, repeats: true) { [weak self] _ in
                self?.textDocumentProxy.deleteBackward()
            }
        }
    }

    @objc private func deleteTouchUp() {
        deleteTimer?.invalidate()
        deleteTimer = nil
    }

    @objc private func deleteTouchCancel() {
        deleteTimer?.invalidate()
        deleteTimer = nil
    }

    @objc private func spaceTouchDown(_ sender: UIButton, event: UIEvent) {
        spaceIsTrackpad = false
        if let t = event.allTouches?.first {
            spaceStart = t.location(in: sender)
            lastTrackpadX = spaceStart.x
        }
    }

    @objc private func spaceDrag(_ sender: UIButton, event: UIEvent) {
        guard trackpadOn, let t = event.allTouches?.first else { return }
        let p = t.location(in: sender)
        if abs(p.x - spaceStart.x) > 10 { spaceIsTrackpad = true }
        guard spaceIsTrackpad else { return }
        let delta = p.x - lastTrackpadX
        if abs(delta) >= 12 {
            textDocumentProxy.adjustTextPosition(byCharacterOffset: delta > 0 ? 1 : -1)
            lastTrackpadX = p.x
            tapHaptic()
        }
    }

    @objc private func spaceTouchUp() {
        if spaceIsTrackpad {
            spaceIsTrackpad = false
            return
        }
        let now = Date()
        if let last = lastSpaceTap, now.timeIntervalSince(last) <= spaceSwitchInterval {
            lastSpaceTap = nil
            language = language == .arabic ? .english : .arabic
            isShifted = false
            if page != .emoji { page = .letters }
            rebuild()
            tapHaptic()
            return
        }
        lastSpaceTap = now
        textDocumentProxy.insertText(" ")
        tapHaptic()
    }

    @objc private func periodTapped() {
        textDocumentProxy.insertText(".")
        tapHaptic()
    }

    @objc private func enterTapped() {
        textDocumentProxy.insertText("\n")
        tapHaptic()
    }

    @objc private func emojiTapped() {
        page = (page == .emoji) ? .letters : .emoji
        rebuild()
    }

    @objc private func symbolsOrLettersTapped() {
        switch page {
        case .letters:
            page = .symbols
            symbolPageIndex = 0
        case .symbols:
            if symbolPageIndex == 0 {
                symbolPageIndex = 1
            } else {
                page = .letters
                symbolPageIndex = 0
            }
        case .emoji:
            page = .letters
        }
        rebuild()
    }

    @objc private func copyTapped() {
        guard hasFullAccess else { return }
        persistAccess()
        let selected = textDocumentProxy.selectedText
        let text = (selected?.isEmpty == false ? selected : nil) ?? combined()
        guard let text, !text.isEmpty else { return }
        UIPasteboard.general.string = text
        tapHaptic()
    }

    @objc private func pasteTapped() {
        guard hasFullAccess else { return }
        persistAccess()
        if let t = UIPasteboard.general.string, !t.isEmpty {
            textDocumentProxy.insertText(t)
            tapHaptic()
        }
    }

    @objc private func translateTapped() {
        guard hasFullAccess else { return }
        persistAccess()
        let selected = textDocumentProxy.selectedText
        let text = (selected?.isEmpty == false ? selected : nil)
            ?? textDocumentProxy.documentContextBeforeInput
            ?? combined()
        guard let text, !text.isEmpty else { return }
        let ar = text.unicodeScalars.filter { $0.value >= 0x0600 && $0.value <= 0x06FF }.count
        let toEn = ar >= max(1, text.count / 4)
        translationModel.sourceLang = toEn ? "ar" : "en"
        translationModel.targetLang = toEn ? "en" : "ar"
        translationModel.sourceText = text
        translationModel.token += 1
    }

    private func applyTranslation(_ text: String) {
        guard !text.isEmpty else { return }
        if let selected = textDocumentProxy.selectedText, !selected.isEmpty {
            textDocumentProxy.deleteBackward()
            textDocumentProxy.insertText(text)
            return
        }
        if let before = textDocumentProxy.documentContextBeforeInput {
            for _ in 0..<before.count { textDocumentProxy.deleteBackward() }
        }
        textDocumentProxy.insertText(text)
    }

    private func combined() -> String? {
        let v = (textDocumentProxy.documentContextBeforeInput ?? "") + (textDocumentProxy.documentContextAfterInput ?? "")
        return v.isEmpty ? nil : v
    }

    @objc private func dismissKeyboardAction() {
        dismissKeyboard()
    }

    private static func catalog() -> [(icon: String, items: [String])] {
        func s(_ t: String) -> [String] { t.split(separator: " ").map(String.init) }
        return [
            ("😊", s("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 🤡 👻 💀 👽 🤖 🎃 😺 😸 😹 😻 😼 😽")),
            ("👋", s("👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 💪 👂 👃 👀 👶 👧 👦 👩 🧑 👨 👵 👴 👮 👷 👸 🤴 🦸 🎅 🧙 🧚 👼 🚶 🏃 💃 🕺 🧘 👪")),
            ("❤️", s("❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ⭐ 🌟 ✨ ⚡ 🔥 💯 ✅ ❌ ❓ ❗")),
            ("🐾", s("🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🐤 🦆 🦉 🐝 🦋 🐞 🐢 🐍 🐙 🐠 🐬 🐳 🦈 🐘 🦒 🦌 🐄 🐇 🌸 🌹 🌻 🌷 🍀 🌿 🍁 🍂")),
            ("🍔", s("🍏 🍎 🍊 🍋 🍌 🍉 🍇 🍓 🍑 🍍 🥝 🍅 🥑 🥕 🌽 🍞 🧀 🥚 🍳 🥞 🥓 🍔 🍟 🍕 🌮 🌯 🥗 🍝 🍜 🍣 🍱 🍦 🍩 🍪 🎂 🍫 🍿 ☕ 🍵 🧃 🥤")),
            ("✈️", s("🚗 🚕 🚌 🚓 🚑 🚚 🚲 🏍️ ✈️ 🚀 🚁 ⛵ 🚢 🏠 🏢 🏥 🏫 🕌 🕋 🗽 🗼 🏰 🎡 ⛺ 🌅 🌃 🌈 ☀️ ⛅ ☁️ 🌧️ ❄️")),
            ("⚽", s("⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 ⛳ 🎯 🎮 🎲 🏆 🥇 🥈 🥉 🎨 🎬 🎤 🎧 🎹 🎸 🥁")),
            ("💡", s("⌚ 📱 💻 📷 🎥 💡 🔒 🔑 🎁 🎈 🎉 📦 📚 ✏️ 💼 🛒")),
            ("⭐", s("⭐ 🌟 ✨ ⚡ 🔥 💧 🌈 ✅ ❌ ❓ ❗ 💯 🔔 💬 ⚪ ⚫ 🔴 🔵 🟢 🟡")),
            ("🇸🇦", s("🇸🇦 🇦🇪 🇶🇦 🇰🇼 🇧🇭 🇴🇲 🇾🇪 🇪🇬 🇯🇴 🇵🇸 🇱🇧 🇸🇾 🇮🇶 🇹🇷 🇺🇸 🇬🇧 🇫🇷 🇩🇪 🇯🇵 🇰🇷 🇮🇳 🇵🇰 🇮🇩 🇲🇾 🇺🇳 🏳️ 🏴 🏁"))
        ]
    }
}

final class EmojiCell: UICollectionViewCell {
    let label = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 26)
        label.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])
        contentView.backgroundColor = .clear
        contentView.layer.cornerRadius = 6
    }
    required init?(coder: NSCoder) { fatalError() }
    func paint(_ p: NaqraPalette) {
        contentView.backgroundColor = .clear
        label.textColor = p.text
    }
}