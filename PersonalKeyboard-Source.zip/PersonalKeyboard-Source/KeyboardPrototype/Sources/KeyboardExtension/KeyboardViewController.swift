import UIKit
import SwiftUI
import Translation

@available(iOS 18.0, *)
@MainActor
private final class TranslationBridgeModel: ObservableObject {
    @Published var configuration: TranslationSession.Configuration?
    private var pendingText: String?
    private var completion: ((Result<String, Error>) -> Void)?

    func request(text: String, source: Locale.Language, target: Locale.Language, completion: @escaping (Result<String, Error>) -> Void) {
        pendingText = text
        self.completion = completion
        configuration = TranslationSession.Configuration(source: source, target: target)
    }

    func translate(using session: TranslationSession) async {
        guard let text = pendingText else { return }
        do {
            let response = try await session.translate(text)
            finish(.success(response.targetText))
        } catch {
            finish(.failure(error))
        }
    }

    private func finish(_ result: Result<String, Error>) {
        let callback = completion
        completion = nil
        pendingText = nil
        configuration = nil
        callback?(result)
    }
}

@available(iOS 18.0, *)
private struct TranslationBridgeView: View {
    @ObservedObject var model: TranslationBridgeModel
    var body: some View {
        Color.clear.frame(width: 1, height: 1).translationTask(model.configuration) { session in
            await model.translate(using: session)
        }
    }
}

final class KeyboardViewController: UIInputViewController {
    private enum KeyboardLanguage: Equatable {
        case arabic, english
        var name: String { self == .arabic ? "العربية" : "English" }
    }
    private enum KeyboardPage: Equatable { case letters, symbols, emoji }
    private enum TranslateTarget: String, CaseIterable {
        case arabic, english
        var title: String { self == .arabic ? "إلى العربية" : "إلى English" }
        var appleCode: String { self == .arabic ? "ar" : "en" }
    }

    private var language: KeyboardLanguage = .arabic
    private var page: KeyboardPage = .letters
    private var isArabic: Bool { language == .arabic }
    private var isEnglish: Bool { language == .english }
    private var spacebarTitle: String { isArabic ? "مسافة" : "space" }
    private var isShifted = false
    private var currentTheme: Theme = .morning
    private var lastSpaceTapTime: TimeInterval?
    private var isShowingTranslator = false
    private let appGroup = UserDefaults(suiteName: "group.app.personal.PersonalKeyboard")
    private var lastTranslateTarget: TranslateTarget {
        get { TranslateTarget(rawValue: appGroup?.string(forKey: "translateTarget") ?? "") ?? .english }
        set { appGroup?.set(newValue.rawValue, forKey: "translateTarget") }
    }

    private let keyboardRoot = UIStackView()
    private let statusLabel = UILabel()
    private let impact = UIImpactFeedbackGenerator(style: .light)
    private var heightConstraint: NSLayoutConstraint?
    private var themeTimer: Timer?
    private var statusTimer: Timer?
    private var deleteHoldTimer: Timer?
    private var repeatDeleteTimer: Timer?
    private var deleteTouchActive = false
    private var deleteDidRepeat = false
    private var translationBridgeModel: AnyObject?
    private var translationHost: UIViewController?
    private var letterButtons: [(button: UIButton, key: String)] = []
    private weak var shiftButton: UIButton?

    private let numberKeys = Array("1234567890").map(String.init)
    private let englishRows: [[String]] = [
        Array("qwertyuiop").map(String.init),
        Array("asdfghjkl").map(String.init),
        Array("zxcvbnm").map(String.init)
    ]
    private let arabicRows: [[String]] = [
        ["ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج"],
        ["ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ة"],
        ["ئ", "ظ", "ط", "ذ", "د", "ز", "ر", "و"]
    ]
    private let symbolRows: [[String]] = [
        [".", "،", "؟", "!", "؛", ":", ",", "?", "'", "\"", "…"],
        ["(", ")", "[", "]", "{", "}", "<", ">", "/", "\\", "|"],
        ["-", "_", "+", "=", "*", "&", "@", "#", "%", "٪", "~"],
        ["$", "€", "£", "¥", "°", "•", "–", "—", "«", "»"]
    ]
    private let emojiRows: [[String]] = [
        ["😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣"],
        ["🥲", "😊", "😉", "😍", "🥰", "😘", "😗", "🙂"],
        ["😌", "😎", "🤩", "🥳", "😭", "😢", "🙏", "❤️"]
    ]

    private enum Theme: Equatable {
        case morning, evening
        var background: UIColor {
            self == .morning ? UIColor(red: 0.88, green: 0.93, blue: 0.98, alpha: 1) : UIColor(red: 0.055, green: 0.075, blue: 0.12, alpha: 1)
        }
        var keyBackground: UIColor {
            self == .morning ? UIColor(red: 0.99, green: 0.995, blue: 1, alpha: 1) : UIColor(red: 0.14, green: 0.18, blue: 0.25, alpha: 1)
        }
        var utilityBackground: UIColor {
            self == .morning ? UIColor(red: 0.74, green: 0.82, blue: 0.91, alpha: 1) : UIColor(red: 0.22, green: 0.29, blue: 0.40, alpha: 1)
        }
        var textColor: UIColor { self == .morning ? .label : .white }
        var activeShiftBackground: UIColor {
            self == .morning ? UIColor.systemBlue.withAlphaComponent(0.25) : UIColor.systemTeal.withAlphaComponent(0.42)
        }
        var shadowOpacity: Float { self == .morning ? 0.12 : 0.05 }
    }
    private enum KeyStyle: Equatable { case standard, utility }

    override func viewDidLoad() {
        super.viewDidLoad()
        impact.prepare()
        setupKeyboard()
        setupTranslationBridgeIfAvailable()
        applyAutomaticTheme()
        rebuildKeys()
        persistFullAccessFlag()
        if #available(iOS 17.0, *) {
            registerForTraitChanges([UITraitUserInterfaceStyle.self]) { (self: KeyboardViewController, _) in
                self.applyAutomaticTheme()
            }
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        persistFullAccessFlag()
        themeTimer?.invalidate()
        themeTimer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in self?.applyAutomaticTheme() }
        if let themeTimer { RunLoop.main.add(themeTimer, forMode: .common) }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        themeTimer?.invalidate(); themeTimer = nil
        statusTimer?.invalidate(); statusTimer = nil
        stopDeleteRepeat()
        lastSpaceTapTime = nil
    }

    private func persistFullAccessFlag() { appGroup?.set(hasFullAccess, forKey: "hasFullAccess") }

    private func applyAutomaticTheme() {
        let selectedTheme: Theme = traitCollection.userInterfaceStyle == .dark ? .evening : .morning
        guard selectedTheme != currentTheme else { return }
        currentTheme = selectedTheme
        view.backgroundColor = currentTheme.background
        statusLabel.textColor = currentTheme.textColor
        statusLabel.backgroundColor = currentTheme.utilityBackground
        rebuildKeys()
    }

    private func setupKeyboard() {
        view.backgroundColor = currentTheme.background
        keyboardRoot.axis = .vertical
        keyboardRoot.semanticContentAttribute = .forceLeftToRight
        keyboardRoot.alignment = .fill
        keyboardRoot.distribution = .fillEqually
        keyboardRoot.spacing = 5
        keyboardRoot.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(keyboardRoot)
        NSLayoutConstraint.activate([
            keyboardRoot.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 1),
            keyboardRoot.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -1),
            keyboardRoot.topAnchor.constraint(equalTo: view.topAnchor, constant: 5),
            keyboardRoot.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -5)
        ])
        heightConstraint = view.heightAnchor.constraint(equalToConstant: 326)
        heightConstraint?.priority = .defaultHigh
        heightConstraint?.isActive = true
        statusLabel.font = .systemFont(ofSize: 12, weight: .medium)
        statusLabel.textAlignment = .center
        statusLabel.textColor = currentTheme.textColor
        statusLabel.backgroundColor = currentTheme.utilityBackground
        statusLabel.layer.cornerRadius = 12
        statusLabel.layer.masksToBounds = true
        statusLabel.alpha = 0
        statusLabel.isUserInteractionEnabled = false
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(statusLabel)
        NSLayoutConstraint.activate([
            statusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 2),
            statusLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 24),
            statusLabel.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, constant: -32)
        ])
    }

    private func setupTranslationBridgeIfAvailable() {
        guard #available(iOS 18.0, *) else { return }
        let model = TranslationBridgeModel()
        let host = UIHostingController(rootView: TranslationBridgeView(model: model))
        host.view.backgroundColor = .clear
        host.view.isUserInteractionEnabled = false
        host.view.translatesAutoresizingMaskIntoConstraints = false
        addChild(host)
        view.addSubview(host.view)
        NSLayoutConstraint.activate([
            host.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            host.view.topAnchor.constraint(equalTo: view.topAnchor),
            host.view.widthAnchor.constraint(equalToConstant: 1),
            host.view.heightAnchor.constraint(equalToConstant: 1)
        ])
        host.didMove(toParent: self)
        translationBridgeModel = model
        translationHost = host
    }

    private func rebuildKeys() {
        keyboardRoot.arrangedSubviews.forEach {
            keyboardRoot.removeArrangedSubview($0)
            $0.removeFromSuperview()
        }
        letterButtons.removeAll()
        shiftButton = nil
        addToolbarRow()
        if isShowingTranslator { addTranslationChooserRow() }
        addKeyRow(numberKeys, style: .standard)
        switch page {
        case .letters:
            let rows = isArabic ? arabicRows : englishRows
            addKeyRow(rows[0], style: .standard, respondsToShift: isEnglish)
            addKeyRow(rows[1], style: .standard, horizontalInset: 4, respondsToShift: isEnglish)
            addContentControlRow(rows[2], leadingTitle: "⇧", leadingEnabled: isEnglish, leadingAccessibilityLabel: isEnglish ? "Shift" : "تبديل الأحرف الكبيرة", leadingAction: { [weak self] in
                guard let self, self.isEnglish else { return }
                self.isShifted.toggle()
                self.updateShiftState()
            }, respondsToShift: isEnglish)
        case .symbols:
            addKeyRow(symbolRows[0], style: .standard)
            addKeyRow(symbolRows[1], style: .standard, horizontalInset: 6)
            addKeyRow(symbolRows[3], style: .standard, horizontalInset: 28)
            addContentControlRow(symbolRows[2], leadingTitle: "ABC", leadingEnabled: true, leadingAccessibilityLabel: "العودة إلى الحروف", leadingAction: { [weak self] in self?.showLetters() })
        case .emoji:
            addKeyRow(emojiRows[0], style: .standard)
            addKeyRow(emojiRows[1], style: .standard, horizontalInset: 6)
            addContentControlRow(emojiRows[2], leadingTitle: "ABC", leadingEnabled: true, leadingAccessibilityLabel: "العودة إلى الحروف", leadingAction: { [weak self] in self?.showLetters() })
        }
        addBottomRow()
        updateShiftState()
    }

    private func addKeyRow(_ keys: [String], style: KeyStyle, horizontalInset: CGFloat = 0, respondsToShift: Bool = false) {
        let row = UIStackView()
        row.axis = .horizontal
        row.semanticContentAttribute = .forceLeftToRight
        row.alignment = .fill
        row.distribution = .fillEqually
        row.spacing = 4
        row.isLayoutMarginsRelativeArrangement = true
        row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: horizontalInset, bottom: 0, trailing: horizontalInset)
        for key in keys {
            let button = makeButton(title: key, style: style)
            if respondsToShift { letterButtons.append((button: button, key: key)) }
            button.addAction(UIAction { [weak self] _ in self?.insert(key) }, for: .touchUpInside)
            row.addArrangedSubview(button)
        }
        keyboardRoot.addArrangedSubview(row)
    }

    private func addContentControlRow(_ keys: [String], leadingTitle: String, leadingEnabled: Bool, leadingAccessibilityLabel: String, leadingAction: @escaping () -> Void, respondsToShift: Bool = false) {
        let row = UIStackView()
        row.axis = .horizontal
        row.semanticContentAttribute = .forceLeftToRight
        row.alignment = .fill
        row.distribution = .fill
        row.spacing = 5
        row.isLayoutMarginsRelativeArrangement = true
        row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 1, bottom: 0, trailing: 1)
        let leading = makeButton(title: leadingTitle, style: .utility)
        leading.isEnabled = leadingEnabled
        leading.accessibilityLabel = leadingAccessibilityLabel
        leading.titleLabel?.font = .systemFont(ofSize: leadingTitle == "ABC" ? 13 : 18, weight: .medium)
        leading.widthAnchor.constraint(equalToConstant: 43).isActive = true
        if leadingTitle == "⇧" {
            shiftButton = leading
            leading.addAction(UIAction { [weak self] _ in
                guard let self, self.isEnglish else { return }
                self.isShifted.toggle()
                self.updateShiftState()
            }, for: .touchUpInside)
        } else {
            leading.addAction(UIAction { _ in leadingAction() }, for: .touchUpInside)
        }
        row.addArrangedSubview(leading)
        let keyStack = UIStackView()
        keyStack.axis = .horizontal
        keyStack.semanticContentAttribute = .forceLeftToRight
        keyStack.alignment = .fill
        keyStack.distribution = .fillEqually
        keyStack.spacing = 4
        for key in keys {
            let button = makeButton(title: key, style: .standard)
            if respondsToShift { letterButtons.append((button: button, key: key)) }
            button.addAction(UIAction { [weak self] _ in self?.insert(key) }, for: .touchUpInside)
            keyStack.addArrangedSubview(button)
        }
        row.addArrangedSubview(keyStack)
        let delete = makeButton(title: "⌫", style: .utility)
        delete.widthAnchor.constraint(equalToConstant: 43).isActive = true
        delete.accessibilityLabel = "حذف"
        delete.addAction(UIAction { [weak self] _ in self?.beginDeletePress() }, for: .touchDown)
        delete.addAction(UIAction { [weak self] _ in self?.endDeletePress() }, for: .touchUpInside)
        delete.addAction(UIAction { [weak self] _ in self?.stopDeleteRepeat() }, for: [.touchUpOutside, .touchCancel, .touchDragExit])
        row.addArrangedSubview(delete)
        keyboardRoot.addArrangedSubview(row)
    }

    private func addToolbarRow() {
        let row = UIStackView()
        row.axis = .horizontal
        row.semanticContentAttribute = .forceLeftToRight
        row.alignment = .fill
        row.distribution = .fill
        row.spacing = 4
        let copyButton = makeButton(title: "", style: .utility)
        copyButton.configuration?.image = UIImage(systemName: "doc.on.doc")
        copyButton.widthAnchor.constraint(equalToConstant: 36).isActive = true
        copyButton.addAction(UIAction { [weak self] _ in self?.copyText() }, for: .touchUpInside)
        row.addArrangedSubview(copyButton)
        let pasteButton = makeButton(title: "", style: .utility)