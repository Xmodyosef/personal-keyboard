import SwiftUI
import Translation
import UIKit

enum KeyboardLanguage { case arabic, english }
enum KeyboardPage { case letters, symbols, emoji }

final class TranslationBridgeModel: ObservableObject {
    @Published var sourceText = ""
    @Published var token = 0
    var sourceLang = "ar"
    var targetLang = "en"
    var onResult: ((String) -> Void)?
}

struct TranslationBridgeView: View {
    @ObservedObject var model: TranslationBridgeModel
    var body: some View {
        Group {
            if #available(iOS 18.0, *) {
                Color.clear.frame(width: 1, height: 1)
                    .translationTask(
                        TranslationSession.Configuration(
                            source: Locale.Language(identifier: model.sourceLang),
                            target: Locale.Language(identifier: model.targetLang)
                        )
                    ) { session in
                        let text = model.sourceText
                        guard !text.isEmpty else { return }
                        do {
                            let response = try await session.translate(text)
                            await MainActor.run { model.onResult?(response.targetText) }
                        } catch {}
                    }
                    .id(model.token)
            }
        }
    }
}

struct NaqraPalette {
    var background: UIColor
    var key: UIColor
    var text: UIColor
    var accent: UIColor
    static func current() -> NaqraPalette {
        let id = UserDefaults(suiteName: "group.app.personal.PersonalKeyboard")?.string(forKey: "themeId") ?? "glass"
        let accent = UIColor(red: 0.35, green: 0.62, blue: 1.0, alpha: 1)
        switch id {
        case "charcoal":
            return .init(background: UIColor(white: 0.06, alpha: 0.18), key: UIColor(white: 0.20, alpha: 0.40), text: .white, accent: accent)
        case "teal":
            return .init(background: UIColor(red: 0.05, green: 0.20, blue: 0.24, alpha: 0.22), key: UIColor(red: 0.14, green: 0.40, blue: 0.44, alpha: 0.48), text: .white, accent: accent)
        case "midnight":
            return .init(background: UIColor(red: 0.04, green: 0.08, blue: 0.18, alpha: 0.20), key: UIColor(red: 0.16, green: 0.24, blue: 0.40, alpha: 0.46), text: .white, accent: accent)
        case "violet":
            return .init(background: UIColor(red: 0.12, green: 0.07, blue: 0.20, alpha: 0.22), key: UIColor(red: 0.30, green: 0.20, blue: 0.46, alpha: 0.46), text: .white, accent: accent)
        case "smoke":
            return .init(background: UIColor(white: 0.14, alpha: 0.20), key: UIColor(white: 0.30, alpha: 0.42), text: .white, accent: accent)
        case "snow":
            return .init(background: UIColor(white: 0.94, alpha: 0.28), key: UIColor(white: 1, alpha: 0.62), text: UIColor(white: 0.12, alpha: 1), accent: UIColor.systemBlue)
        case "clear":
            return .init(background: UIColor(white: 0.08, alpha: 0.08), key: UIColor(white: 1, alpha: 0.14), text: .white, accent: accent)
        default:
            return .init(
                background: UIColor(red: 0.05, green: 0.10, blue: 0.22, alpha: 0.16),
                key: UIColor(red: 0.18, green: 0.26, blue: 0.42, alpha: 0.42),
                text: UIColor(white: 0.96, alpha: 1),
                accent: accent
            )
        }
    }
}

final class KeyboardViewController: UIInputViewController, UIScrollViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    private let suite = UserDefaults(suiteName: "group.app.personal.PersonalKeyboard")
    private var language: KeyboardLanguage = .arabic
    private var page: KeyboardPage = .letters
    private var isShifted = false
    private var symbolPageIndex = 0
    private var emojiCategoryIndex = 0
    private var palette = NaqraPalette.current()

    private let blurView = UIVisualEffectView(effect: UIBlurEffect(style: .systemUltraThinMaterialDark))
    private let rootStack = UIStackView()
    private var heightConstraint: NSLayoutConstraint?
    private var deleteTimer: Timer?
    private var lastSpaceTap: Date?
    private let spaceSwitchInterval: TimeInterval = 0.36
    private var spaceStart: CGPoint = .zero
    private var spaceIsTrackpad = false
    private var lastTrackpadX: CGFloat = 0

    private let translationModel = TranslationBridgeModel()
    private var translationHost: UIHostingController<TranslationBridgeView>?
    private var emojiPager: UIScrollView?
    private var emojiTabs: UIStackView?

    private let letterFont = UIFont.systemFont(ofSize: 21, weight: .medium)
    private let iconConfig = UIImage.SymbolConfiguration(pointSize: 13, weight: .semibold)

    private let arabicRows = [
        ["ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج"],
        ["ش","س","ي","ب","ل","ا","ت","ن","م","ك","ة"],
        ["ئ","ظ","ط","ذ","د","ز","ر","و"]
    ]
    private let arabicShiftRows = [
        ["َ","ً","ُ","ٌ","ِ","ٍ","ْ","ّ","ـ","ٰ","ٓ"],
        ["أ","إ","آ","ى","ء","ؤ","لا","لآ","لأ","لإ","ة"],
        ["،","؛","؟","٪","…","ـ","ى","ئ"]
    ]
    private let englishLower = [
        ["q","w","e","r","t","y","u","i","o","p"],
        ["a","s","d","f","g","h","j","k","l"],
        ["z","x","c","v","b","n","m"]
    ]
    private let englishUpper = [
        ["Q","W","E","R","T","Y","U","I","O","P"],
        ["A","S","D","F","G","H","J","K","L"],
        ["Z","X","C","V","B","N","M"]
    ]
    private let numberRow = ["1","2","3","4","5","6","7","8","9","0"]
    private let symbolPages = [
        [["-","/",":",";","(",")","$","&","@","\""],[".",",","?","!","'","*","+","=","#"],["%","^","_","\\","|","~","`"]],
        [["[","]","{","}","<",">","«","»"],["€","£","¥","₽","٪","،","؛","؟"],["…","–","—","•","°","§"]]
    ]
    private let emojiPack: [(icon: String, items: [String])] = KeyboardViewController.catalog()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        configureRoot()
        attachBridge()
        translationModel.onResult = { [weak self] t in self?.applyTranslation(t) }
        rebuild()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        persistAccess()
        palette = NaqraPalette.current()
        rebuild()
    }

    override func updateViewConstraints() {
        if heightConstraint == nil {
            let c = view.heightAnchor.constraint(equalToConstant: page == .emoji ? 348 : 292)
            c.priority = .defaultHigh
            c.isActive = true
            heightConstraint = c
        }
        super.updateViewConstraints()
    }

    private func persistAccess() { suite?.set(hasFullAccess, forKey: "hasFullAccess") }
    private var hapticsOn: Bool { suite?.object(forKey: "haptics") as? Bool ?? true }
    private var trackpadOn: Bool { suite?.object(forKey: "trackpad") as? Bool ?? true }

    private func tapHaptic() {
        guard hapticsOn else { return }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    private func configureRoot() {
        blurView.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(blurView, at: 0)
        NSLayoutConstraint.activate([
            blurView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            blurView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            blurView.topAnchor.constraint(equalTo: view.topAnchor),
            blurView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        rootStack.axis = .vertical
        rootStack.spacing = 6
        rootStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(rootStack)
        NSLayoutConstraint.activate([
            rootStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 5),
            rootStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -5),
            rootStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 8),
            rootStack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -5)
        ])
    }

    private func attachBridge() {
        let host = UIHostingController(rootView: TranslationBridgeView(model: translationModel))
        translationHost = host
        addChild(host)
        host.view.backgroundColor = .clear
        host.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(host.view)
        NSLayoutConstraint.activate([
            host.view.widthAnchor.constraint(equalToConstant: 1),
            host.view.heightAnchor.constraint(equalToConstant: 1),
            host.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            host.view.topAnchor.constraint(equalTo: view.topAnchor)
        ])
        host.didMove(toParent: self)
    }

    private func rebuild() {
        palette = NaqraPalette.current()
        view.backgroundColor = .clear
        blurView.backgroundColor = palette.background
        rootStack.arrangedSubviews.forEach { rootStack.removeArrangedSubview($0); $0.removeFromSuperview() }
        heightConstraint?.constant = page == .emoji ? 348 : 292
        if page != .emoji { rootStack.addArrangedSubview(makeToolbar()) }
        switch page {
        case .letters:
            rootStack.addArrangedSubview(makeRow(numberRow, rtl: false))
            let rows = language == .arabic ? (isShifted ? arabicShiftRows : arabicRows) : (isShifted ? englishUpper : englishLower)
            for (i, row) in rows.enumerated() {
                if i == rows.count - 1 { rootStack.addArrangedSubview(makeLastLetterRow(row)) }
                else { rootStack.addArrangedSubview(makeRow(row, rtl: language == .arabic)) }
            }
            rootStack.addArrangedSubview(makeBottom(title: "#+="))
        case .symbols:
            for row in symbolPages[min(symbolPageIndex, 1)] { rootStack.addArrangedSubview(makeRow(row, rtl: false)) }
            rootStack.addArrangedSubview(makeBottom(title: symbolPageIndex == 0 ? "1/2" : "2/1", letters: true))
        case .emoji:
            rootStack.addArrangedSubview(makeEmojiTabs())
            rootStack.addArrangedSubview(makeEmojiPager())
            rootStack.addArrangedSubview(makeBottom(title: "#+=", letters: true, emojiOn: true))
        }
    }

    private func makeToolbar() -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 6
        s.distribution = .fillEqually
        s.semanticContentAttribute = .forceRightToLeft
        s.addArrangedSubview(control("نسخ", #selector(copyTapped), font: 15))
        s.addArrangedSubview(control("لصق", #selector(pasteTapped), font: 15))
        s.addArrangedSubview(control("ترجم", #selector(translateTapped), font: 15))
        s.heightAnchor.constraint(equalToConstant: 34).isActive = true
        return s
    }

    private func makeRow(_ keys: [String], rtl: Bool) -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 5
        s.distribution = .fillEqually
        s.semanticContentAttribute = rtl ? .forceRightToLeft : .forceLeftToRight
        keys.forEach { s.addArrangedSubview(charKey($0)) }
        s.heightAnchor.constraint(equalToConstant: 42).isActive = true
        return s
    }

    private func makeLastLetterRow(_ keys: [String]) -> UIView {
        let wrap = UIStackView()
        wrap.axis = .horizontal
        wrap.spacing = 5
        wrap.semanticContentAttribute = .forceLeftToRight
        let shift = iconKey(isShifted ? "shift.fill" : "shift", #selector(shiftTapped))
        shift.widthAnchor.constraint(equalToConstant: 40).isActive = true
        paint(shift, emphasized: isShifted)
        let mid = UIStackView()
        mid.axis = .horizontal
        mid.spacing = 5
        mid.distribution = .fillEqually
        mid.semanticContentAttribute = language == .arabic ? .forceRightToLeft : .forceLeftToRight
        keys.forEach { mid.addArrangedSubview(charKey($0)) }
        let del = iconKey("delete.left", #selector(deleteTouchUp))
        del.addTarget(self, action: #selector(deleteTouchDown), for: .touchDown)
        del.addTarget(self, action: #selector(deleteTouchCancel), for: [.touchUpOutside, .touchCancel])
        del.widthAnchor.constraint(equalToConstant: 40).isActive = true
        wrap.addArrangedSubview(shift)
        wrap.addArrangedSubview(mid)
        wrap.addArrangedSubview(del)
        wrap.heightAnchor.constraint(equalToConstant: 42).isActive = true
        return wrap
    }

    private func makeBottom(title: String, letters: Bool = false, emojiOn: Bool = false) -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 5
        s.semanticContentAttribute = .forceLeftToRight
        let emoji = control(emojiOn ? "😊" : "🙂", #selector(emojiTapped), font: 18)
        let midTitle = page == .symbols ? title : (letters ? "ABC" : title)
        let symbols = control(midTitle, #selector(symbolsOrLettersTapped), font: 13)
        let space = control("مسافة", #selector(spaceTouchUp), font: 14)
        space.addTarget(self, action: #selector(spaceTouchDown(_:event:)), for: .touchDown)
        space.addTarget(self, action: #selector(spaceDrag(_:event:)), for: .touchDragInside)
        space.addTarget(self, action: #selector(spaceDrag(_:event:)), for: .touchDragOutside)
        let period = control(".", #selector(periodTapped), font: 20)
        let enter = control("إدخال", #selector(enterTapped), font: 13)
        let hide = iconKey("keyboard.chevron.compact.down", #selector(dismissKeyboardAction))
        emoji.widthAnchor.constraint(equalToConstant: 40).isActive = true
        symbols.widthAnchor.constraint(equalToConstant: 50).isActive = true
        period.widthAnchor.constraint(equalToConstant: 34).isActive = true
        enter.widthAnchor.constraint(equalToConstant: 54).isActive = true
        hide.widthAnchor.constraint(equalToConstant: 38).isActive = true
        space.setContentHuggingPriority(.defaultLow, for: .horizontal)
        space.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        [emoji, symbols, space, period, enter, hide].forEach { s.addArrangedSubview($0) }
        s.heightAnchor.constraint(equalToConstant: 40).isActive = true
        return s
    }

    private func makeEmojiTabs() -> UIView {
        let scroller = UIScrollView()
        scroller.showsHorizontalScrollIndicator = false
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 4
        s.translatesAutoresizingMaskIntoConstraints = false
        scroller.addSubview(s)
        emojiTabs = s
        for (i, pack) in emojiPack.enumerated() {
            let b = control(pack.icon, #selector(emojiTab(_:)), font: 18)
            b.tag = i
            b.backgroundColor = i == emojiCategoryIndex ? UIColor.white.withAlphaComponent(0.22) : palette.key
            b.widthAnchor.constraint(equalToConstant: 38).isActive = true
            s.addArrangedSubview(b)
        }
        NSLayoutConstraint.activate([
            s.leadingAnchor.constraint(equalTo: scroller.contentLayoutGuide.leadingAnchor, constant: 2),
            s.trailingAnchor.constraint(equalTo: scroller.contentLayoutGuide.trailingAnchor, constant: -2),
            s.topAnchor.constraint(equalTo: scroller.contentLayoutGuide.topAnchor),
            s.bottomAnchor.constraint(equalTo: scroller.contentLayoutGuide.bottomAnchor),
            s.heightAnchor.constraint(equalTo: scroller.frameLayoutGuide.heightAnchor)
        ])
        scroller.heightAnchor.constraint(equalToConstant: 34).isActive = true
        return scroller
    }

    private func makeEmojiPager() -> UIView {
        let pager = UIScrollView()
        pager.isPagingEnabled = true
        pager.showsHorizontalScrollIndicator = false
        pager.delegate = self
        pager.translatesAutoresizingMaskIntoConstraints = false
        emojiPager = pager
        let host = UIView()
        host.translatesAutoresizingMaskIntoConstraints = false
        pager.addSubview(host)
        NSLayoutConstraint.activate([
            host.topAnchor.constraint(equalTo: pager.contentLayoutGuide.topAnchor),
            host.bottomAnchor.constraint(equalTo: pager.contentLayoutGuide.bottomAnchor),
            host.leadingAnchor.constraint(equalTo: pager.contentLayoutGuide.leadingAnchor),
            host.trailingAnchor.constraint(equalTo: pager.contentLayoutGuide.trailingAnchor),
            host.heightAnchor.constraint(equalTo: pager.frameLayoutGuide.heightAnchor)
        ])
        var previous: UIView?
        for i in 0..<emojiPack.count {
            let layout = UICollectionViewFlowLayout()
            layout.minimumInteritemSpacing = 2
            layout.minimumLineSpacing = 2
            layout.sectionInset = UIEdgeInsets(top: 2, left: 2, bottom: 2, right: 2)
            let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
            cv.backgroundColor = .clear
            cv.dataSource = self
            cv.delegate = self
            cv.tag = i
            cv.register(EmojiCell.self, forCellWithReuseIdentifier: "e")
            cv.translatesAutoresizingMaskIntoConstraints = false
            host.addSubview(cv)
            NSLayoutConstraint.activate([
                cv.topAnchor.constraint(equalTo: host.topAnchor),
                cv.bottomAnchor.constraint(equalTo: host.bottomAnchor),
                cv.widthAnchor.constraint(equalTo: pager.frameLayoutGuide.widthAnchor),
                cv.heightAnchor.constraint(equalTo: host.heightAnchor)
            ])
            if let previous {
                cv.leadingAnchor.constraint(equalTo: previous.trailingAnchor).isActive = true
            } else {
                cv.leadingAnchor.constraint(equalTo: host.leadingAnchor).isActive = true
            }
            if i == emojiPack.count - 1 {
                cv.trailingAnchor.constraint(equalTo: host.trailingAnchor).isActive = true
            }
            previous = cv
        }
        DispatchQueue.main.async { [weak self] in
            guard let self, let pager = self.emojiPager else { return }
            pager.setContentOffset(CGPoint(x: CGFloat(self.emojiCategoryIndex) * pager.bounds.width, y: 0), animated: false)
        }
        return pager
    }

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        guard scrollView === emojiPager, scrollView.bounds.width > 0 else { return }
        let idx = Int(round(scrollView.contentOffset.x / scrollView.bounds.width))
        emojiCategoryIndex = min(max(idx, 0), emojiPack.count - 1)
        refreshTabs()
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        emojiPack[collectionView.tag].items.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "e", for: indexPath) as! EmojiCell
        cell.label.text = emojiPack[collectionView.tag].items[indexPath.item]
        cell.paint(palette)
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        textDocumentProxy.insertText(emojiPack[collectionView.tag].items[indexPath.item])
        tapHaptic()
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cols: CGFloat = 8
        let w = floor((collectionView.bounds.width - 4 - (cols - 1) * 2) / cols)
        return CGSize(width: max(w, 28), height: max(w, 32))
    }

    private func refreshTabs() {
        guard let tabs = emojiTabs else { return }
        for (i, view) in tabs.arrangedSubviews.enumerated() {
            view.backgroundColor = i == emojiCategoryIndex ? UIColor.white.withAlphaComponent(0.22) : palette.key
        }
    }

    @objc private func emojiTab(_ sender: UIButton) {
        emojiCategoryIndex = sender.tag
        refreshTabs()
        guard let pager = emojiPager else { return }
        pager.setContentOffset(CGPoint(x: CGFloat(sender.tag) * pager.bounds.width, y: 0), animated: true)
    }

    private func paint(_ b: UIButton, emphasized: Bool = false) {
        b.backgroundColor = emphasized ? palette.accent : palette.key
        b.setTitleColor(emphasized ? .white : palette.text, for: .normal)
        b.tintColor = emphasized ? .white : palette.text
        b.layer.cornerRadius = 11
        b.layer.cornerCurve = .continuous
        b.layer.shadowColor = UIColor.black.cgColor
        b.layer.shadowOpacity = 0.28
        b.layer.shadowRadius = 3
        b.layer.shadowOffset = CGSize(width: 0, height: 2)
        b.clipsToBounds = false
    }

    private func attachPress(_ b: UIButton) {
        b.addTarget(self, action: #selector(keyPressDown(_:)), for: .touchDown)
        b.addTarget(self, action: #selector(keyPressUp(_:)), for: [.touchUpInside, .touchUpOutside, .touchCancel])
    }

    @objc private func keyPressDown(_ sender: UIButton) {
        UIView.animate(withDuration: 0.08, delay: 0, options: [.allowUserInteraction, .curveEaseOut]) {
            sender.transform = CGAffineTransform(scaleX: 1.12, y: 1.12)
            sender.backgroundColor = UIColor.white.withAlphaComponent(0.30)
        }
    }

    @objc private func keyPressUp(_ sender: UIButton) {
        let isShiftBtn = sender.image(for: .normal) != nil && (
            sender.currentImage?.description.contains("shift") == true
        )
        UIView.animate(withDuration: 0.14, delay: 0, options: [.allowUserInteraction, .curveEaseOut]) {
            sender.transform = .identity
            self.paint(sender, emphasized: self.isShifted && isShiftBtn)
        }
    }

    private func charKey(_ t: String) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(t, for: .normal)
        b.titleLabel?.font = letterFont
        paint(b)
        attachPress(b)
        b.addTarget(self, action: #selector(characterTapped(_:)), for: .touchUpInside)
        return b
    }

    private func control(_ t: String, _ a: Selector, font: CGFloat) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(t, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: font, weight: .semibold)
        paint(b)
        attachPress(b)
        b.addTarget(self, action: a, for: .touchUpInside)
        return b
    }

    private func iconKey(_ name: String, _ a: Selector) -> UIButton {
        let b = UIButton(type: .system)
        b.setImage(UIImage(systemName: name, withConfiguration: iconConfig), for: .normal)
        paint(b, emphasized: name == "shift.fill" && isShifted)
        attachPress(b)
        b.addTarget(self, action: a, for: .touchUpInside)
        return b
    }

    @objc private func characterTapped(_ sender: UIButton) {
        guard let t = sender.title(for: .normal), !t.isEmpty else { return }
        textDocumentProxy.insertText(t)
        tapHaptic()
        if page == .letters, language == .english, isShifted {
            isShifted = false
            rebuild()
        }
    }

    @objc private func shiftTapped() {
        isShifted.toggle()
        rebuild()
    }

    @objc private func deleteTouchDown() {
        textDocumentProxy.deleteBackward()
        tapHaptic()
        deleteTimer?.invalidate()
        deleteTimer = Timer.scheduledTimer(withTimeInterval: 0.35, repeats: false) { [weak self] _ in
            self?.deleteTimer = Timer.scheduledTimer(withTimeInterval: 0.07, repeats: true) { [weak self] _ in
                self?.textDocumentProxy.deleteBackward()
            }
        }
    }

    @objc private func deleteTouchUp() {
        deleteTimer?.invalidate()
        deleteTimer = nil
    }

    @objc private func deleteTouchCancel() {
        deleteTimer?.invalidate()
        deleteTimer = nil
    }

    @objc private func spaceTouchDown(_ sender: UIButton, event: UIEvent) {
        spaceIsTrackpad = false
        if let t = event.allTouches?.first {
            spaceStart = t.location(in: sender)
            lastTrackpadX = spaceStart.x
        }
    }

    @objc private func spaceDrag(_ sender: UIButton, event: UIEvent) {
        guard trackpadOn, let t = event.allTouches?.first else { return }
        let p = t.location(in: sender)
        if abs(p.x - spaceStart.x) > 10 { spaceIsTrackpad = true }
        guard spaceIsTrackpad else { return }
        let delta = p.x - lastTrackpadX
        if abs(delta) >= 12 {
            textDocumentProxy.adjustTextPosition(byCharacterOffset: delta > 0 ? 1 : -1)
            lastTrackpadX = p.x
            tapHaptic()
        }
    }

    @objc private func spaceTouchUp() {
        if spaceIsTrackpad {
            spaceIsTrackpad = false
            return
        }
        let now = Date()
        if let last = lastSpaceTap, now.timeIntervalSince(last) <= spaceSwitchInterval {
            lastSpaceTap = nil
            language = language == .arabic ? .english : .arabic
            isShifted = false
            if page != .emoji { page = .letters }
            rebuild()
            tapHaptic()
            return
        }
        lastSpaceTap = now
        textDocumentProxy.insertText(" ")
        tapHaptic()
    }

    @objc private func periodTapped() {
        textDocumentProxy.insertText(".")
        tapHaptic()
    }

    @objc private func enterTapped() {
        textDocumentProxy.insertText("\n")
        tapHaptic()
    }

    @objc private func emojiTapped() {
        page = .emoji
        rebuild()
    }

    @objc private func symbolsOrLettersTapped() {
        switch page {
        case .letters:
            page = .symbols
            symbolPageIndex = 0
        case .symbols:
            if symbolPageIndex == 0 {
                symbolPageIndex = 1
            } else {
                page = .letters
                symbolPageIndex = 0
            }
        case .emoji:
            page = .letters
        }
        rebuild()
    }

    @objc private func copyTapped() {
        guard hasFullAccess else { return }
        persistAccess()
        let selected = textDocumentProxy.selectedText
        let text = (selected?.isEmpty == false ? selected : nil) ?? combined()
        guard let text, !text.isEmpty else { return }
        UIPasteboard.general.string = text
        tapHaptic()
    }

    @objc private func pasteTapped() {
        guard hasFullAccess else { return }
        persistAccess()
        if let t = UIPasteboard.general.string, !t.isEmpty {
            textDocumentProxy.insertText(t)
            tapHaptic()
        }
    }

    @objc private func translateTapped() {
        guard hasFullAccess else { return }
        persistAccess()
        let selected = textDocumentProxy.selectedText
        let text = (selected?.isEmpty == false ? selected : nil)
            ?? textDocumentProxy.documentContextBeforeInput
            ?? combined()
        guard let text, !text.isEmpty else { return }
        let ar = text.unicodeScalars.filter { $0.value >= 0x0600 && $0.value <= 0x06FF }.count
        let toEn = ar >= max(1, text.count / 4)
        translationModel.sourceLang = toEn ? "ar" : "en"
        translationModel.targetLang = toEn ? "en" : "ar"
        translationModel.sourceText = text
        translationModel.token += 1
    }

    private func applyTranslation(_ text: String) {
        guard !text.isEmpty else { return }
        if let selected = textDocumentProxy.selectedText, !selected.isEmpty {
            textDocumentProxy.deleteBackward()
            textDocumentProxy.insertText(text)
            return
        }
        if let before = textDocumentProxy.documentContextBeforeInput {
            for _ in 0..<before.count { textDocumentProxy.deleteBackward() }
        }
        textDocumentProxy.insertText(text)
    }

    private func combined() -> String? {
        let v = (textDocumentProxy.documentContextBeforeInput ?? "") + (textDocumentProxy.documentContextAfterInput ?? "")
        return v.isEmpty ? nil : v
    }

    @objc private func dismissKeyboardAction() {
        dismissKeyboard()
    }

    private static func catalog() -> [(icon: String, items: [String])] {
        func s(_ t: String) -> [String] { t.split(separator: " ").map(String.init) }
        return [
            ("😊", s("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 🤡 👻 💀 👽 🤖 🎃 😺 😸 😹 😻 😼 😽")),
            ("👋", s("👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 💪 👂 👃 👀 👶 👧 👦 👩 🧑 👨 👵 👴 👮 👷 👸 🤴 🦸 🎅 🧙 🧚 👼 🚶 🏃 💃 🕺 🧘 👪")),
            ("❤️", s("❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ⭐ 🌟 ✨ ⚡ 🔥 💯 ✅ ❌ ❓ ❗")),
            ("🐾", s("🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🐤 🦆 🦉 🐝 🦋 🐞 🐢 🐍 🐙 🐠 🐬 🐳 🦈 🐘 🦒 🦌 🐄 🐇 🌸 🌹 🌻 🌷 🍀 🌿 🍁 🍂")),
            ("🍔", s("🍏 🍎 🍊 🍋 🍌 🍉 🍇 🍓 🍑 🍍 🥝 🍅 🥑 🥕 🌽 🍞 🧀 🥚 🍳 🥞 🥓 🍔 🍟 🍕 🌮 🌯 🥗 🍝 🍜 🍣 🍱 🍦 🍩 🍪 🎂 🍫 🍿 ☕ 🍵 🧃 🥤")),
            ("✈️", s("🚗 🚕 🚌 🚓 🚑 🚚 🚲 🏍️ ✈️ 🚀 🚁 ⛵ 🚢 🏠 🏢 🏥 🏫 🕌 🕋 🗽 🗼 🏰 🎡 ⛺ 🌅 🌃 🌈 ☀️ ⛅ ☁️ 🌧️ ❄️")),
            ("⚽", s("⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 ⛳ 🎯 🎮 🎲 🏆 🥇 🥈 🥉 🎨 🎬 🎤 🎧 🎹 🎸 🥁")),
            ("💡", s("⌚ 📱 💻 📷 🎥 💡 🔒 🔑 🎁 🎈 🎉 📦 📚 ✏️ 💼 🛒")),
            ("⭐", s("⭐ 🌟 ✨ ⚡ 🔥 💧 🌈 ✅ ❌ ❓ ❗ 💯 🔔 💬 ⚪ ⚫ 🔴 🔵 🟢 🟡")),
            ("🇸🇦", s("🇸🇦 🇦🇪 🇶🇦 🇰🇼 🇧🇭 🇴🇲 🇾🇪 🇪🇬 🇯🇴 🇵🇸 🇱🇧 🇸🇾 🇮🇶 🇹🇷 🇺🇸 🇬🇧 🇫🇷 🇩🇪 🇯🇵 🇰🇷 🇮🇳 🇵🇰 🇮🇩 🇲🇾 🇺🇳 🏳️ 🏴 🏁"))
        ]
    }
}

final class EmojiCell: UICollectionViewCell {
    let label = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 26)
        label.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])
        contentView.layer.cornerRadius = 6
    }
    required init?(coder: NSCoder) { fatalError() }
    func paint(_ p: NaqraPalette) {
        contentView.backgroundColor = p.key
        label.textColor = p.text
    }
}