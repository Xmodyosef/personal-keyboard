import SwiftUI
import Translation
import UIKit

enum KeyboardLanguage { case arabic, english }
enum KeyboardPage { case letters, symbols, emoji }

final class TranslationBridgeModel: ObservableObject {
    @Published var sourceText = ""
    @Published var token = 0
    var sourceLang = "ar"
    var targetLang = "en"
    var onResult: ((String) -> Void)?
}

struct TranslationBridgeView: View {
    @ObservedObject var model: TranslationBridgeModel
    var body: some View {
        Group {
            if #available(iOS 18.0, *) {
                Color.clear.frame(width: 1, height: 1)
                    .translationTask(
                        TranslationSession.Configuration(
                            source: Locale.Language(identifier: model.sourceLang),
                            target: Locale.Language(identifier: model.targetLang)
                        )
                    ) { session in
                        let text = model.sourceText
                        guard !text.isEmpty else { return }
                        do {
                            let response = try await session.translate(text)
                            await MainActor.run { model.onResult?(response.targetText) }
                        } catch {}
                    }
                    .id(model.token)
            }
        }
    }
}

final class KeyboardViewController: UIInputViewController {
    private let appGroupID = "group.app.personal.PersonalKeyboard"
    private let fullAccessKey = "hasFullAccess"
    private var language: KeyboardLanguage = .arabic
    private var page: KeyboardPage = .letters
    private var isShifted = false
    private var symbolPageIndex = 0
    private var emojiCategoryIndex = 0
    private var emojiPageIndex = 0
    private let rootStack = UIStackView()
    private var heightConstraint: NSLayoutConstraint?
    private var deleteTimer: Timer?
    private var lastSpaceTap: Date?
    private let spaceSwitchInterval: TimeInterval = 0.36
    private let translationModel = TranslationBridgeModel()
    private var translationHost: UIHostingController<TranslationBridgeView>?
    private let letterFont = UIFont.systemFont(ofSize: 22, weight: .semibold)
    private let toolbarFont = UIFont.systemFont(ofSize: 15, weight: .semibold)
    private let iconConfig = UIImage.SymbolConfiguration(pointSize: 13, weight: .semibold)
    private let arabicRows: [[String]] = [
        ["ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج"],
        ["ش","س","ي","ب","ل","ا","ت","ن","م","ك","ة"],
        ["ئ","ظ","ط","ذ","د","ز","ر","و"]
    ]
    private let arabicShiftRows: [[String]] = [
        ["َ","ً","ُ","ٌ","ِ","ٍ","ْ","ّ","ـ","ٰ","ٓ"],
        ["أ","إ","آ","ى","ء","ؤ","لا","لآ","لأ","لإ","ة"],
        ["،","؛","؟","٪","…","ـ","ى","ئ"]
    ]
    private let englishLower: [[String]] = [
        ["q","w","e","r","t","y","u","i","o","p"],
        ["a","s","d","f","g","h","j","k","l"],
        ["z","x","c","v","b","n","m"]
    ]
    private let englishUpper: [[String]] = [
        ["Q","W","E","R","T","Y","U","I","O","P"],
        ["A","S","D","F","G","H","J","K","L"],
        ["Z","X","C","V","B","N","M"]
    ]
    private let numberRow = ["1","2","3","4","5","6","7","8","9","0"]
    private let symbolPages: [[[String]]] = [
        [
            ["-","/",":",";","(",")","$","&","@","\""],
            [".",",","?","!","'","*","+","=","#"],
            ["%","^","_","\\","|","~","`"]
        ],
        [
            ["[","]","{","}","<",">","«","»"],
            ["€","£","¥","₽","٪","،","؛","؟"],
            ["…","–","—","•","°","§"]
        ]
    ]
    private let emojiCategories: [(title: String, emojis: [String])] = KeyboardViewController.makeEmojiCatalog()
    private let emojiPerPage = 32

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .secondarySystemBackground
        configureRootStack()
        attachTranslationBridge()
        translationModel.onResult = { [weak self] text in self?.applyTranslation(text) }
        rebuild()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        persistFullAccess()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        persistFullAccess()
    }

    override func updateViewConstraints() {
        if heightConstraint == nil {
            let c = view.heightAnchor.constraint(equalToConstant: page == .emoji ? 336 : 292)
            c.priority = .defaultHigh
            c.isActive = true
            heightConstraint = c
        }
        super.updateViewConstraints()
    }

    private func persistFullAccess() {
        UserDefaults(suiteName: appGroupID)?.set(hasFullAccess, forKey: fullAccessKey)
    }

    private func configureRootStack() {
        rootStack.axis = .vertical
        rootStack.spacing = 6
        rootStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(rootStack)
        NSLayoutConstraint.activate([
            rootStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 4),
            rootStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -4),
            rootStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 6),
            rootStack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -4)
        ])
    }

    private func attachTranslationBridge() {
        let host = UIHostingController(rootView: TranslationBridgeView(model: translationModel))
        translationHost = host
        addChild(host)
        host.view.backgroundColor = .clear
        host.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(host.view)
        NSLayoutConstraint.activate([
            host.view.widthAnchor.constraint(equalToConstant: 1),
            host.view.heightAnchor.constraint(equalToConstant: 1),
            host.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            host.view.topAnchor.constraint(equalTo: view.topAnchor)
        ])
        host.didMove(toParent: self)
    }

    private func rebuild() {
        rootStack.arrangedSubviews.forEach {
            rootStack.removeArrangedSubview($0)
            $0.removeFromSuperview()
        }
        heightConstraint?.constant = page == .emoji ? 336 : 292
        rootStack.addArrangedSubview(makeToolbarRow())
        switch page {
        case .letters:
            rootStack.addArrangedSubview(makeRow(numberRow, semantic: .forceLeftToRight))
            let rows = language == .arabic ? (isShifted ? arabicShiftRows : arabicRows) : (isShifted ? englishUpper : englishLower)
            for (i, row) in rows.enumerated() {
                if i == rows.count - 1 {
                    rootStack.addArrangedSubview(makeLetterBottomRow(row))
                } else {
                    let sem: UISemanticContentAttribute = language == .arabic ? .forceRightToLeft : .forceLeftToRight
                    rootStack.addArrangedSubview(makeRow(row, semantic: sem))
                }
            }
            rootStack.addArrangedSubview(makeBottomRow(title: "#+="))
        case .symbols:
            let pages = symbolPages[min(symbolPageIndex, symbolPages.count - 1)]
            for (i, row) in pages.enumerated() {
                rootStack.addArrangedSubview(makeRow(row, semantic: .forceLeftToRight))
                if i == pages.count - 1 { break }
            }
            rootStack.addArrangedSubview(makeBottomRow(title: symbolPageIndex == 0 ? "1/2" : "2/1", lettersMode: true))
        case .emoji:
            rootStack.addArrangedSubview(makeEmojiTabs())
            rootStack.addArrangedSubview(makeEmojiGrid())
            rootStack.addArrangedSubview(makeEmojiPager())
            rootStack.addArrangedSubview(makeBottomRow(title: "#+=", lettersMode: true, emojiOn: true))
        }
    }

    private func makeToolbarRow() -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 6
        s.distribution = .fillEqually
        s.semanticContentAttribute = .forceRightToLeft
        s.addArrangedSubview(makeAction("نسخ", #selector(copyTapped)))
        s.addArrangedSubview(makeAction("لصق", #selector(pasteTapped)))
        s.addArrangedSubview(makeAction("ترجم", #selector(translateTapped)))
        s.heightAnchor.constraint(equalToConstant: 34).isActive = true
        return s
    }

    private func makeRow(_ keys: [String], semantic: UISemanticContentAttribute) -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 4
        s.distribution = .fillEqually
        s.semanticContentAttribute = semantic
        keys.forEach { s.addArrangedSubview(makeChar($0)) }
        s.heightAnchor.constraint(equalToConstant: 42).isActive = true
        return s
    }

    private func makeLetterBottomRow(_ keys: [String]) -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 4
        s.semanticContentAttribute = language == .arabic ? .forceRightToLeft : .forceLeftToRight
        let shift = makeIcon(isShifted ? "shift.fill" : "shift", #selector(shiftTapped))
        shift.widthAnchor.constraint(equalToConstant: 42).isActive = true
        s.addArrangedSubview(shift)
        keys.forEach { s.addArrangedSubview(makeChar($0)) }
        let del = makeIcon("delete.left", #selector(deleteTouchUp))
        del.addTarget(self, action: #selector(deleteTouchDown), for: .touchDown)
        del.addTarget(self, action: #selector(deleteTouchCancel), for: [.touchUpOutside, .touchCancel])
        del.widthAnchor.constraint(equalToConstant: 42).isActive = true
        s.addArrangedSubview(del)
        s.heightAnchor.constraint(equalToConstant: 42).isActive = true
        return s
    }

    private func makeBottomRow(title: String, lettersMode: Bool = false, emojiOn: Bool = false) -> UIView {
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 4
        s.semanticContentAttribute = .forceLeftToRight
        let emoji = makeControl(emojiOn ? "😊" : "🙂", #selector(emojiTapped))
        let midTitle = page == .symbols ? title : (lettersMode ? "ABC" : title)
        let symbols = makeControl(midTitle, #selector(symbolsOrLettersTapped))
        let space = makeControl("مسافة", #selector(spaceTapped))
        let period = makeControl(".", #selector(periodTapped))
        let enter = makeControl("إدخال", #selector(enterTapped))
        let hide = makeIcon("keyboard.chevron.compact.down", #selector(dismissKeyboardAction))
        emoji.widthAnchor.constraint(greaterThanOrEqualToConstant: 36).isActive = true
        symbols.widthAnchor.constraint(greaterThanOrEqualToConstant: 44).isActive = true
        period.widthAnchor.constraint(equalToConstant: 34).isActive = true
        enter.widthAnchor.constraint(greaterThanOrEqualToConstant: 52).isActive = true
        hide.widthAnchor.constraint(equalToConstant: 36).isActive = true
        space.setContentHuggingPriority(.defaultLow, for: .horizontal)
        [emoji, symbols, space, period, enter, hide].forEach { s.addArrangedSubview($0) }
        s.heightAnchor.constraint(equalToConstant: 40).isActive = true
        return s
    }

    private func makeEmojiTabs() -> UIView {
        let scroller = UIScrollView()
        scroller.showsHorizontalScrollIndicator = false
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 6
        s.translatesAutoresizingMaskIntoConstraints = false
        scroller.addSubview(s)
        for (i, cat) in emojiCategories.enumerated() {
            let b = makeControl(cat.title, #selector(emojiCategoryTapped(_:)))
            b.tag = i
            b.backgroundColor = i == emojiCategoryIndex ? UIColor.systemBlue.withAlphaComponent(0.25) : .tertiarySystemFill
            s.addArrangedSubview(b)
        }
        NSLayoutConstraint.activate([
            s.leadingAnchor.constraint(equalTo: scroller.contentLayoutGuide.leadingAnchor),
            s.trailingAnchor.constraint(equalTo: scroller.contentLayoutGuide.trailingAnchor),
            s.topAnchor.constraint(equalTo: scroller.contentLayoutGuide.topAnchor),
            s.bottomAnchor.constraint(equalTo: scroller.contentLayoutGuide.bottomAnchor),
            s.heightAnchor.constraint(equalTo: scroller.frameLayoutGuide.heightAnchor)
        ])
        scroller.heightAnchor.constraint(equalToConstant: 32).isActive = true
        return scroller
    }

    private func currentEmojiPages() -> [[String]] {
        let items = emojiCategories[min(emojiCategoryIndex, emojiCategories.count - 1)].emojis
        return stride(from: 0, to: items.count, by: emojiPerPage).map { Array(items[$0..<min($0 + emojiPerPage, items.count)]) }
    }

    private func makeEmojiGrid() -> UIView {
        let pages = currentEmojiPages()
        let items = pages.isEmpty ? [] : pages[min(emojiPageIndex, max(pages.count - 1, 0))]
        let grid = UIStackView()
        grid.axis = .vertical
        grid.spacing = 4
        grid.distribution = .fillEqually
        var n = 0
        for _ in 0..<4 {
            let row = UIStackView()
            row.axis = .horizontal
            row.spacing = 4
            row.distribution = .fillEqually
            for _ in 0..<8 {
                if n < items.count { row.addArrangedSubview(makeChar(items[n])) }
                else { row.addArrangedSubview(UIView()) }
                n += 1
            }
            grid.addArrangedSubview(row)
        }
        return grid
    }

    private func makeEmojiPager() -> UIView {
        let total = max(currentEmojiPages().count, 1)
        let s = UIStackView()
        s.axis = .horizontal
        s.spacing = 8
        s.alignment = .center
        let prev = makeControl("◀", #selector(emojiPrevPage))
        let lab = UILabel()
        lab.text = "\(min(emojiPageIndex + 1, total))/\(total)"
        lab.textAlignment = .center
        lab.font = .monospacedDigitSystemFont(ofSize: 13, weight: .semibold)
        let next = makeControl("▶", #selector(emojiNextPage))
        prev.widthAnchor.constraint(equalToConstant: 44).isActive = true
        next.widthAnchor.constraint(equalToConstant: 44).isActive = true
        s.addArrangedSubview(prev)
        s.addArrangedSubview(lab)
        s.addArrangedSubview(next)
        s.heightAnchor.constraint(equalToConstant: 30).isActive = true
        return s
    }

    private func styled() -> UIButton {
        let b = UIButton(type: .system)
        b.backgroundColor = .systemBackground
        b.setTitleColor(.label, for: .normal)
        b.layer.cornerRadius = 6
        return b
    }

    private func makeChar(_ t: String) -> UIButton {
        let b = styled()
        b.setTitle(t, for: .normal)
        b.titleLabel?.font = letterFont
        b.addTarget(self, action: #selector(characterTapped(_:)), for: .touchUpInside)
        return b
    }

    private func makeAction(_ t: String, _ a: Selector) -> UIButton {
        let b = styled()
        b.setTitle(t, for: .normal)
        b.titleLabel?.font = toolbarFont
        b.addTarget(self, action: a, for: .touchUpInside)
        return b
    }

    private func makeControl(_ t: String, _ a: Selector) -> UIButton {
        let b = styled()
        b.setTitle(t, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 14, weight: .semibold)
        b.addTarget(self, action: a, for: .touchUpInside)
        return b
    }

    private func makeIcon(_ name: String, _ a: Selector) -> UIButton {
        let b = styled()
        b.setImage(UIImage(systemName: name, withConfiguration: iconConfig), for: .normal)
        b.tintColor = .label
        b.addTarget(self, action: a, for: .touchUpInside)
        return b
    }

    @objc private func characterTapped(_ sender: UIButton) {
        guard let t = sender.title(for: .normal), !t.isEmpty else { return }
        textDocumentProxy.insertText(t)
        if page == .letters, language == .english, isShifted {
            isShifted = false
            rebuild()
        }
    }

    @objc private func shiftTapped() { isShifted.toggle(); rebuild() }

    @objc private func deleteTouchDown() {
        textDocumentProxy.deleteBackward()
        deleteTimer?.invalidate()
        deleteTimer = Timer.scheduledTimer(withTimeInterval: 0.35, repeats: false) { [weak self] _ in
            self?.deleteTimer = Timer.scheduledTimer(withTimeInterval: 0.07, repeats: true) { [weak self] _ in
                self?.textDocumentProxy.deleteBackward()
            }
        }
    }

    @objc private func deleteTouchUp() { deleteTimer?.invalidate(); deleteTimer = nil }
    @objc private func deleteTouchCancel() { deleteTimer?.invalidate(); deleteTimer = nil }

    @objc private func spaceTapped() {
        let now = Date()
        if let last = lastSpaceTap, now.timeIntervalSince(last) <= spaceSwitchInterval {
            lastSpaceTap = nil
            language = language == .arabic ? .english : .arabic
            isShifted = false
            if page != .emoji { page = .letters }
            rebuild()
            return
        }
        lastSpaceTap = now
        textDocumentProxy.insertText(" ")
    }

    @objc private func periodTapped() { textDocumentProxy.insertText(".") }
    @objc private func enterTapped() { textDocumentProxy.insertText("\n") }
    @objc private func emojiTapped() { page = .emoji; rebuild() }

    @objc private func symbolsOrLettersTapped() {
        switch page {
        case .letters:
            page = .symbols; symbolPageIndex = 0
        case .symbols:
            if symbolPageIndex == 0 { symbolPageIndex = 1 }
            else { page = .letters; symbolPageIndex = 0 }
        case .emoji:
            page = .letters
        }
        rebuild()
    }

    @objc private func emojiCategoryTapped(_ sender: UIButton) {
        emojiCategoryIndex = sender.tag
        emojiPageIndex = 0
        rebuild()
    }

    @objc private func emojiPrevPage() {
        let t = max(currentEmojiPages().count, 1)
        emojiPageIndex = (emojiPageIndex - 1 + t) % t
        rebuild()
    }

    @objc private func emojiNextPage() {
        let t = max(currentEmojiPages().count, 1)
        emojiPageIndex = (emojiPageIndex + 1) % t
        rebuild()
    }

    @objc private func copyTapped() {
        guard hasFullAccess else { return }
        persistFullAccess()
        let selected = textDocumentProxy.selectedText
        let text = (selected?.isEmpty == false ? selected : nil) ?? combinedContext()
        guard let text, !text.isEmpty else { return }
        UIPasteboard.general.string = text
    }

    @objc private func pasteTapped() {
        guard hasFullAccess else { return }
        persistFullAccess()
        if let t = UIPasteboard.general.string, !t.isEmpty { textDocumentProxy.insertText(t) }
    }

    @objc private func translateTapped() {
        guard hasFullAccess else { return }
        persistFullAccess()
        let selected = textDocumentProxy.selectedText
        let text = (selected?.isEmpty == false ? selected : nil)
            ?? textDocumentProxy.documentContextBeforeInput
            ?? combinedContext()
        guard let text, !text.isEmpty else { return }
        let ar = text.unicodeScalars.filter { $0.value >= 0x0600 && $0.value <= 0x06FF }.count
        let toEn = ar >= max(1, text.count / 4)
        translationModel.sourceLang = toEn ? "ar" : "en"
        translationModel.targetLang = toEn ? "en" : "ar"
        translationModel.sourceText = text
        translationModel.token += 1
    }

    private func applyTranslation(_ text: String) {
        guard !text.isEmpty else { return }
        if let selected = textDocumentProxy.selectedText, !selected.isEmpty {
            textDocumentProxy.deleteBackward()
            textDocumentProxy.insertText(text)
            return
        }
        if let before = textDocumentProxy.documentContextBeforeInput {
            for _ in 0..<before.count { textDocumentProxy.deleteBackward() }
        }
        textDocumentProxy.insertText(text)
    }

    private func combinedContext() -> String? {
        let v = (textDocumentProxy.documentContextBeforeInput ?? "") + (textDocumentProxy.documentContextAfterInput ?? "")
        return v.isEmpty ? nil : v
    }

    @objc private func dismissKeyboardAction() { dismissKeyboard() }

    private static func makeEmojiCatalog() -> [(title: String, emojis: [String])] {
        func split(_ s: String) -> [String] { s.split(separator: " ").map(String.init) }
        return [
            ("وجوه", split("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 👽 🤖 🎃 😺 😸 😹 😻 😼 😽 🙀 😿 😾")),
            ("ناس", split("👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 💪 🦵 🦶 👂 👃 👀 👶 👧 👦 👩 🧑 👨 👵 👴 👮 👷 💂 👸 🤴 🦸 🎅 🧙 🧝 🧚 👼 🚶 🏃 💃 🕺 🧘 👪")),
            ("قلوب", split("❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ⭐ 🌟 ✨ ⚡ 🔥 💯 ✅ ❌ ❓ ❗")),
            ("حيوان", split("🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐒 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🐙 🦑 🦐 🦞 🦀 🐡 🐠 🐟 🐬 🐳 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦛 🦏 🐪 🦒 🦘 🐄 🐖 🐏 🐑 🦙 🐐 🦌 🐓 🦃 🦚 🦜 🦢 🦩 🐇 🦨 🦥 🦔 🐉 🌵 🎄 🌲 🌳 🌴 🌱 🌿 ☘️ 🍀 🍃 🍂 🍁 🍄 💐 🌷 🌹 🥀 🌺 🌸 🌼 🌻")),
            ("طعام", split("🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥒 🌶️ 🌽 🥕 🧄 🧅 🥔 🥐 🥯 🍞 🥖 🧀 🥚 🍳 🥞 🧇 🥓 🥩 🍗 🌭 🍔 🍟 🍕 🥪 🌮 🌯 🥗 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🍤 🍙 🍚 🍧 🍨 🍦 🥧 🧁 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🥜 🍯 🥛 ☕ 🍵 🧃 🥤 🧋 🍺 🍻 🍷 🍸 🍹")),
            ("سفر", split("🚗 🚕 🚙 🚌 🚓 🚑 🚒 🚚 🚜 🛴 🚲 🛵 🏍️ ✈️ 🛫 🛬 🚀 🛸 🚁 ⛵ 🚤 🚢 ⚓ ⛽ 🚧 🚦 🗽 🗼 🏰 🏯 🎡 🎢 🎠 ⛺ 🏠 🏡 🏢 🏥 🏦 🏨 🏫 ⛪ 🕌 🕍 🛕 🕋 🌅 🌄 🌠 🎆 🌇 🌃 🌌 🌉")),
            ("نشاط", split("⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 🏸 🏒 ⛳ 🏹 🎣 🥊 🥋 🎽 🛹 🎿 🏂 🏆 🥇 🥈 🥉 🎯 🎮 🎲 🎭 🎨 🎬 🎤 🎧 🎹 🥁 🎸 🎺 🎻")),
            ("أشياء", split("⌚ 📱 💻 ⌨️ 🖥️ 🖨️ 📷 📹 🎥 📞 📺 📻 ⏰ ⌛ 🔋 🔌 💡 🔦 💸 💵 💰 💳 💎 🔧 🔨 🧲 🔒 🔑 🚪 🛏️ 🧸 🎁 🎈 🎉 📦 📚 ✏️ 📌")),
            ("رموز", split("❤️ ⭐ 🌟 ✨ ⚡ 🔥 💧 🌈 ☀️ ⛅ ☁️ 🌧️ ❄️ ⛄ ✅ ❌ ❓ ❗ 💯 🔔 💬 ⚪ ⚫ 🔴 🔵 🟢 🟡 🟠 🟣 🔺 🔻")),
            ("أعلام", split("🏳️ 🏴 🏁 🚩 🇸🇦 🇦🇪 🇶🇦 🇰🇼 🇧🇭 🇴🇲 🇾🇪 🇪🇬 🇸🇩 🇱🇾 🇹🇳 🇩🇿 🇲🇦 🇯🇴 🇵🇸 🇱🇧 🇸🇾 🇮🇶 🇹🇷 🇺🇸 🇬🇧 🇫🇷 🇩🇪 🇮🇹 🇪🇸 🇨🇳 🇯🇵 🇰🇷 🇮🇳 🇵🇰 🇮🇩 🇲🇾 🇺🇳"))
        ]
    }
}