import SwiftUI
import Translation

@main
struct KeyboardPrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    var body: some View {
        VStack(spacing: 18) {
            Text("لوحتي")
                .font(.largeTitle.bold())
            Text("لوحة عربية وإنجليزية وأردية خفيفة")
                .font(.title3)
            VStack(alignment: .leading, spacing: 10) {
                Label("افتح الإعدادات > عام > لوحة المفاتيح", systemImage: "gearshape")
                Label("أضف لوحة «لوحتي» من لوحات المفاتيح", systemImage: "keyboard")
                Label("انقر المسافة مرتين للدوران: العربية ← English ← اردو", systemImage: "character.cursor.ibeam")
                Label("الأرقام إنجليزية في جميع اللغات", systemImage: "number")
                Label("الرموز والإيموجي في الشريط العلوي", systemImage: "face.smiling")
                Label("الحذف في اليمين ويعمل بالضغط المطوّل", systemImage: "delete.left")
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
            if #available(iOS 18.0, *) {
                TranslationPreparationButton()
            }
            Text("النسخ واللصق يحتاجان إلى تفعيل الوصول الكامل. الترجمة تعمل بين العربية والإنجليزية على iOS 18 أو أحدث بعد تجهيز اللغتين؛ ترجمة الأردية غير متاحة حاليًا.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(uiColor: .systemGroupedBackground))
    }
}

@available(iOS 18.0, *)
private struct TranslationPreparationButton: View {
    @State private var configuration: TranslationSession.Configuration?
    @State private var status = ""

    var body: some View {
        VStack(spacing: 8) {
            Button("تجهيز الترجمة العربية والإنجليزية") {
                configuration = TranslationSession.Configuration(
                    source: Locale.Language(identifier: "ar"),
                    target: Locale.Language(identifier: "en")
                )
            }
            .buttonStyle(.borderedProminent)
            if !status.isEmpty {
                Text(status)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .translationTask(configuration) { session in
            do {
                try await session.prepareTranslation()
                status = "اكتمل تجهيز الترجمة على الجهاز"
            } catch {
                status = "تعذر تجهيز حزم اللغة الآن؛ جرّب اتصال Wi‑Fi ثم أعد المحاولة"
            }
        }
    }
}
