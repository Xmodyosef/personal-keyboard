import UIKit

final class KeyboardViewController: UIInputViewController {
    private var isArabic = true
    private var isShifted = false
    private let keyboardRoot = UIStackView()
    private var heightConstraint: NSLayoutConstraint?

    private let numberKeys = Array("1234567890").map(String.init)
    private let englishRows = [Array("qwertyuiop").map(String.init), Array("asdfghjkl").map(String.init), Array("zxcvbnm").map(String.init)]
    private let arabicRows: [[String]] = [
        ["ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج"],
        ["ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك"],
        ["ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "ظ"]
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        setupKeyboard()
        rebuildKeys()
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        preferredContentSize = CGSize(width: view.bounds.width, height: 270)
    }

    private func setupKeyboard() {
        view.backgroundColor = UIColor(red: 0.91, green: 0.92, blue: 0.94, alpha: 1)
        keyboardRoot.axis = .vertical
        keyboardRoot.semanticContentAttribute = .forceLeftToRight
        keyboardRoot.alignment = .fill
        keyboardRoot.distribution = .fillEqually
        keyboardRoot.spacing = 7
        keyboardRoot.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(keyboardRoot)
        NSLayoutConstraint.activate([
            keyboardRoot.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 4),
            keyboardRoot.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -4),
            keyboardRoot.topAnchor.constraint(equalTo: view.topAnchor, constant: 7),
            keyboardRoot.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -7)
        ])
        heightConstraint = view.heightAnchor.constraint(equalToConstant: 270)
        heightConstraint?.priority = .defaultHigh
        heightConstraint?.isActive = true
    }

    private func rebuildKeys() {
        keyboardRoot.arrangedSubviews.forEach {
            keyboardRoot.removeArrangedSubview($0)
            $0.removeFromSuperview()
        }

        addKeyRow(numberKeys, style: .standard)
        let rows = isArabic ? arabicRows : englishRows
        addKeyRow(rows[0], style: .standard)
        addKeyRow(rows[1], style: .standard, horizontalInset: 14)
        addLetterControlRow(rows[2])
        addBottomRow()
    }

    private enum KeyStyle { case standard, utility, language }

    private func addKeyRow(_ keys: [String], style: KeyStyle, horizontalInset: CGFloat = 0) {
        let row = UIStackView()
        row.axis = .horizontal
        row.semanticContentAttribute = isArabic ? .forceRightToLeft : .forceLeftToRight
        row.alignment = .fill
        row.distribution = .fillEqually
        row.spacing = 5
        row.isLayoutMarginsRelativeArrangement = true
        row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: horizontalInset, bottom: 0, trailing: horizontalInset)
        for key in keys {
            let button = makeButton(title: isShifted && !isArabic ? key.uppercased() : key, style: style)
            button.addAction(UIAction { [weak self] _ in self?.insert(key) }, for: .touchUpInside)
            row.addArrangedSubview(button)
        }
        keyboardRoot.addArrangedSubview(row)
    }

    private func addLetterControlRow(_ letters: [String]) {
        let row = UIStackView()
        row.axis = .horizontal
        row.semanticContentAttribute = isArabic ? .forceRightToLeft : .forceLeftToRight
        row.alignment = .fill
        row.distribution = .fillEqually
        row.spacing = 5
        row.isLayoutMarginsRelativeArrangement = true
        row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 3, bottom: 0, trailing: 3)

        let shift = makeButton(title: "⇧", style: .utility)
        shift.addAction(UIAction { [weak self] _ in
            self?.isShifted.toggle()
            self?.rebuildKeys()
        }, for: .touchUpInside)
        row.addArrangedSubview(shift)

        for key in letters {
            let button = makeButton(title: isShifted && !isArabic ? key.uppercased() : key, style: .standard)
            button.addAction(UIAction { [weak self] _ in self?.insert(key) }, for: .touchUpInside)
            row.addArrangedSubview(button)
        }

        let delete = makeButton(title: "⌫", style: .utility)
        delete.addAction(UIAction { [weak self] _ in self?.textDocumentProxy.deleteBackward() }, for: .touchUpInside)
        row.addArrangedSubview(delete)
        keyboardRoot.addArrangedSubview(row)
    }

    private func addBottomRow() {
        let row = UIStackView()
        row.axis = .horizontal
        row.semanticContentAttribute = .forceLeftToRight
        row.alignment = .fill
        row.distribution = .fill
        row.spacing = 5

        let punctuation = makeButton(title: isArabic ? "،" : ",", style: .utility)
        punctuation.widthAnchor.constraint(equalToConstant: 42).isActive = true
        punctuation.addAction(UIAction { [weak self] _ in
            guard let self else { return }
            self.textDocumentProxy.insertText(self.isArabic ? "،" : ",")
        }, for: .touchUpInside)
        row.addArrangedSubview(punctuation)

        let space = makeButton(title: "مسافة", style: .standard)
        space.setContentHuggingPriority(.defaultLow, for: .horizontal)
        space.addAction(UIAction { [weak self] _ in self?.textDocumentProxy.insertText(" ") }, for: .touchUpInside)
        row.addArrangedSubview(space)

        let returnKey = makeButton(title: "↵", style: .utility)
        returnKey.widthAnchor.constraint(equalToConstant: 48).isActive = true
        returnKey.addAction(UIAction { [weak self] _ in self?.textDocumentProxy.insertText("\n") }, for: .touchUpInside)
        row.addArrangedSubview(returnKey)

        let language = makeButton(title: isArabic ? "EN" : "ع", style: .language)
        language.widthAnchor.constraint(equalToConstant: 46).isActive = true
        language.accessibilityLabel = isArabic ? "Switch to English" : "التبديل إلى العربية"
        language.addAction(UIAction { [weak self] _ in
            self?.isArabic.toggle()
            self?.isShifted = false
            self?.rebuildKeys()
        }, for: .touchUpInside)
        row.addArrangedSubview(language)
        keyboardRoot.addArrangedSubview(row)
    }

    private func makeButton(title: String, style: KeyStyle) -> UIButton {
        var config = UIButton.Configuration.filled()
        config.title = title
        config.cornerStyle = .medium
        config.contentInsets = NSDirectionalEdgeInsets(top: 2, leading: 2, bottom: 2, trailing: 2)
        switch style {
        case .standard:
            config.baseBackgroundColor = .white
            config.baseForegroundColor = UIColor.label
        case .utility:
            config.baseBackgroundColor = UIColor(red: 0.77, green: 0.80, blue: 0.84, alpha: 1)
            config.baseForegroundColor = UIColor.label
        case .language:
            config.baseBackgroundColor = UIColor.systemBlue
            config.baseForegroundColor = .white
        }
        let button = UIButton(configuration: config)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .regular)
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = style == .standard ? 0.12 : 0
        button.layer.shadowRadius = 0
        button.layer.shadowOffset = CGSize(width: 0, height: 1)
        return button
    }

    private func insert(_ key: String) {
        let output = isShifted && !isArabic ? key.uppercased() : key
        textDocumentProxy.insertText(output)
        if isShifted && !isArabic {
            isShifted = false
            rebuildKeys()
        }
    }
}
