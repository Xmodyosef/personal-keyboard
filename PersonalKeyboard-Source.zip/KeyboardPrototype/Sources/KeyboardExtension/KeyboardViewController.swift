import UIKit

final class KeyboardViewController: UIInputViewController {
    // MARK: - State
    private var isArabic = true
    private var isShifted = false
    private var currentTheme: Theme = .morning

    private let keyboardRoot = UIStackView()
    private let impact = UIImpactFeedbackGenerator(style: .light)
    private var heightConstraint: NSLayoutConstraint?
    private var themeTimer: Timer?

    // References used for lightweight Shift updates.
    private var letterButtons: [(button: UIButton, key: String)] = []
    private weak var shiftButton: UIButton?

    // MARK: - Keyboard data
    private let numberKeys = Array("1234567890").map(String.init)
    private let englishRows = [
        Array("qwertyuiop").map(String.init),
        Array("asdfghjkl").map(String.init),
        Array("zxcvbnm").map(String.init)
    ]
    private let arabicRows: [[String]] = [
        ["ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج"],
        ["ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك"],
        ["ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "ظ"]
    ]

    // MARK: - Themes
    private enum Theme: Equatable {
        case morning
        case evening

        var background: UIColor {
            switch self {
            case .morning: return UIColor(red: 0.94, green: 0.95, blue: 0.97, alpha: 1)
            case .evening: return UIColor(red: 0.10, green: 0.11, blue: 0.13, alpha: 1)
            }
        }

        var keyBackground: UIColor {
            switch self {
            case .morning: return .white
            case .evening: return UIColor(red: 0.20, green: 0.21, blue: 0.24, alpha: 1)
            }
        }

        var utilityBackground: UIColor {
            switch self {
            case .morning: return UIColor(red: 0.78, green: 0.81, blue: 0.85, alpha: 1)
            case .evening: return UIColor(red: 0.30, green: 0.32, blue: 0.36, alpha: 1)
            }
        }

        var languageBackground: UIColor {
            switch self {
            case .morning: return .systemBlue
            case .evening: return UIColor(red: 0.25, green: 0.55, blue: 0.95, alpha: 1)
            }
        }

        var textColor: UIColor {
            switch self {
            case .morning: return .label
            case .evening: return .white
            }
        }

        var activeShiftBackground: UIColor {
            switch self {
            case .morning: return UIColor.systemBlue.withAlphaComponent(0.25)
            case .evening: return UIColor.systemBlue.withAlphaComponent(0.55)
            }
        }

        var shadowOpacity: Float {
            switch self {
            case .morning: return 0.08
            case .evening: return 0
            }
        }
    }

    private enum KeyStyle: Equatable {
        case standard
        case utility
        case language
    }

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        impact.prepare()
        setupKeyboard()
        applyAutomaticTheme()
        rebuildKeys()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        themeTimer?.invalidate()
        themeTimer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in
            self?.applyAutomaticTheme()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        themeTimer?.invalidate()
        themeTimer = nil
    }

    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        if previousTraitCollection?.userInterfaceStyle != traitCollection.userInterfaceStyle {
            applyAutomaticTheme()
        }
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        preferredContentSize = CGSize(width: view.bounds.width, height: 270)
    }

    // MARK: - Automatic theme
    private func applyAutomaticTheme() {
        let selectedTheme: Theme
        if traitCollection.userInterfaceStyle == .dark {
            selectedTheme = .evening
        } else {
            let hour = Calendar.current.component(.hour, from: Date())
            selectedTheme = (hour >= 6 && hour < 18) ? .morning : .evening
        }

        guard selectedTheme != currentTheme else { return }
        currentTheme = selectedTheme
        view.backgroundColor = currentTheme.background
        rebuildKeys()
    }

    // MARK: - Layout
    private func setupKeyboard() {
        view.backgroundColor = currentTheme.background
        keyboardRoot.axis = .vertical
        keyboardRoot.semanticContentAttribute = .forceLeftToRight
        keyboardRoot.alignment = .fill
        keyboardRoot.distribution = .fillEqually
        keyboardRoot.spacing = 7
        keyboardRoot.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(keyboardRoot)
        NSLayoutConstraint.activate([
            keyboardRoot.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 4),
            keyboardRoot.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -4),
            keyboardRoot.topAnchor.constraint(equalTo: view.topAnchor, constant: 7),
            keyboardRoot.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -7)
        ])
        heightConstraint = view.heightAnchor.constraint(equalToConstant: 270)
        heightConstraint?.priority = .defaultHigh
        heightConstraint?.isActive = true
    }

    private func rebuildKeys() {
        keyboardRoot.arrangedSubviews.forEach {
            keyboardRoot.removeArrangedSubview($0)
            $0.removeFromSuperview()
        }
        letterButtons.removeAll()
        shiftButton = nil

        addKeyRow(numberKeys, style: .standard, forceLTR: true)
        let rows = isArabic ? arabicRows : englishRows
        addKeyRow(rows[0], style: .standard, respondsToShift: !isArabic)
        addKeyRow(rows[1], style: .standard, horizontalInset: 14, respondsToShift: !isArabic)
        addLetterControlRow(rows[2])
        addBottomRow()
        updateShiftState()
    }

    private func addKeyRow(
        _ keys: [String],
        style: KeyStyle,
        horizontalInset: CGFloat = 0,
        forceLTR: Bool = false,
        respondsToShift: Bool = false
    ) {
        let row = UIStackView()
        row.axis = .horizontal
        row.semanticContentAttribute = forceLTR ? .forceLeftToRight
            : (isArabic ? .forceRightToLeft : .forceLeftToRight)
        row.alignment = .fill
        row.distribution = .fillEqually
        row.spacing = 5
        row.isLayoutMarginsRelativeArrangement = true
        row.directionalLayoutMargins = NSDirectionalEdgeInsets(
            top: 0, leading: horizontalInset, bottom: 0, trailing: horizontalInset
        )

        for key in keys {
            let button = makeButton(title: key, style: style)
            if respondsToShift {
                letterButtons.append((button: button, key: key))
            }
            button.addAction(UIAction { [weak self] _ in self?.insert(key) }, for: .touchUpInside)
            row.addArrangedSubview(button)
        }
        keyboardRoot.addArrangedSubview(row)
    }

    private func addLetterControlRow(_ letters: [String]) {
        let row = UIStackView()
        row.axis = .horizontal
        row.semanticContentAttribute = isArabic ? .forceRightToLeft : .forceLeftToRight
        row.alignment = .fill
        row.distribution = .fillEqually
        row.spacing = 5
        row.isLayoutMarginsRelativeArrangement = true
        row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 3, bottom: 0, trailing: 3)

        let shift = makeButton(title: "⇧", style: .utility)
        shift.isEnabled = !isArabic
        shiftButton = shift
        shift.addAction(UIAction { [weak self] _ in
            guard let self, !self.isArabic else { return }
            self.isShifted.toggle()
            self.updateShiftState()
        }, for: .touchUpInside)
        row.addArrangedSubview(shift)

        for key in letters {
            let button = makeButton(title: key, style: .standard)
            letterButtons.append((button: button, key: key))
            button.addAction(UIAction { [weak self] _ in self?.insert(key) }, for: .touchUpInside)
            row.addArrangedSubview(button)
        }

        let delete = makeButton(title: "⌫", style: .utility)
        delete.addAction(UIAction { [weak self] _ in self?.deleteBackward() }, for: .touchUpInside)
        row.addArrangedSubview(delete)
        keyboardRoot.addArrangedSubview(row)
    }

    private func addBottomRow() {
        let row = UIStackView()
        row.axis = .horizontal
        row.semanticContentAttribute = .forceLeftToRight
        row.alignment = .fill
        row.distribution = .fill
        row.spacing = 4

        let copyButton = makeButton(title: isArabic ? "نسخ" : "Copy", style: .utility)
        copyButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .medium)
        copyButton.widthAnchor.constraint(equalToConstant: 44).isActive = true
        copyButton.addAction(UIAction { [weak self] _ in self?.copyText() }, for: .touchUpInside)
        row.addArrangedSubview(copyButton)

        let pasteButton = makeButton(title: isArabic ? "لصق" : "Paste", style: .utility)
        pasteButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .medium)
        pasteButton.widthAnchor.constraint(equalToConstant: 44).isActive = true
        pasteButton.addAction(UIAction { [weak self] _ in self?.pasteText() }, for: .touchUpInside)
        row.addArrangedSubview(pasteButton)

        let translateButton = makeButton(title: isArabic ? "ترجمة" : "Translate", style: .utility)
        translateButton.titleLabel?.font = .systemFont(ofSize: 12, weight: .medium)
        translateButton.widthAnchor.constraint(equalToConstant: 50).isActive = true
        translateButton.addAction(UIAction { [weak self] _ in self?.translateText() }, for: .touchUpInside)
        row.addArrangedSubview(translateButton)

        let globe = makeButton(title: "🌐", style: .utility)
        globe.widthAnchor.constraint(equalToConstant: 36).isActive = true
        globe.accessibilityLabel = "Change keyboard"
        globe.addAction(UIAction { [weak self] _ in self?.advanceToNextInputMode() }, for: .touchUpInside)
        row.addArrangedSubview(globe)

        let returnKey = makeButton(title: returnKeyTitle(), style: .utility)
        returnKey.widthAnchor.constraint(equalToConstant: 48).isActive = true
        returnKey.addAction(UIAction { [weak self] _ in
            guard let self else { return }
            self.impact.impactOccurred()
            self.textDocumentProxy.insertText("\n")
        }, for: .touchUpInside)
        row.addArrangedSubview(returnKey)

        let space = makeButton(title: isArabic ? "مسافة" : "space", style: .standard)
        space.setContentHuggingPriority(.defaultLow, for: .horizontal)
        space.addAction(UIAction { [weak self] _ in
            guard let self else { return }
            self.impact.impactOccurred()
            self.textDocumentProxy.insertText(" ")
        }, for: .touchUpInside)
        row.addArrangedSubview(space)

        let dismissButton = makeButton(title: "⌨️", style: .utility)
        dismissButton.widthAnchor.constraint(equalToConstant: 38).isActive = true
        dismissButton.accessibilityLabel = isArabic ? "إخفاء لوحة المفاتيح" : "Dismiss keyboard"
        dismissButton.addAction(UIAction { [weak self] _ in self?.dismissKeyboardAction() }, for: .touchUpInside)
        row.addArrangedSubview(dismissButton)

        let language = makeButton(title: isArabic ? "EN" : "ع", style: .language)
        language.widthAnchor.constraint(equalToConstant: 40).isActive = true
        language.accessibilityLabel = isArabic ? "Switch to English" : "التبديل إلى العربية"
        language.addAction(UIAction { [weak self] _ in
            guard let self else { return }
            self.isArabic.toggle()
            self.isShifted = false
            self.rebuildKeys()
        }, for: .touchUpInside)
        row.addArrangedSubview(language)

        keyboardRoot.addArrangedSubview(row)
    }

    // MARK: - Shift state (lightweight; does not rebuild the keyboard)
    private func updateShiftState() {
        for item in letterButtons {
            let title = isShifted && !isArabic ? item.key.uppercased() : item.key
            item.button.configuration?.title = title
        }
        shiftButton?.isEnabled = !isArabic
        shiftButton?.configuration?.baseBackgroundColor = isShifted
            ? currentTheme.activeShiftBackground
            : currentTheme.utilityBackground
        shiftButton?.configuration?.baseForegroundColor = currentTheme.textColor
    }

    // MARK: - Buttons and text input
    private func makeButton(title: String, style: KeyStyle) -> UIButton {
        var config = UIButton.Configuration.filled()
        config.title = title
        config.cornerStyle = .medium
        config.contentInsets = NSDirectionalEdgeInsets(top: 2, leading: 2, bottom: 2, trailing: 2)

        switch style {
        case .standard:
            config.baseBackgroundColor = currentTheme.keyBackground
            config.baseForegroundColor = currentTheme.textColor
        case .utility:
            config.baseBackgroundColor = currentTheme.utilityBackground
            config.baseForegroundColor = currentTheme.textColor
        case .language:
            config.baseBackgroundColor = currentTheme.languageBackground
            config.baseForegroundColor = .white
        }

        let button = UIButton(configuration: config)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .regular)
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = style == .standard ? currentTheme.shadowOpacity : 0
        button.layer.shadowRadius = 0
        button.layer.shadowOffset = CGSize(width: 0, height: 1)
        return button
    }

    private func returnKeyTitle() -> String {
        switch textDocumentProxy.returnKeyType {
        case .go: return isArabic ? "اذهب" : "Go"
        case .search: return isArabic ? "بحث" : "Search"
        case .done: return isArabic ? "تم" : "Done"
        case .send: return isArabic ? "إرسال" : "Send"
        default: return "↵"
        }
    }

    private func insert(_ key: String) {
        let output = isShifted && !isArabic ? key.uppercased() : key
        impact.impactOccurred()
        impact.prepare()
        textDocumentProxy.insertText(output)
        if isShifted && !isArabic {
            isShifted = false
            updateShiftState()
        }
    }

    private func deleteBackward() {
        impact.impactOccurred()
        impact.prepare()
        textDocumentProxy.deleteBackward()
    }

    private func copyText() {
        impact.impactOccurred()
        guard hasFullAccess,
              let selectedText = textDocumentProxy.selectedText,
              !selectedText.isEmpty else { return }
        UIPasteboard.general.string = selectedText
    }

    private func pasteText() {
        impact.impactOccurred()
        guard hasFullAccess,
              let text = UIPasteboard.general.string,
              !text.isEmpty else { return }
        textDocumentProxy.insertText(text)
    }

    private func translateText() {
        impact.impactOccurred()
        // Placeholder for a future translation implementation.
    }

    private func dismissKeyboardAction() {
        impact.impactOccurred()
        dismissKeyboard()
    }
}
