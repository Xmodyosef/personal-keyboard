import UIKit
import SwiftUI
import Translation

@available(iOS 18.0, *)
@MainActor
private final class TranslationBridgeModel: ObservableObject {
    @Published var configuration: TranslationSession.Configuration?
    private var pendingText: String?
    private var completion: ((Result<String, Error>) -> Void)?

    func request(
        text: String,
        source: Locale.Language,
        target: Locale.Language,
        completion: @escaping (Result<String, Error>) -> Void
    ) {
        pendingText = text
        self.completion = completion
        configuration = TranslationSession.Configuration(source: source, target: target)
    }

    func translate(using session: TranslationSession) async {
        guard let text = pendingText else { return }
        do {
            let response = try await session.translate(text)
            finish(.success(response.targetText))
        } catch {
            finish(.failure(error))
        }
    }

    private func finish(_ result: Result<String, Error>) {
        let callback = completion
        completion = nil
        pendingText = nil
        configuration = nil
        callback?(result)
    }
}

@available(iOS 18.0, *)
private struct TranslationBridgeView: View {
    @ObservedObject var model: TranslationBridgeModel

    var body: some View {
        Color.clear
            .frame(width: 1, height: 1)
            .translationTask(model.configuration) { session in
                await model.translate(using: session)
            }
    }
}

final class KeyboardViewController: UIInputViewController {
    // MARK: - State
    private var isArabic = true
    private var isShifted = false
    private var currentTheme: Theme = .morning
    private var lastSpaceTapTime: TimeInterval?

    private let keyboardRoot = UIStackView()
    private let statusLabel = UILabel()
    private let impact = UIImpactFeedbackGenerator(style: .light)
    private var heightConstraint: NSLayoutConstraint?
    private var themeTimer: Timer?
    private var statusTimer: Timer?
    private var translationBridgeModel: AnyObject?
    private var translationHost: UIViewController?

    // References used for lightweight Shift updates.
    private var letterButtons: [(button: UIButton, key: String)] = []
    private weak var shiftButton: UIButton?

    // MARK: - Keyboard data
    private var numberKeys: [String] {
        Array((isArabic ? "١٢٣٤٥٦٧٨٩٠" : "1234567890")).map(String.init)
    }

    private let englishRows: [[String]] = [
        Array("qwertyuiop").map(String.init),
        Array("asdfghjkl").map(String.init),
        Array("zxcvbnm").map(String.init)
    ]

    private let arabicRows: [[String]] = [
        ["ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د"],
        ["ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط"],
        ["ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "ظ"]
    ]

    // MARK: - Themes
    private enum Theme: Equatable {
        case morning
        case evening

        var background: UIColor {
            switch self {
            case .morning: return UIColor(red: 0.88, green: 0.93, blue: 0.98, alpha: 1)
            case .evening: return UIColor(red: 0.055, green: 0.075, blue: 0.12, alpha: 1)
            }
        }

        var keyBackground: UIColor {
            switch self {
            case .morning: return UIColor(red: 0.99, green: 0.995, blue: 1, alpha: 1)
            case .evening: return UIColor(red: 0.14, green: 0.18, blue: 0.25, alpha: 1)
            }
        }

        var utilityBackground: UIColor {
            switch self {
            case .morning: return UIColor(red: 0.74, green: 0.82, blue: 0.91, alpha: 1)
            case .evening: return UIColor(red: 0.22, green: 0.29, blue: 0.40, alpha: 1)
            }
        }

        var textColor: UIColor {
            switch self {
            case .morning: return .label
            case .evening: return .white
            }
        }

        var activeShiftBackground: UIColor {
            switch self {
            case .morning: return UIColor.systemBlue.withAlphaComponent(0.25)
            case .evening: return UIColor.systemTeal.withAlphaComponent(0.42)
            }
        }

        var shadowOpacity: Float {
            switch self {
            case .morning: return 0.12
            case .evening: return 0.05
            }
        }
    }

    private enum KeyStyle: Equatable {
        case standard
        case utility
    }

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        impact.prepare()
        setupKeyboard()
        setupTranslationBridgeIfAvailable()
        applyAutomaticTheme()
        rebuildKeys()
        if #available(iOS 17.0, *) {
            registerForTraitChanges([UITraitUserInterfaceStyle.self]) { (self: KeyboardViewController, _) in
                self.applyAutomaticTheme()
            }
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        themeTimer?.invalidate()
        themeTimer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in
            self?.applyAutomaticTheme()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        themeTimer?.invalidate()
        themeTimer = nil
        statusTimer?.invalidate()
        statusTimer = nil
        lastSpaceTapTime = nil
    }

    // MARK: - Automatic theme
    private func applyAutomaticTheme() {
        let selectedTheme: Theme
        if traitCollection.userInterfaceStyle == .dark {
            selectedTheme = .evening
        } else {
            let hour = Calendar.current.component(.hour, from: Date())
            selectedTheme = (hour >= 6 && hour < 18) ? .morning : .evening
        }

        guard selectedTheme != currentTheme else { return }
        currentTheme = selectedTheme
        view.backgroundColor = currentTheme.background
        statusLabel.textColor = currentTheme.textColor
        statusLabel.backgroundColor = currentTheme.utilityBackground
        rebuildKeys()
    }

    // MARK: - Layout
    private func setupKeyboard() {
        view.backgroundColor = currentTheme.background
        keyboardRoot.axis = .vertical
        keyboardRoot.semanticContentAttribute = .forceLeftToRight
        keyboardRoot.alignment = .fill
        keyboardRoot.distribution = .fillEqually
        keyboardRoot.spacing = 5
        keyboardRoot.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(keyboardRoot)
        NSLayoutConstraint.activate([
            keyboardRoot.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 4),
            keyboardRoot.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -4),
            keyboardRoot.topAnchor.constraint(equalTo: view.topAnchor, constant: 6),
            keyboardRoot.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -6)
        ])
        heightConstraint = view.heightAnchor.constraint(equalToConstant: 286)
        heightConstraint?.priority = .defaultHigh
        heightConstraint?.isActive = true

        statusLabel.font = .systemFont(ofSize: 12, weight: .medium)
        statusLabel.textAlignment = .center
        statusLabel.textColor = currentTheme.textColor
        statusLabel.backgroundColor = currentTheme.utilityBackground
        statusLabel.layer.cornerRadius = 12
        statusLabel.layer.masksToBounds = true
        statusLabel.alpha = 0
        statusLabel.isUserInteractionEnabled = false
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(statusLabel)
        NSLayoutConstraint.activate([
            statusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 2),
            statusLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 24),
            statusLabel.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, constant: -32)
        ])
    }

    private func setupTranslationBridgeIfAvailable() {
        guard #available(iOS 18.0, *) else { return }
        let model = TranslationBridgeModel()
        let host = UIHostingController(rootView: TranslationBridgeView(model: model))
        host.view.backgroundColor = .clear
        host.view.isUserInteractionEnabled = false
        host.view.translatesAutoresizingMaskIntoConstraints = false
        addChild(host)
        view.addSubview(host.view)
        NSLayoutConstraint.activate([
            host.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            host.view.topAnchor.constraint(equalTo: view.topAnchor),
            host.view.widthAnchor.constraint(equalToConstant: 1),
            host.view.heightAnchor.constraint(equalToConstant: 1)
        ])
        host.didMove(toParent: self)
        translationBridgeModel = model
        translationHost = host
    }

    private func rebuildKeys() {
        keyboardRoot.arrangedSubviews.forEach {
            keyboardRoot.removeArrangedSubview($0)
            $0.removeFromSuperview()
        }
        letterButtons.removeAll()
        shiftButton = nil

        addKeyRow(numberKeys, style: .standard, forceLTR: true)
        let rows = isArabic ? arabicRows : englishRows
        addKeyRow(rows[0], style: .standard, respondsToShift: !isArabic)
        addKeyRow(rows[1], style: .standard, horizontalInset: 14, respondsToShift: !isArabic)
        addLetterControlRow(rows[2])
        addBottomRow()
        updateShiftState()
    }

    private func addKeyRow(
        _ keys: [String],
        style: KeyStyle,
        horizontalInset: CGFloat = 0,
        forceLTR: Bool = false,
        respondsToShift: Bool = false
    ) {
        let row = UIStackView()
        row.axis = .horizontal
        // The arrays above are stored in the exact visual order used by iPhone keyboards.
        row.semanticContentAttribute = .forceLeftToRight
        row.alignment = .fill
        row.distribution = .fillEqually
        row.spacing = 5
        row.isLayoutMarginsRelativeArrangement = true
        row.directionalLayoutMargins = NSDirectionalEdgeInsets(
            top: 0, leading: horizontalInset, bottom: 0, trailing: horizontalInset
        )

        for key in keys {
            let button = makeButton(title: key, style: style)
            if respondsToShift {
                letterButtons.append((button: button, key: key))
            }
            button.addAction(UIAction { [weak self] _ in self?.insert(key) }, for: .touchUpInside)
            row.addArrangedSubview(button)
        }
        keyboardRoot.addArrangedSubview(row)
    }

    private func addLetterControlRow(_ letters: [String]) {
        let row = UIStackView()
        row.axis = .horizontal
        // Keep Shift fixed at the visual left and Delete fixed at the visual right.
        row.semanticContentAttribute = .forceLeftToRight
        row.alignment = .fill
        row.distribution = .fill
        row.spacing = 5
        row.isLayoutMarginsRelativeArrangement = true
        row.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 3, bottom: 0, trailing: 3)

        let shift = makeButton(title: "⇧", style: .utility)
        shift.isEnabled = !isArabic
        shiftButton = shift
        shift.addAction(UIAction { [weak self] _ in
            guard let self, !self.isArabic else { return }
            self.isShifted.toggle()
            self.updateShiftState()
        }, for: .touchUpInside)
        shift.widthAnchor.constraint(equalToConstant: 43).isActive = true
        row.addArrangedSubview(shift)

        let lettersStack = UIStackView()
        lettersStack.axis = .horizontal
        lettersStack.semanticContentAttribute = .forceLeftToRight
        lettersStack.alignment = .fill
        lettersStack.distribution = .fillEqually
        lettersStack.spacing = 5
        for key in letters {
            let button = makeButton(title: key, style: .standard)
            letterButtons.append((button: button, key: key))
            button.addAction(UIAction { [weak self] _ in self?.insert(key) }, for: .touchUpInside)
            lettersStack.addArrangedSubview(button)
        }
        row.addArrangedSubview(lettersStack)

        let delete = makeButton(title: "⌫", style: .utility)
        delete.widthAnchor.constraint(equalToConstant: 43).isActive = true
        delete.addAction(UIAction { [weak self] _ in self?.deleteBackward() }, for: .touchUpInside)
        row.addArrangedSubview(delete)
        keyboardRoot.addArrangedSubview(row)
    }

    private func addBottomRow() {
        let row = UIStackView()
        row.axis = .horizontal
        row.semanticContentAttribute = .forceLeftToRight
        row.alignment = .fill
        row.distribution = .fill
        row.spacing = 5

        let copyButton = makeButton(title: "", style: .utility)
        copyButton.configuration?.image = UIImage(systemName: "doc.on.doc")
        copyButton.configuration?.imagePadding = 0
        copyButton.accessibilityLabel = isArabic ? "نسخ النص المحدد" : "Copy selected text"
        copyButton.widthAnchor.constraint(equalToConstant: 40).isActive = true
        copyButton.addAction(UIAction { [weak self] _ in self?.copyText() }, for: .touchUpInside)
        row.addArrangedSubview(copyButton)

        let pasteButton = makeButton(title: "", style: .utility)
        pasteButton.configuration?.image = UIImage(systemName: "doc.on.clipboard")
        pasteButton.configuration?.imagePadding = 0
        pasteButton.accessibilityLabel = isArabic ? "لصق" : "Paste"
        pasteButton.widthAnchor.constraint(equalToConstant: 40).isActive = true
        pasteButton.addAction(UIAction { [weak self] _ in self?.pasteText() }, for: .touchUpInside)
        row.addArrangedSubview(pasteButton)

        let translateButton = makeButton(title: "A文", style: .utility)
        translateButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        translateButton.accessibilityLabel = isArabic ? "ترجمة النص المحدد" : "Translate selected text"
        translateButton.widthAnchor.constraint(equalToConstant: 42).isActive = true
        translateButton.addAction(UIAction { [weak self] _ in self?.translateText() }, for: .touchUpInside)
        row.addArrangedSubview(translateButton)

        let globe = makeButton(title: "🌐", style: .utility)
        globe.widthAnchor.constraint(equalToConstant: 36).isActive = true
        globe.accessibilityLabel = isArabic ? "تغيير لوحة مفاتيح النظام" : "Change system keyboard"
        globe.addAction(UIAction { [weak self] _ in self?.advanceToNextInputMode() }, for: .touchUpInside)
        row.addArrangedSubview(globe)

        let space = makeButton(title: isArabic ? "مسافة" : "space", style: .standard)
        space.accessibilityLabel = isArabic
            ? "مسافة؛ انقر مرتين للتبديل إلى الإنجليزية"
            : "Space; double tap to switch to Arabic"
        space.setContentHuggingPriority(.defaultLow, for: .horizontal)
        space.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        space.addAction(UIAction { [weak self] _ in self?.handleSpaceTap() }, for: .touchUpInside)
        row.addArrangedSubview(space)

        let dismissButton = makeButton(title: "⌨️", style: .utility)
        dismissButton.widthAnchor.constraint(equalToConstant: 38).isActive = true
        dismissButton.accessibilityLabel = isArabic ? "إخفاء لوحة المفاتيح" : "Dismiss keyboard"
        dismissButton.addAction(UIAction { [weak self] _ in self?.dismissKeyboardAction() }, for: .touchUpInside)
        row.addArrangedSubview(dismissButton)

        keyboardRoot.addArrangedSubview(row)
    }

    // MARK: - Shift state (lightweight; does not rebuild the keyboard)
    private func updateShiftState() {
        for item in letterButtons {
            let title = isShifted && !isArabic ? item.key.uppercased() : item.key
            item.button.configuration?.title = title
        }
        shiftButton?.isEnabled = !isArabic
        shiftButton?.configuration?.baseBackgroundColor = isShifted
            ? currentTheme.activeShiftBackground
            : currentTheme.utilityBackground
        shiftButton?.configuration?.baseForegroundColor = currentTheme.textColor
    }

    // MARK: - Buttons and text input
    private func makeButton(title: String, style: KeyStyle) -> UIButton {
        var config = UIButton.Configuration.filled()
        config.title = title
        config.cornerStyle = .medium
        config.contentInsets = NSDirectionalEdgeInsets(top: 2, leading: 2, bottom: 2, trailing: 2)

        switch style {
        case .standard:
            config.baseBackgroundColor = currentTheme.keyBackground
            config.baseForegroundColor = currentTheme.textColor
        case .utility:
            config.baseBackgroundColor = currentTheme.utilityBackground
            config.baseForegroundColor = currentTheme.textColor
        }

        let button = UIButton(configuration: config)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .regular)
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = style == .standard ? currentTheme.shadowOpacity : 0
        button.layer.shadowRadius = 0
        button.layer.shadowOffset = CGSize(width: 0, height: 1)
        return button
    }

    private func insert(_ key: String) {
        lastSpaceTapTime = nil
        let output = isShifted && !isArabic ? key.uppercased() : key
        impact.impactOccurred()
        impact.prepare()
        textDocumentProxy.insertText(output)
        if isShifted && !isArabic {
            isShifted = false
            updateShiftState()
        }
    }

    private func deleteBackward() {
        lastSpaceTapTime = nil
        impact.impactOccurred()
        impact.prepare()
        textDocumentProxy.deleteBackward()
    }

    private func handleSpaceTap() {
        impact.impactOccurred()
        let now = ProcessInfo.processInfo.systemUptime
        if let lastSpaceTapTime, now - lastSpaceTapTime <= 0.36 {
            textDocumentProxy.deleteBackward() // Remove the first space so the double tap only switches language.
            self.lastSpaceTapTime = nil
            isArabic.toggle()
            isShifted = false
            rebuildKeys()
            showStatus(isArabic ? "العربية" : "English")
            return
        }
        textDocumentProxy.insertText(" ")
        lastSpaceTapTime = now
    }

    private func showStatus(_ message: String) {
        statusTimer?.invalidate()
        statusLabel.text = "  \(message)  "
        statusLabel.alpha = 1
        statusTimer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: false) { [weak self] _ in
            UIView.animate(withDuration: 0.2) { self?.statusLabel.alpha = 0 }
        }
    }

    private func copyText() {
        impact.impactOccurred()
        guard hasFullAccess else {
            showStatus(isArabic ? "فعّل الوصول الكامل للنسخ" : "Enable Full Access to copy")
            return
        }
        guard let selectedText = textDocumentProxy.selectedText, !selectedText.isEmpty else {
            showStatus(isArabic ? "حدّد النص أولًا ثم انسخه" : "Select text first, then copy")
            return
        }
        UIPasteboard.general.string = selectedText
        showStatus(isArabic ? "تم النسخ" : "Copied")
    }

    private func pasteText() {
        impact.impactOccurred()
        guard hasFullAccess else {
            showStatus(isArabic ? "فعّل الوصول الكامل للصق" : "Enable Full Access to paste")
            return
        }
        guard let text = UIPasteboard.general.string, !text.isEmpty else {
            showStatus(isArabic ? "الحافظة فارغة أو الوصول مرفوض" : "Clipboard is empty or access denied")
            return
        }
        textDocumentProxy.insertText(text)
        showStatus(isArabic ? "تم اللصق" : "Pasted")
    }

    private func translateText() {
        impact.impactOccurred()
        guard let selectedText = textDocumentProxy.selectedText, !selectedText.isEmpty else {
            showStatus(isArabic ? "حدّد النص لترجمته أولًا" : "Select text to translate first")
            return
        }
        guard #available(iOS 18.0, *),
              let bridgeModel = translationBridgeModel as? TranslationBridgeModel else {
            showStatus(isArabic ? "الترجمة تتطلب iOS 18 أو أحدث" : "Translation requires iOS 18 or later")
            return
        }

        let containsArabic = selectedText.unicodeScalars.contains { (0x0600...0x06FF).contains(Int($0.value)) }
        let source = Locale.Language(identifier: containsArabic ? "ar" : "en")
        let target = Locale.Language(identifier: containsArabic ? "en" : "ar")
        showStatus(isArabic ? "جارٍ الترجمة على الجهاز…" : "Translating on device…")

        bridgeModel.request(text: selectedText, source: source, target: target) { [weak self] result in
            guard let self else { return }
            switch result {
            case .success(let translatedText):
                self.textDocumentProxy.insertText(translatedText)
                self.showStatus(self.isArabic ? "تمت الترجمة" : "Translated")
            case .failure:
                self.showStatus(self.isArabic
                    ? "تعذرت الترجمة؛ جرّب تجهيز اللغتين في التطبيق"
                    : "Translation unavailable; prepare both languages in the app")
            }
        }
    }

    private func dismissKeyboardAction() {
        impact.impactOccurred()
        dismissKeyboard()
    }
}
