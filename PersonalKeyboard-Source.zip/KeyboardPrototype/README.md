# لوحتي — لوحة مفاتيح iOS تجريبية

مشروع أولي للوحة مفاتيح عربية/إنجليزية، مع صف أرقام علوي وثلاثة صفوف حروف وشريط أزرار سفلي. زر تبديل اللغة في أقصى أسفل اليمين. النسخة الحالية تطلب **Full Access** لاستخدام أزرار النسخ واللصق؛ لا ترسل النص إلى خدمة ترجمة أو خادم.

## إخراج IPA من الآيفون باستخدام Mac سحابي

لا يحتاج هذا المسار إلى جهاز Mac لديك. GitHub Actions يشغّل Xcode على جهاز macOS مستضاف لدى GitHub، ويُخرج ملف IPA **غير موقّع**. بعد ذلك تستورده في ESign وتوقّعه على هاتفك. لا ترفع شهادة التوقيع أو ملف التزويد أو كلمة مرورهما إلى GitHub.

1. في Safari افتح [github.com/new](https://github.com/new)، وسجّل الدخول أو أنشئ حساب GitHub. أنشئ مستودعًا جديدًا **خاصًا (Private)** باسم مثل `personal-keyboard`.
2. افتح المستودع واضغط **Add file > Upload files**، ثم اختر ملف `PersonalKeyboard-Source.zip` من تطبيق «الملفات» على الآيفون. اترك اسم الملف كما هو، ثم اضغط **Commit changes**.
3. في المستودع اضغط **Add file > Create new file**. في خانة اسم الملف اكتب بالضبط: `.github/workflows/build-unsigned-ipa.yml`.
4. افتح ملف سير البناء المرفق أدناه، وانسخ محتواه كاملًا إلى محرر GitHub. اضغط **Commit changes** على فرع `main`.
5. افتح تبويب **Actions** في المستودع. إذا طلب GitHub تفعيل Actions فوافق على تشغيلها للمستودع. انتظر انتهاء مهمة **Build unsigned iOS IPA** بنجاح؛ قد يبدأ التشغيل تلقائيًا. وإلا افتح سير العمل واضغط **Run workflow**.
6. افتح نتيجة التشغيل الناجحة، ثم تحت **Artifacts** نزّل `PersonalKeyboard-unsigned-ipa`. سيصل ملف ZIP إلى «الملفات»؛ فك ضغطه لتحصل على `PersonalKeyboard-unsigned.ipa`.
7. في ESign استورد ملف IPA ووقّعه بشهادتك، ثم ثبّته. بعد التثبيت اذهب إلى **الإعدادات > عام > لوحة المفاتيح > لوحات المفاتيح > إضافة لوحة مفاتيح جديدة** واختر «لوحتي».

### ملف سير البناء

أنشئه في المستودع بالمسار المذكور أعلاه، والصق النص التالي:

```yaml
name: Build unsigned iOS IPA

on:
  workflow_dispatch:
  push:
    branches: [main]

jobs:
  build:
    runs-on: macos-15
    steps:
      - name: Check out repository
        uses: actions/checkout@v7

      - name: Unpack source archive if uploaded
        run: |
          if [ -f "PersonalKeyboard-Source.zip" ]; then
            mkdir -p /tmp/keyboard-source
            unzip -q PersonalKeyboard-Source.zip -d /tmp/keyboard-source
            cp -R /tmp/keyboard-source/KeyboardPrototype/. "$GITHUB_WORKSPACE/"
          fi

      - name: Install XcodeGen
        run: brew install xcodegen

      - name: Generate Xcode project
        run: xcodegen generate

      - name: Build app for iOS device without signing
        run: |
          xcodebuild \
            -project PersonalKeyboard.xcodeproj \
            -scheme PersonalKeyboard \
            -configuration Release \
            -sdk iphoneos \
            -derivedDataPath "$PWD/build/DerivedData" \
            CODE_SIGNING_ALLOWED=NO \
            build

      - name: Package unsigned IPA
        run: |
          mkdir -p "$PWD/build/Payload"
          cp -R "$PWD/build/DerivedData/Build/Products/Release-iphoneos/PersonalKeyboard.app" "$PWD/build/Payload/PersonalKeyboard.app"
          cd "$PWD/build"
          /usr/bin/zip -qry PersonalKeyboard-unsigned.ipa Payload

      - name: Upload IPA artifact
        uses: actions/upload-artifact@v6
        with:
          name: PersonalKeyboard-unsigned-ipa
          path: build/PersonalKeyboard-unsigned.ipa
          if-no-files-found: error
          retention-days: 7
```

## تنبيهات

- حساب GitHub وإتاحة دقائق macOS مطلوبان، وقد تختلف أسماء الأزرار قليلًا بين واجهة الجوال وواجهة الحاسوب.
- يجب أن تسمح شهادتك وملفات التزويد بتوقيع التطبيق وإضافة لوحة المفاتيح معًا. معرفا الحزمة المحددان في النموذج هما `app.personal.PersonalKeyboard` و`app.personal.PersonalKeyboard.KeyboardExtension`. غيّرهما معًا إذا كانت شهادتك وملفات التزويد تستخدمان معرفات أخرى.
- احتفظ بالمستودع خاصًا. لا ترفع ملفات `.p12` أو `.mobileprovision` أو كلمات مرور الشهادة.
- لم يُنفذ البناء السحابي من هذه الجلسة، ولم يتم التحقق من توافق الشهادة. بعض الحقول الحساسة قد تجبر iOS على استخدام لوحة النظام.
- هذا نموذج أولي، لا يشمل التنبؤ أو التصحيح أو الكتابة بالسحب. الحد الأدنى المستهدف iOS 17.

## إصلاح فشل XcodeGen عند `path: Nothing found`

إذا ظهر هذا الخطأ في أول تشغيل، فنسخة `PersonalKeyboard-Source.zip` القديمة تحتوي على `project.yml` ناقصًا. النسخة المصححة تتضمن مسار Info.plist المطلوب: `Sources/KeyboardExtension/Info.plist`. استبدل ملف ZIP في المستودع بالنسخة المصححة ثم انتظر تشغيل Actions من جديد. لا تغيّر الشهادة أو إعداد ESign لمعالجة هذا الخطأ؛ فهو يحصل قبل مرحلة البناء والتوقيع.

## إصلاح خطأ ترجمة Swift

أُعلن `KeyStyle` كتعداد متوافق مع `Equatable` لأن الشيفرة تقارن النمط بالقيمة `.standard` عند تحديد ظل الأزرار. إذا فشل تشغيل سابق عند `SwiftCompile`، استبدل الأرشيف بحزمة المصدر الأحدث ثم أعد البناء. إذا استمر الفشل، أرسل رسالة `error:` الفعلية من سجل `xcodebuild`، لأن ملخص `BUILD FAILED` لا يعرض تشخيص المترجم التفصيلي.

## تحسينات واجهة الكتابة

صف الأرقام يبقى معروضًا من اليسار إلى اليمين في اللغتين. يتغير عنوان زر المسافة بين «مسافة» و`space` وفق اللغة المحددة، ويظهر زر Shift بتظليل أزرق خفيف عند تفعيله للإنجليزية.

تتضمن النسخة الحالية أيضًا استجابة لمسية خفيفة عند كتابة الأحرف والحذف، وزر 🌐 يستدعي `advanceToNextInputMode()` للتبديل إلى لوحة مفاتيح iOS التالية. يظل زر اللغة الداخلي مخصصًا للتبديل بين العربية والإنجليزية داخل هذه اللوحة.

## الثيم التلقائي وShift

يوجد ثيمان: morning الفاتح بين 06:00 و17:59، وevening الداكن بين 18:00 و05:59. إذا كان مظهر iOS الداكن مفعّلًا، تُستخدم evening بغض النظر عن الوقت. يفحص الامتداد تغيّر الوقت دوريًا، ويستجيب لتغيّر مظهر النظام.

زر Shift متاح للإنجليزية فقط. الضغط عليه يحدّث حالة الأحرف وعنوان زر Shift مباشرةً من دون إعادة إنشاء لوحة المفاتيح؛ وبعد إدخال الحرف الكبير يعود تلقائيًا إلى الحالة غير المفعّلة. إعادة إنشاء المفاتيح تبقى عند تبديل اللغة أو تغيّر الثيم التلقائي.

## الشريط السفلي والحافظة

يضم الشريط أزرار نسخ ولصق وترجمة ومسافة وGlobe وإدخال وإخفاء لوحة المفاتيح وتبديل اللغة. النسخ ينسخ النص المحدد حاليًا فقط، واللصق يدرج نص الحافظة؛ وكلاهما يحتاج تفعيل **Full Access** في إعدادات iOS، لذلك صار الامتداد يطلبه. لن تُقرأ الحافظة أو تُنسخ محتوياتها تلقائيًا؛ لا يحدث ذلك إلا عند ضغط زر النسخ أو اللصق. زر الترجمة حاليًا تجريبي ويصدر استجابة لمسية فقط؛ لم يُربط بمحرك ترجمة.
