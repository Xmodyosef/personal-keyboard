import SwiftUI
import Translation
import UIKit

@main
struct KeyboardPrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

enum NaqraThemeID: String, CaseIterable, Identifiable {
    case auto, light, dark, glass, oled, ocean, cobalt, royal
    case violet, amethyst, orchid, hailey, ember, forest, jade
    case matrix, dracula, nebula, nocturne, slate, graphite
    case prism, aurora, rose, nord, custom

    var id: String { rawValue }

    enum Family: String {
        case core = "أساسي"
        case color = "ألوان"
        case special = "خاص"
    }

    var family: Family {
        switch self {
        case .auto, .light, .dark, .oled, .glass, .nord: return .core
        case .ocean, .cobalt, .royal, .violet, .amethyst, .orchid, .hailey, .ember, .rose: return .color
        default: return .special
        }
    }

    var title: String {
        switch self {
        case .auto: return "تلقائي"
        case .light: return "فاتح"
        case .dark: return "داكن"
        case .glass: return "منشور"
        case .oled: return "أوليد"
        case .ocean: return "بحر"
        case .cobalt: return "كوبالت"
        case .royal: return "ملكي"
        case .violet: return "بنفسج"
        case .amethyst: return "جمشت"
        case .orchid: return "أوركيد"
        case .hailey: return "دم"
        case .ember: return "جمر"
        case .forest: return "غابة"
        case .jade: return "يشم"
        case .matrix: return "ماتريكس"
        case .dracula: return "دراكولا"
        case .nebula: return "سديم"
        case .nocturne: return "ليلي"
        case .slate: return "أردواز"
        case .graphite: return "جرافيت"
        case .prism: return "منشور زجاج"
        case .aurora: return "شفق"
        case .rose: return "وردي"
        case .nord: return "نورد"
        case .custom: return "مخصص"
        }
    }

    var keyColor: Color {
        switch self {
        case .auto: return Color(red: 0.34, green: 0.36, blue: 0.40)
        case .light: return Color(red: 0.88, green: 0.94, blue: 1.00)
        case .dark: return Color(red: 0.14, green: 0.18, blue: 0.36)
        case .glass: return Color(red: 0.86, green: 0.84, blue: 0.94)
        case .oled: return Color(red: 0.08, green: 0.08, blue: 0.09)
        case .ocean: return Color(red: 0.04, green: 0.34, blue: 0.36)
        case .cobalt: return Color(red: 0.10, green: 0.16, blue: 0.52)
        case .royal: return Color(red: 0.12, green: 0.16, blue: 0.42)
        case .violet: return Color(red: 0.28, green: 0.10, blue: 0.46)
        case .amethyst: return Color(red: 0.28, green: 0.14, blue: 0.42)
        case .orchid: return Color(red: 0.46, green: 0.12, blue: 0.30)
        case .hailey: return Color(red: 0.38, green: 0.06, blue: 0.08)
        case .ember: return Color(red: 0.42, green: 0.22, blue: 0.06)
        case .forest: return Color(red: 0.22, green: 0.34, blue: 0.12)
        case .jade: return Color(red: 0.06, green: 0.22, blue: 0.16)
        case .matrix: return Color(red: 0.01, green: 0.05, blue: 0.01)
        case .dracula: return Color(red: 0.16, green: 0.10, blue: 0.16)
        case .nebula: return Color(red: 0.16, green: 0.10, blue: 0.28)
        case .nocturne: return Color(red: 0.08, green: 0.12, blue: 0.22)
        case .slate: return Color(red: 0.22, green: 0.26, blue: 0.32)
        case .graphite: return Color(red: 0.16, green: 0.16, blue: 0.18)
        case .prism: return Color(red: 0.86, green: 0.78, blue: 0.96)
        case .aurora: return Color(red: 0.08, green: 0.20, blue: 0.18)
        case .rose: return Color(red: 0.42, green: 0.14, blue: 0.22)
        case .nord: return Color(red: 0.74, green: 0.80, blue: 0.86)
        case .custom: return Color(red: 0.46, green: 0.48, blue: 0.52)
        }
    }

    var ink: Color {
        switch self {
        case .light, .glass, .nord, .prism: return Color(red: 0.12, green: 0.16, blue: 0.22)
        case .forest: return Color(red: 0.90, green: 0.93, blue: 0.62)
        case .jade, .aurora: return Color(red: 0.72, green: 0.96, blue: 0.82)
        case .matrix: return Color(red: 0.12, green: 1.00, blue: 0.28)
        case .ocean: return Color(red: 0.55, green: 0.98, blue: 0.96)
        case .ember: return Color(red: 1.00, green: 0.88, blue: 0.46)
        case .hailey, .rose: return Color(red: 1.00, green: 0.78, blue: 0.82)
        case .dracula: return Color(red: 0.98, green: 0.78, blue: 0.86)
        default: return Color.white.opacity(0.94)
        }
    }

    static func normalized(_ raw: String) -> NaqraThemeID {
        switch raw {
        case "charcoal", "smoke": return .dark
        case "teal": return .ocean
        case "midnight": return .cobalt
        case "snow": return .light
        case "clear": return .glass
        default: return NaqraThemeID(rawValue: raw) ?? .dark
        }
    }
}

enum ThemeStore {
    static let suiteName = "group.app.personal.PersonalKeyboard"
    static var suite: UserDefaults { UserDefaults(suiteName: suiteName) ?? .standard }
    static var fileURL: URL? {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: suiteName)?
            .appendingPathComponent("naqra-prefs.json")
    }

    static func fileDict() -> [String: Any] {
        guard let url = fileURL, let data = try? Data(contentsOf: url),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return [:] }
        return obj
    }

    static let boardName = UIPasteboard.Name("group.app.personal.PersonalKeyboard")

    static func write(_ key: String, value: Any) {
        suite.set(value, forKey: key)
        UserDefaults.standard.set(value, forKey: key)
        suite.synchronize()
        UserDefaults.standard.synchronize()
        var d = fileDict()
        d[key] = value
        if let url = fileURL, let data = try? JSONSerialization.data(withJSONObject: d, options: []) {
            try? data.write(to: url, options: .atomic)
        }
        let pb = UIPasteboard(name: boardName, create: true)
        if let text = value as? String {
            pb?.string = "naqra|" + key + "|" + text
        } else if let flag = value as? Bool {
            pb?.string = "naqra|" + key + "|" + (flag ? "1" : "0")
        }
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName("app.personal.PersonalKeyboard.prefs" as CFString),
            nil,
            nil,
            true
        )
    }

    static func string(_ key: String) -> String? {
        if let v = fileDict()[key] as? String { return v }
        if let v = suite.string(forKey: key) { return v }
        if let v = UserDefaults.standard.string(forKey: key) { return v }
        if key == "themeId",
           let raw = UIPasteboard(name: boardName, create: false)?.string,
           raw.hasPrefix("naqra|themeId|") {
            return String(raw.dropFirst("naqra|themeId|".count))
        }
        return nil
    }

    static func bool(_ key: String) -> Bool? {
        if let v = fileDict()[key] as? Bool { return v }
        if suite.object(forKey: key) != nil { return suite.bool(forKey: key) }
        if UserDefaults.standard.object(forKey: key) != nil {
            return UserDefaults.standard.bool(forKey: key)
        }
        return nil
    }

    static var groupAlive: Bool {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: suiteName) != nil
    }
}

struct KeyboardPreview: View {
    let theme: NaqraThemeID
    var symbols: Bool = false
    var body: some View {
        VStack(spacing: 5) {
            HStack(spacing: 5) {
                cap("⧉")
                ForEach(["اقتراح","تصحيح","بديل"], id: \.self) { w in
                    Text(w)
                        .font(.system(size: 11, weight: .medium))
                        .frame(maxWidth: .infinity)
                        .frame(height: 22)
                        .background(theme.keyColor.opacity(0.55))
                        .clipShape(RoundedRectangle(cornerRadius: 6))
                        .foregroundStyle(theme.ink)
                }
                cap("文A")
            }
            if symbols {
                keys(Array("1234567890").map(String.init), 11)
                keys(["-","/"," :","؛","(",")","&","@"], 12)
                keys([".","،","?","!","'","*","+","="], 12)
                keys(["٪","؟","…","«","»","•","×","÷"], 12)
            } else {
                keys(Array("1234567890").map(String.init), 11)
                keys(["ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج"], 13)
                keys(["ش","س","ي","ب","ل","ا","ت","ن","م","ك","ة"], 13)
                keys(["ء","ظ","ط","ذ","د","ز","ر","و","ى"], 13)
            }
            HStack(spacing: 5) {
                cap(symbols ? "1/2" : "123")
                Text(" ")
                    .frame(maxWidth: .infinity)
                    .frame(height: 22)
                    .background(theme.keyColor.opacity(0.55))
                    .clipShape(RoundedRectangle(cornerRadius: 6))
                cap(".")
                cap("↓")
            }
        }
        .padding(10)
        .background(theme.keyColor.opacity(0.20))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.22), lineWidth: 1))
    }
    private func cap(_ t: String) -> some View {
        Text(t)
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(theme.ink)
            .frame(minWidth: 28, minHeight: 22)
            .padding(.horizontal, 4)
            .background(theme.keyColor)
            .clipShape(RoundedRectangle(cornerRadius: 6))
    }
    private func keys(_ items: [String], _ size: CGFloat) -> some View {
        HStack(spacing: 3) {
            ForEach(Array(items.enumerated()), id: \.offset) { _, item in
                Text(item)
                    .font(.system(size: size, weight: .medium))
                    .foregroundStyle(theme.ink)
                    .frame(maxWidth: .infinity)
                    .frame(height: 22)
                    .background(theme.keyColor)
                    .clipShape(RoundedRectangle(cornerRadius: 5))
            }
        }
    }
}

struct FeaturedThemeCard: View {
    let item: NaqraThemeID
    let selected: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            KeyboardPreview(theme: item)
            HStack {
                Text(item.title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)
                Spacer()
                Image(systemName: selected ? "checkmark.circle.fill" : "circle")
                    .foregroundStyle(selected ? Color.accentColor : Color.secondary)
            }
        }
        .padding(10)
        .background(Color.secondary.opacity(0.12))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(selected ? Color.accentColor : Color.clear, lineWidth: 2)
        )
    }
}

struct ContentView: View {
    @State private var hasFullAccess = false
    @State private var themeID = NaqraThemeID.dark
    @State private var haptics = true
    @State private var trackpad = true
    @State private var previewSymbols = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    accessCard
                    themesCard
                    extrasCard
                }
                .padding()
            }
            .navigationTitle("نقرة")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear(perform: reload)
        }
    }

    private var accessCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            if hasFullAccess {
                Text("الوصول الكامل مفعّل")
                    .font(.headline)
            } else {
                Button {
                    if let url = URL(string: UIApplication.openSettingsURLString) {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    Text("فتح الإعدادات")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(hasFullAccess ? Color.green.opacity(0.18) : Color.orange.opacity(0.16))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var themesCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("الثيمات")
                .font(.headline)
            Picker("", selection: $previewSymbols) {
                Text("حروف").tag(false)
                Text("رموز").tag(true)
            }
            .pickerStyle(.segmented)
            KeyboardPreview(theme: themeID, symbols: previewSymbols)
            HStack(spacing: 10) {
                Button { applyTheme(.light) } label: {
                    FeaturedThemeCard(item: .light, selected: themeID == .light)
                }
                .buttonStyle(.plain)
                Button { applyTheme(.dark) } label: {
                    FeaturedThemeCard(item: .dark, selected: themeID == .dark)
                }
                .buttonStyle(.plain)
            }
            Button { applyTheme(.auto) } label: {
                HStack {
                    Text("تلقائي")
                    Spacer()
                    Image(systemName: themeID == .auto ? "checkmark.circle.fill" : "circle")
                }
                .padding()
                .background(Color.secondary.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(.plain)
            ForEach([NaqraThemeID.Family.core, .color, .special], id: \.rawValue) { family in
                Text(family.rawValue)
                    .font(.subheadline.weight(.semibold))
                    .padding(.top, 4)
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                    ForEach(NaqraThemeID.allCases.filter { $0.family == family && $0 != .auto }) { item in
                        Button { applyTheme(item) } label: {
                            VStack(spacing: 8) {
                                KeyboardPreview(theme: item)
                                    .scaleEffect(0.92)
                                    .clipped()
                                HStack {
                                    Text(item.title)
                                        .font(.caption)
                                        .foregroundStyle(.primary)
                                    Spacer()
                                    if themeID == item {
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundStyle(Color.accentColor)
                                            .font(.caption)
                                    }
                                }
                            }
                            .padding(8)
                            .background(themeID == item ? Color.accentColor.opacity(0.16) : Color.secondary.opacity(0.10))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func miniKey(_ letter: String, _ item: NaqraThemeID) -> some View {
        Text(letter)
            .font(.system(size: 12, weight: .semibold))
            .foregroundStyle(item.ink)
            .frame(width: 28, height: 20)
            .background(item.keyColor.opacity(0.35))
            .clipShape(RoundedRectangle(cornerRadius: 4))
    }

    private var extrasCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("لمس أدق")
                .font(.headline)
            Toggle("اهتزاز خفيف عند المفاتيح", isOn: $haptics)
                .onChange(of: haptics) { _, v in
                    ThemeStore.write("haptics", value: v)
                }
            Toggle("سحب المسافة لتحريك المؤشر", isOn: $trackpad)
                .onChange(of: trackpad) { _, v in
                    ThemeStore.write("trackpad", value: v)
                }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var howToCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("تفعيل اللوحة")
                .font(.headline)
            Text("1. الإعدادات → عام → لوحة المفاتيح → لوحات المفاتيح.")
            Text("2. أضف لوحة مفاتيح ثم اختر نقرة.")
            Text("3. اضغط نقرة وفعّل السماح بالوصول الكامل.")
            Text("4. افتح اللوحة مرة ثم ارجع هنا لتتحدّث الحالة.")
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var sideloadCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("ESign / Feather / TrollStore")
                .font(.headline)
            Text("لا يوجد زر سحري داخل ملف deb. الثيم بين التطبيق واللوحة يحتاج App Group.")
            Text("عند التوقيع: لا تزيل Entitlements، وأبقِ group.app.personal.PersonalKeyboard. شهادة مطور أو TrollStore غالباً تشغّلها. التوقيع العام غالباً لا.")
            Text("إذا فشل المشاركة: ثيم اللوحة من أيقونة الألوان يعمل مباشرة.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func applyTheme(_ item: NaqraThemeID) {
        themeID = item
        ThemeStore.write("themeId", value: item.rawValue)
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    private func reload() {
        hasFullAccess = ThemeStore.bool("hasFullAccess") ?? false
        if let raw = ThemeStore.string("themeId") {
            themeID = NaqraThemeID.normalized(raw)
        }
        if let v = ThemeStore.bool("haptics") { haptics = v }
        if let v = ThemeStore.bool("trackpad") { trackpad = v }
    }
}

@available(iOS 18.0, *)
struct TranslationPrepCard: View {
    @State private var status = "جاري فحص حزم الترجمة…"

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("تجهيز ترجمة iOS 18")
                .font(.headline)
            Text(status)
                .font(.subheadline)
            Text("الترجمة داخل اللوحة بين العربية والإنجليزية فقط.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.blue.opacity(0.10))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .task {
            let availability = LanguageAvailability()
            let arEn = await availability.status(from: Locale.Language(identifier: "ar"), to: Locale.Language(identifier: "en"))
            let enAr = await availability.status(from: Locale.Language(identifier: "en"), to: Locale.Language(identifier: "ar"))
            switch (arEn, enAr) {
            case (.installed, .installed): status = "حزم العربية والإنجليزية جاهزة."
            case (.unsupported, _), (_, .unsupported): status = "الجهاز لا يدعم هذا الزوج من اللغات."
            default: status = "اللغات مدعومة. قد تُنزَّل الحزم عند أول ترجمة."
            }
        }
    }
}
